# BadGenesis cloud APK build

The checked-in Android source remains in `app/`; the current emulator and RTC
assets remain in `app/src/main/assets/`. The original HTML is `original.html`.

`bash tools/cloud-build.sh` builds that project with the official Android 36
platform and build-tools 36.0.0, Eclipse ECJ 3.42.0, and an installed Java 21
runtime. Downloads are cached in `toolchain/` and verified against the upstream
checksums. A Gradle build configuration is also included for the same sources.

The script compiles Java 17 source, desugars bytecode with D8 for Android API 26
and later, compiles the real resources and current emulator assets with AAPT2,
aligns the APK, and signs it with `signing/badgenesis-development.keystore`.
The retained signing key lets subsequent builds update the installed test app.
It verifies the APK signature and ZIP alignment and writes:

- `dist/BadGenesis-Android16.apk`
- `dist/apk-badging.txt`, including package ID and SDK declarations

The application targets Android 16 (API 36) and supports Android 8.0 (API 26)
and later. This script is for the cloud builder; installing and using the APK
on a phone does not require a computer or local build tools.

Native Android integration includes system document pickers, native AudioTrack
PCM output, audio focus and app lifecycle handling, fullscreen display and
cutout insets, portrait/landscape orientation, Bluetooth/USB controller input,
predictive Back handling, and optional vibration. The app requests only the
normal `VIBRATE` permission. Its emulator assets are packaged locally.

#!/usr/bin/env python3
"""Apply English UI text to the preserved sources after audio integration finishes.
Only strings and obsolete display-option UI hooks are changed; CPU/video execution is retained.
"""
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'
replacements={
    'ripristinati':'restored',
    'EA address invalido':'Invalid EA address', 'EA control invalido':'Invalid EA control',
    'non implementato':'not implemented', 'La ROM non dichiara SRAM':'The ROM does not declare SRAM',
    'Carica prima la ROM':'Load a ROM first', 'deflate non disponibile per':'deflate is unavailable for',
    'Indirizzo non valido':'Invalid address', 'Nessun breakpoint':'No breakpoints',
    'Nessun watchpoint':'No watchpoints', 'Debugger Mega Drive: OFF = nessun hook sul core':'Mega Drive debugger: OFF = core hooks disabled',
    'Debugger attivo':'Debugger enabled','Debugger disattivato':'Debugger disabled',
    'ROM CARICATA':'ROM LOADED','SPEGNI':'POWER OFF','ACCENDI':'POWER ON',
    'RIPRENDI':'RESUME','PAUSA':'PAUSED','ACCESO':'POWER ON',
    'analisi archivio…':'reading archive…','Nessuna ROM Mega Drive trovata nello ZIP':'No Mega Drive ROM found in the ZIP',
    'ROM caricata':'ROM loaded','ZIP · trovate':'ZIP · found','ERRORE':'ERROR',
    'Audio YM2612/Z80: prossimo step':'YM2612 / PSG audio',
    'core PSG/YM2612 non ancora attivo in questa alpha':'PSG / YM2612 audio',
    'gamepad rilevato:':'gamepad detected:','Gamepad collegato':'Gamepad connected',
    'gamepad scollegato':'gamepad disconnected','PAD · collegato':'PAD · connected',
    'State caricato':'State loaded','SRAM esportata':'SRAM exported','SRAM importata':'SRAM imported',
    'ROM ricevuta ma non caricata dal core':'ROM received but the core did not load it',
    'non caricata':'not loaded','save key non consentita':'save key is not allowed',
    'Direzioni':'Directions','registra le ultime istruzioni':'record the most recent instructions',' o frecce':' or arrow keys',
}
for name in ('core.js','hub.js'):
    p=root/name;s=p.read_text()
    for source,english in replacements.items():s=s.replace(source,english)
    if name=='core.js':
        # The Android app offers only unfiltered sharp pixels. Remove the retired selector hook.
        s=re.sub(r"\$\('#videoMode'\)\.onchange=e=>\{\$\('#screenShell'\)\.className='screen-shell '\+\(e\.target\.value==='pixel'\?'':e\.target\.value\)\};?",'',s)
        s=s.replace("makeToggle(){if(this.toggleBtn)return;const b=document.createElement('button');b.type='button';", "makeToggle(){if(this.toggleBtn)return;const b=document.createElement('button');b.id='mdDbgToggle';b.type='button';")
        # Correct input origin text; live Android/browser controller status is managed by mobile.js.
        s=s.replace('TOUCH / KEYBOARD / TOUCH','TOUCH / KEYBOARD')
        s=s.replace("$('#pauseBtn').textContent=machine.paused?'RESUME':'PAUSED'", "$('#pauseBtn').textContent=machine.paused?'RESUME':'PAUSE'")
    p.write_text(s)
print('English UI applied to core.js and hub.js; emulator logic unchanged.')

#!/usr/bin/env bash
# Build the existing Android application in the cloud without Android Studio or Gradle.
# Google SDK tools + Eclipse's Java compiler run on the installed Java 21 runtime.
set -Eeuo pipefail
trap 'printf "Build failed at line %s\n" "$LINENO" >&2' ERR
BG_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
BG_TOOLS="${BADGENESIS_TOOLCHAIN:-$BG_ROOT/toolchain}"
BG_BUILD="$BG_ROOT/build/cloud"
BG_DIST="$BG_ROOT/dist"
mkdir -p "$BG_TOOLS/downloads" "$BG_BUILD" "$BG_DIST" "$BG_ROOT/signing"
for command in java keytool curl python3; do
  command -v "$command" >/dev/null || { printf 'Required cloud command is missing: %s\n' "$command" >&2; exit 1; }
done

python3 - "$BG_TOOLS" "$BG_BUILD" "${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}" <<'PY'
import hashlib, pathlib, subprocess, sys, xml.etree.ElementTree as ET, zipfile
root = pathlib.Path(sys.argv[1]); cache = root/'downloads'; build = pathlib.Path(sys.argv[2])
installed_sdk = pathlib.Path(sys.argv[3]) if sys.argv[3] else None
def fetch(url, path):
    if path.exists() and path.stat().st_size: return
    temporary = path.with_suffix(path.suffix+'.part')
    print('Downloading '+url, flush=True)
    subprocess.run(['curl','--fail','--location','--retry','3','--connect-timeout','30',
                    '--max-time','900','--output',str(temporary),url],check=True)
    temporary.replace(path)
def check(path, algorithm, expected):
    actual = hashlib.new(algorithm,path.read_bytes()).hexdigest()
    if actual.lower() != expected.strip().lower():
        path.unlink(missing_ok=True)
        raise RuntimeError('Checksum mismatch: '+str(path))
tree = None
def tag(e):return e.tag.rsplit('}',1)[-1]
def child(e,name):return next((c for c in e if tag(c)==name),None)
def text(e,name):
    c=child(e,name);return c.text if c is not None else None
def install(package, filename, dest):
    global tree
    markers=sorted(dest.rglob(filename)) if dest.exists() else []
    if markers:return markers[0]
    if tree is None:
        metadata=cache/'repository2-3.xml'
        fetch('https://dl.google.com/android/repository/repository2-3.xml',metadata)
        tree=ET.parse(metadata)
    p=next((e for e in tree.iter() if tag(e)=='remotePackage' and e.get('path')==package),None)
    if p is None:raise RuntimeError('SDK repository does not contain '+package)
    archives=child(p,'archives')
    archive=next((a for a in archives if text(a,'host-os') in (None,'linux') and child(a,'complete') is not None),None)
    if archive is None:raise RuntimeError('No Linux SDK archive for '+package)
    complete=child(archive,'complete');relative=text(complete,'url')
    url=relative if relative.startswith('https://') else 'https://dl.google.com/android/repository/'+relative
    path=cache/pathlib.Path(relative).name
    fetch(url,path)
    checksum=child(complete,'checksum')
    if checksum is not None:check(path,checksum.get('type','sha1'),checksum.text)
    if text(complete,'size') and path.stat().st_size!=int(text(complete,'size')):raise RuntimeError('Incomplete SDK archive '+str(path))
    dest.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(path) as z:
        for member in z.infolist():
            extracted=(dest/member.filename).resolve()
            if not extracted.is_relative_to(dest.resolve()):raise RuntimeError('Unsafe SDK archive member')
        z.extractall(dest)
        for member in z.infolist():
            mode=member.external_attr>>16
            if mode: (dest/member.filename).chmod(mode&0o777)
    markers=sorted(dest.rglob(filename))
    if len(markers)!=1:raise RuntimeError('Expected one SDK '+filename+' after extracting '+package)
    return markers[0]
# Reuse the cloud runner's exact API 36 SDK when available. Official archives
# have changed their top-level directory names; discover files after extraction.
sdk=root/'sdk'
platform=installed_sdk/'platforms/android-36/android.jar' if installed_sdk else None
if platform is None or not platform.is_file():
    platform=install('platforms;android-36','android.jar',sdk/'platform-36')
tools=installed_sdk/'build-tools/36.0.0' if installed_sdk else None
required=('aapt2','d8','apksigner','zipalign')
if tools is None or not all((tools/name).is_file() for name in required):
    tools=install('build-tools;36.0.0','aapt2',sdk/'build-tools-36').parent
if not all((tools/name).is_file() for name in required):raise RuntimeError('Incomplete Android build-tools 36.0.0')
(build/'sdk-paths.txt').write_text(str(platform)+'\n'+str(tools)+'\n')
compiler=cache/'ecj-3.42.0.jar'
base='https://repo.maven.apache.org/maven2/org/eclipse/jdt/ecj/3.42.0/ecj-3.42.0.jar'
fetch(base,compiler)
checksum=cache/'ecj-3.42.0.jar.sha1';fetch(base+'.sha1',checksum)
check(compiler,'sha1',checksum.read_text().split()[0])
PY

mapfile -t BG_SDK_PATHS < "$BG_BUILD/sdk-paths.txt"
BG_ANDROID_JAR="${BG_SDK_PATHS[0]}"
BG_SDK_BIN="${BG_SDK_PATHS[1]}"
rm -rf "$BG_BUILD/classes" "$BG_BUILD/generated" "$BG_BUILD/dex"
mkdir -p "$BG_BUILD/classes" "$BG_BUILD/generated" "$BG_BUILD/dex"
python3 - "$BG_ROOT" "$BG_BUILD" <<'PY'
import pathlib,sys,xml.etree.ElementTree as ET
root,build=map(pathlib.Path,sys.argv[1:])
ET.register_namespace('android','http://schemas.android.com/apk/res/android')
tree=ET.parse(root/'app/src/main/AndroidManifest.xml')
tree.getroot().set('package','com.badgenesis.app')
tree.write(build/'AndroidManifest.xml',encoding='utf-8',xml_declaration=True)
PY
printf 'Compiling Android 16 resources\n'
"$BG_SDK_BIN/aapt2" compile --dir "$BG_ROOT/app/src/main/res" -o "$BG_BUILD/resources.zip"
"$BG_SDK_BIN/aapt2" link -o "$BG_BUILD/resources.apk" -I "$BG_ANDROID_JAR" \
  --manifest "$BG_BUILD/AndroidManifest.xml" --min-sdk-version 26 --target-sdk-version 36 \
  --version-code 1 --version-name 1.0.0 --java "$BG_BUILD/generated" \
  -A "$BG_ROOT/app/src/main/assets" "$BG_BUILD/resources.zip"
python3 - "$BG_ROOT" "$BG_BUILD" <<'PY'
import pathlib,sys
root,build=map(pathlib.Path,sys.argv[1:])
sources=sorted((root/'app/src/main/java').rglob('*.java'))+sorted((build/'generated').rglob('*.java'))
(build/'sources.txt').write_text('\n'.join('"'+str(p)+'"' for p in sources)+'\n')
PY
printf 'Compiling Java 17 Android integration\n'
java -Xmx1024m -jar "$BG_TOOLS/downloads/ecj-3.42.0.jar" -17 -proc:none \
  -bootclasspath "$BG_ANDROID_JAR" -d "$BG_BUILD/classes" @"$BG_BUILD/sources.txt"
python3 - "$BG_BUILD" <<'PY'
import pathlib,sys,zipfile
build=pathlib.Path(sys.argv[1]); classes=build/'classes'
with zipfile.ZipFile(build/'classes.jar','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(classes.rglob('*.class')):z.write(p,p.relative_to(classes))
PY
printf 'Converting Java bytecode for Android API 26 and later\n'
"$BG_SDK_BIN/d8" --release --min-api 26 --lib "$BG_ANDROID_JAR" \
  --output "$BG_BUILD/dex" "$BG_BUILD/classes.jar"
python3 - "$BG_BUILD" <<'PY'
import pathlib,shutil,sys,zipfile
build=pathlib.Path(sys.argv[1]);apk=build/'unaligned.apk'
shutil.copyfile(build/'resources.apk',apk)
with zipfile.ZipFile(apk,'a',zipfile.ZIP_DEFLATED) as z:
    for p in sorted((build/'dex').glob('*.dex')):z.write(p,p.name)
PY
"$BG_SDK_BIN/zipalign" -P 16 -f 4 "$BG_BUILD/unaligned.apk" "$BG_BUILD/aligned.apk"
BG_KEY="$BG_ROOT/signing/badgenesis-development.keystore"
if [ ! -f "$BG_KEY" ]; then
  keytool -genkeypair -keystore "$BG_KEY" -storetype JKS \
    -storepass badgenesis-development -keypass badgenesis-development \
    -alias badgenesis -keyalg RSA -keysize 3072 -validity 10000 \
    -dname 'CN=BadGenesis Development, OU=Development, O=BadGenesis, C=US'
fi
printf 'Signing the test APK\n'
"$BG_SDK_BIN/apksigner" sign --ks "$BG_KEY" --ks-key-alias badgenesis \
  --ks-pass pass:badgenesis-development --key-pass pass:badgenesis-development \
  --min-sdk-version 26 --out "$BG_DIST/BadGenesis-Android16.apk" "$BG_BUILD/aligned.apk"
"$BG_SDK_BIN/apksigner" verify --verbose --print-certs "$BG_DIST/BadGenesis-Android16.apk"
"$BG_SDK_BIN/zipalign" -c -P 16 4 "$BG_DIST/BadGenesis-Android16.apk"
"$BG_SDK_BIN/aapt2" dump badging "$BG_DIST/BadGenesis-Android16.apk" > "$BG_DIST/apk-badging.txt"
python3 - "$BG_DIST/BadGenesis-Android16.apk" <<'PY'
import hashlib,pathlib,sys
apk=pathlib.Path(sys.argv[1]); print('Built '+str(apk))
print('APK bytes: '+str(apk.stat().st_size))
print('SHA-256: '+hashlib.sha256(apk.read_bytes()).hexdigest())
PY

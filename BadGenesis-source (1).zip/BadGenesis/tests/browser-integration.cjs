'use strict';
// Executes the shipped HTML and its script tags in real Chromium. Android JNI /
// AudioTrack are represented by observable bridges; physical-device behavior
// is explicitly outside this browser check.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
const {chromium}=require('/opt/codex/runtimes/cua/lib/node_modules/playwright');
const root=path.resolve(__dirname,'..'),out=path.join(root,'test-results');
fs.mkdirSync(out,{recursive:true});
const report={scope:'Shipped HTML in Chromium with Android bridge capture; not a physical Android/AudioTrack test',checks:[],errors:[],consoleErrors:[],screenshots:[]};
function check(name,details){report.checks.push({name,...details});console.log('PASS '+name);}
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-dev-shm-usage','--allow-file-access-from-files']});
 try{
  const context=await browser.newContext({viewport:{width:960,height:540},deviceScaleFactor:1,hasTouch:true,isMobile:true});
  await context.addInitScript(()=>{
   window.nativeCalls=[];window.nativePCM=[];
   window.AndroidApp={setOrientation:x=>nativeCalls.push(['orientation',x]),enterGameplay:()=>nativeCalls.push(['fullscreen',true]),exitGameplay:()=>nativeCalls.push(['fullscreen',false]),setVibrationEnabled:x=>nativeCalls.push(['vibrationEnabled',x]),vibrate:x=>nativeCalls.push(['vibrate',x]),copyText:()=>{},exportFile:()=>{}};
   window.AndroidAudio={setEnabled:x=>nativeCalls.push(['audioEnabled',x]),flush:()=>nativeCalls.push(['audioFlush']),writePCM:x=>{nativePCM.push(x);if(nativePCM.length>120)nativePCM.shift()}};
  });
  const page=await context.newPage();page.on('pageerror',e=>report.errors.push(e.message));page.on('console',m=>{if(m.type()==='error')report.consoleErrors.push(m.text())});
  await page.goto(pathToFileURL(path.join(root,'app/src/main/assets/BadGenesis.html')).href);
  await page.waitForFunction(()=>document.body.classList.contains('android-home'));
  assert.deepEqual(report.errors,[]);check('shipped script includes load without runtime exceptions');
  await page.screenshot({path:path.join(out,'android-home.png')});report.screenshots.push('android-home.png');
  await page.locator('#androidLoad').click();await page.locator('#fileInput').setInputFiles(path.join(__dirname,'diagnostic.bin'));
  await page.waitForFunction(()=>typeof machine!=='undefined'&&machine.frames>=5&&document.body.classList.contains('gameplay'));
  const startup=await page.evaluate(()=>({running:machine.running,frames:machine.frames,signature:machine.bus.zram[0x1ff0],fm:machine.bus.ym[0xa0],psg:machine.audio.psg.tone,pcm:nativePCM.length,filter:getComputedStyle(document.querySelector('#screen')).filter,imageRendering:getComputedStyle(document.querySelector('#screen')).imageRendering,smooth:machine.vdp.ctx.imageSmoothingEnabled,nativeFullscreen:nativeCalls.some(c=>c[0]==='fullscreen'&&c[1])}));
  assert.equal(startup.running,true);assert.equal(startup.signature,0x42);assert.equal(startup.fm,0x69);assert.equal(startup.psg[0],261);assert.ok(startup.pcm>=5);assert.equal(startup.filter,'none');assert.ok(['pixelated','crisp-edges'].includes(startup.imageRendering));assert.equal(startup.nativeFullscreen,true);check('ROM file picker, real CPU/VDP/Z80/FM/PSG, native PCM and fullscreen gameplay',startup);
  const cdp=await context.newCDPSession(page);
  const rect=await page.locator('#mobileDpad').boundingBox(),ar=await page.locator('#mobileFace [data-key=a]').boundingBox(),br=await page.locator('#mobileFace [data-key=b]').boundingBox();
  const direction={id:1,x:rect.x+rect.width*.82,y:rect.y+rect.height*.18},a={id:2,x:ar.x+ar.width/2,y:ar.y+ar.height/2},b={id:3,x:br.x+br.width/2,y:br.y+br.height/2};
  await cdp.send('Input.dispatchTouchEvent',{type:'touchStart',touchPoints:[direction,a,b]});
  assert.deepEqual(await page.evaluate(()=>[machine.pad.keys.up,machine.pad.keys.right,machine.pad.keys.a,machine.pad.keys.b]),[true,true,true,true]);
  await cdp.send('Input.dispatchTouchEvent',{type:'touchMove',touchPoints:[{...direction,x:rect.x+rect.width*.18,y:rect.y+rect.height*.82},a,b]});
  assert.deepEqual(await page.evaluate(()=>[machine.pad.keys.down,machine.pad.keys.left,machine.pad.keys.a,machine.pad.keys.b]),[true,true,true,true]);
  await cdp.send('Input.dispatchTouchEvent',{type:'touchEnd',touchPoints:[]});assert.equal(await page.evaluate(()=>Object.values(machine.pad.keys).some(Boolean)),false);check('Chromium real multitouch events: diagonals plus two held action buttons');
  await page.screenshot({path:path.join(out,'android-landscape-gameplay.png')});report.screenshots.push('android-landscape-gameplay.png');
  const random=await page.evaluate(()=>{RTC.auto=false;document.querySelector('#rtcMode').value='random';document.querySelector('#rtcStart').value='8000';document.querySelector('#rtcEnd').value='BFFF';document.querySelector('#rtcIntensity').value='12';for(let i=0;i<8;i++)rtcBlast();const seeds=RTC.history.slice(-8).map(h=>h.seed);document.querySelector('#rtcAutoFrames').value='2';RTC.auto=true;for(let i=0;i<8;i++)machine.runFrame();RTC.auto=false;return {seeds,auto:RTC.history.slice(-4).map(h=>({seed:h.seed,frame:h.frame})),allRandom:RTC.history.every(h=>h.random),audioCount:nativePCM.length}});
  assert.equal(new Set(random.seeds).size,8);assert.equal(new Set(random.auto.map(h=>h.seed)).size,4);assert.equal(random.allRandom,true);check('fresh normal and emulated-frame Auto Blast randomness',random);
  await page.evaluate(()=>{rtcSetClean();rtcCapture();rtcBlast();machine.runFrame();rtcCapture();rtcRewindStart();rtcRewindStep();rtcRewindStop();rtcRestoreClean()});
  await page.waitForFunction(()=>machine.running&&!machine.paused&&nativePCM.length>0);check('RTC blast and rewind restore complete sound-bearing machine state');
  await page.setViewportSize({width:412,height:915});await page.screenshot({path:path.join(out,'android-portrait-gameplay.png')});report.screenshots.push('android-portrait-gameplay.png');
  const portrait=await page.evaluate(()=>{const ids=['mobileDpad','mobileFace','mobileMeta'];return ids.map(id=>{const r=document.getElementById(id).getBoundingClientRect();return{id,x:r.x,y:r.y,right:r.right,bottom:r.bottom}})});assert.ok(portrait.every(r=>r.x>=-1&&r.y>=0&&r.right<=413&&r.bottom<=916));check('portrait control groups stay on screen',{groups:portrait});
  await page.locator('#mobileMenu').click();await page.locator('#androidOptions').click();await page.locator('#controlButtons').selectOption('3');await page.locator('#controlVibration').selectOption('on');await page.locator('#controlSize').evaluate(e=>{e.value='130';e.dispatchEvent(new Event('input',{bubbles:true}))});await page.locator('#controlOpacity').evaluate(e=>{e.value='40';e.dispatchEvent(new Event('input',{bubbles:true}))});
  const prefs=await page.evaluate(()=>JSON.parse(localStorage.getItem('badgenesis:controls:v1')));assert.equal(prefs.buttons,'3');assert.equal(prefs.vibration,true);assert.equal(prefs.size,130);assert.equal(prefs.opacity,40);check('phone settings persist controller size/opacity/3-button/vibration');
  await page.screenshot({path:path.join(out,'android-options.png')});report.screenshots.push('android-options.png');
  await page.locator('#androidHome').click();await page.locator('#androidRtc').click();await page.screenshot({path:path.join(out,'android-rtc.png'),fullPage:true});report.screenshots.push('android-rtc.png');
  const text=await page.locator('body').innerText();assert.doesNotMatch(text,/\b(carica|caricato|caricata|scarica|accendi|spegni|nessun|nessuna|riprendi|pausa|istruzioni|trovate|italiano|ripristinati|rilevato|collegato|direzioni)\b/i);check('rendered interface text is English');
  assert.deepEqual(report.errors,[]);assert.deepEqual(report.consoleErrors,[]);check('no browser runtime or console errors during gameplay, RTC and menus');
  await context.close();
 }catch(error){report.failure=error.stack;throw error}
 finally{await browser.close();fs.writeFileSync(path.join(out,'browser-report.json'),JSON.stringify(report,null,2)+'\n')}
 console.log(JSON.stringify({report:path.join(out,'browser-report.json'),checks:report.checks.length,screenshots:report.screenshots}));
})().catch(error=>{console.error(error.stack);process.exitCode=1});

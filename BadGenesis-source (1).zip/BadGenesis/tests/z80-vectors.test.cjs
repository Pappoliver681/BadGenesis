const fs=require('node:fs');const Z80=require('../app/src/main/assets/z80.js');
const toFlags=f=>({S:f>>7&1,Z:f>>6&1,Y:f>>5&1,H:f>>4&1,X:f>>3&1,P:f>>2&1,N:f>>1&1,C:f&1});
const fromFlags=f=>f.S<<7|f.Z<<6|f.Y<<5|f.H<<4|f.X<<3|f.P<<2|f.N<<1|f.C;
let total=0,failed=0;
const vectors=require('./z80-vectors.json');
for(const file of Object.keys(vectors)) {
 let fails=0, examples=[];
 for(const test of vectors[file]) {
  const ram=new Uint8Array(65536);for(const [a,v] of test.initial.ram)ram[a]=v;
  const ports=[];
  const cpu=new Z80(a=>ram[a],(a,v)=>ram[a]=v,p=>(test.ports||[]).find(x=>x[0]===p&&x[2]==='r')?.[1]??255,(p,v)=>ports.push([p,v,'w']));
  const src=test.initial;
  const s={...cpu.state(),...src,flags:toFlags(src.f),flags_prime:toFlags(src.af_&255),imode:src.im,do_delayed_ei:!!src.ei};
  for(const pair of ['af','bc','de','hl']) {s[pair[0]+'_prime']=src[pair+'_']>>8;s[pair[1]+'_prime']=src[pair+'_']&255;}
  cpu.loadState(s);const cycles=cpu.step();const out=cpu.state();
  let errs=[];for(const key of ['a','b','c','d','e','h','l','i','r','ix','iy','pc','sp','iff1','iff2','wz','q','p'])if(out[key]!==test.final[key])errs.push(`${key}:${out[key]}/${test.final[key]}`);
  if(fromFlags(out.flags)!==test.final.f)errs.push(`f:${fromFlags(out.flags)}/${test.final.f}`);
  if(cycles!==test.cycles.length)errs.push(`cycles:${cycles}/${test.cycles.length}`);
  for(const [a,v] of test.final.ram)if(ram[a]!==v)errs.push(`RAM ${a}:${ram[a]}/${v}`);
  if(JSON.stringify(ports)!==JSON.stringify((test.ports||[]).filter(x=>x[2]==='w')))errs.push('I/O writes');
  if(errs.length){fails++;if(examples.length<2)examples.push({name:test.name,errors:errs});}
  total++;
 }
 failed+=fails;if(fails)console.log(file,'FAIL '+fails+' '+JSON.stringify(examples));
}
console.log(`Z80 independent reference vectors: ${total} tested, ${failed} failed.`);process.exitCode=failed?1:0;

'use strict';
const assert = require('node:assert/strict');
const GenesisZ80 = require('../app/src/main/assets/z80.js');
function machine(program = []) {
  const ram = new Uint8Array(65536);
  ram.set(program);
  const io = [];
  const cpu = new GenesisZ80(a => ram[a], (a,v) => ram[a] = v, () => 0xa5, (p,v) => io.push([p,v]));
  return {cpu, ram, io};
}
function set(cpu, patch) { cpu.loadState(Object.assign(cpu.state(),patch)); }
function flags(cpu) { const f=cpu.state().flags;return f.S<<7|f.Z<<6|f.Y<<5|f.H<<4|f.X<<3|f.P<<2|f.N<<1|f.C; }
// Primary instructions, stack and signed relative control flow.
{
  const {cpu,ram}=machine([0x31,0,0x20,0x3e,0x7f,0xc6,1,0xf5,0xaf,0xf1,0x76]);
  assert.deepEqual(Array.from({length:7},()=>cpu.step()),[10,7,7,11,4,10,4]);
  assert.equal(cpu.state().a,0x80); assert.equal(flags(cpu),0x94);
  assert.equal(cpu.state().sp,0x2000); assert.equal(ram[0x1fff],0x80);
  const r=cpu.state().r;assert.equal(cpu.step(),4);assert.equal(cpu.state().r,r+1);
}
// CB rotate / bit / set / reset on both registers and memory.
{
  const {cpu,ram}=machine([0x06,0x81,0xcb,0,0xcb,0x78,0xcb,0xc0,0xcb,0x80,0x21,0,0x20,0xcb,6]);
  ram[0x2000]=0x80;
  assert.equal(cpu.step(),7);assert.equal(cpu.step(),8);assert.equal(cpu.state().b,3);
  assert.equal(cpu.step(),8);assert.equal(cpu.state().flags.Z,1);
  cpu.step();cpu.step();assert.equal(cpu.state().b,2);
  cpu.step();assert.equal(cpu.step(),15);assert.equal(ram[0x2000],1);
}
// IX/IY and indexed CB register copies, signed displacement and correct cycles.
{
  const {cpu,ram}=machine([0xdd,0x21,0,0x20,0xfd,0x21,0,0x30,0xdd,0x36,0xff,0x81,0xdd,0xcb,0xff,0,
    0xfd,0x36,2,0x80,0xfd,0xcb,2,0x7e,0xfd,0xcb,2,0xbe]);
  assert.equal(cpu.step(),14);assert.equal(cpu.step(),14);
  assert.equal(cpu.step(),19);assert.equal(cpu.step(),23);
  assert.equal(ram[0x1fff],3);assert.equal(cpu.state().b,3);
  assert.equal(cpu.step(),19);assert.equal(cpu.step(),20);
  assert.equal(cpu.state().flags.Z,0);assert.equal(cpu.step(),23);
  assert.equal(ram[0x3002],0);assert.equal(cpu.state().ix,0x2000);assert.equal(cpu.state().iy,0x3000);
}
// ED block move repeat, arithmetic, I/O and undefined opcodes.
{
  const {cpu,ram,io}=machine([0xed,0xb0,0xed,0x4a,0xed,0x79,0xed,0x78,0xed,0]);
  set(cpu,{h:0x20,l:0,d:0x30,e:0,b:0,c:3,a:0x5a});ram.set([1,2,3],0x2000);
  assert.equal(cpu.step(),21);assert.equal(cpu.step(),21);assert.equal(cpu.step(),16);
  assert.deepEqual(Array.from(ram.slice(0x3000,0x3003)),[1,2,3]);assert.equal(cpu.state().pc,2);
  assert.equal(cpu.step(),15);assert.equal(cpu.step(),12);assert.deepEqual(io,[[0,0x5a]]);
  assert.equal(cpu.step(),12);assert.equal(cpu.state().a,0xa5);assert.equal(cpu.step(),8);
}
// Prefixes belong to one instruction. Last index prefix wins; ED ignores it.
{
  const {cpu}=machine([0xdd,0xfd,0x21,0x34,0x12,0xdd,0xed,0x47,0xdd,0x3e,0x42]);
  set(cpu,{a:0x19});assert.equal(cpu.step(),18);assert.equal(cpu.state().iy,0x1234);assert.equal(cpu.state().ix,0);
  assert.equal(cpu.step(),13);assert.equal(cpu.state().i,0x19);
  assert.equal(cpu.step(),11);assert.equal(cpu.state().a,0x42);assert.equal(cpu.state().pc,11);
}
// EI inhibits INT for one instruction; DI is immediate; HALT exits on accepted INT.
{
  const {cpu,ram}=machine([0xfb,0,0x76]);set(cpu,{imode:1,sp:0x2000});
  cpu.step();cpu.interrupt();assert.equal(cpu.step(),4);assert.equal(cpu.state().pc,2);
  cpu.step();assert.equal(cpu.state().halted,true);
  cpu.interrupt();assert.equal(cpu.step(),17);assert.equal(cpu.state().pc,0x39);
  assert.equal(ram[0x1ffe],3);assert.equal(ram[0x1fff],0);assert.equal(cpu.state().iff1,0);
  ram[0x39]=0xf3;set(cpu,{iff1:1,iff2:1});cpu.step();cpu.interrupt();cpu.step();assert.equal(cpu.state().pc,0x3b);
}
// EI then DI must not re-enable IFF; IM 2 uses a little endian vector.
{
  const {cpu,ram}=machine([0xfb,0xf3,0]);cpu.step();cpu.step();assert.equal(cpu.state().iff1,0);
  set(cpu,{iff1:1,iff2:1,imode:2,i:0x20,sp:0x4000});ram[0x20ff]=0;ram[0x2100]=0x30;
  cpu.interrupt();assert.equal(cpu.step(),23);assert.equal(cpu.state().pc,0x3001);
}
// NMOS LD A,I interrupt race and its full-state latch are preserved.
{
  const {cpu}=machine([0xed,0x57,0]);set(cpu,{iff1:1,iff2:1,imode:1,i:0x80});
  assert.equal(cpu.step(),9);assert.equal(cpu.state().flags.P,1);assert.equal(cpu.state().p,1);
  const saved=cpu.state();cpu.interrupt();cpu.step();assert.equal(cpu.state().flags.P,0);
  cpu.loadState(saved);cpu.step();assert.equal(cpu.state().flags.P,1);assert.equal(cpu.state().p,0);
}
// Save/load including an armed IRQ and a corruption-created repeated prefix stream.
{
  const {cpu,ram}=machine();ram.fill(0xdd);assert.equal(cpu.step(),256);
  let state=cpu.state();assert.equal(state.pending_index,0xdd);assert.equal(state.pc,64);
  cpu.loadState(state);ram[64]=0x21;ram[65]=0x34;ram[66]=0x12;
  assert.equal(cpu.step(),10);assert.equal(cpu.state().ix,0x1234);
  ram[67]=0xfb;ram[68]=0;cpu.step();cpu.step();cpu.interrupt();
  state=cpu.state();const before=ram.slice();cpu.step();const expected=cpu.state();const after=ram.slice();
  ram.set(before);cpu.loadState(JSON.parse(JSON.stringify(state)));cpu.step();
  assert.deepEqual(cpu.state(),expected);assert.deepEqual(ram,after);
}
// Every opcode and prefix group must consume cycles without throwing after RTC writes.
for (const prefix of [[],[0xcb],[0xed],[0xdd],[0xfd],[0xdd,0xcb,0],[0xfd,0xcb,0]]) {
  for(let opcode=0;opcode<256;opcode++) {
    const {cpu}=machine([...prefix,opcode,0,0,0,0]);set(cpu,{b:1,c:1,h:0x20,l:0,ix:0x2000,iy:0x3000});
    const cycles=cpu.step();assert.ok(Number.isFinite(cycles)&&cycles>0,`${prefix}/${opcode}`);
  }
}
console.log('Z80 instruction families, timing, interrupt behavior and state replay passed (1,792 opcode paths).');

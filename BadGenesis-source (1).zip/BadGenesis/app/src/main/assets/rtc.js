// BADGENESIS RTC: original memory domains and emulator, with complete state timelines.
'use strict';
const RTC = {
  frame: 0, blast: 0, auto: false, undo: null, history: [], rewind: [], rewindBytes: 0,
  rewindLimit: 64 * 1024 * 1024, rewinding: false, rewTimer: 0, rewindResume: false,
  rewindStateBytes: 0, rewindLastFrame: 0, rewindInterval: 0,
  quick: null, clean: null, recovery: null, kept: [], keptBytes: 0,
  originalRom: null, romName: '', lastSeed: null, randomCounter: 0,
  historySession: '', preserveRewindOnLoad: false, recoveryPersistAt: 0,
  domainConfig: { global: { start: '', end: '', exclusions: '' } }, rangeScope: 'global'
};
const rtcStatus = text => { const e = $('#rtcStatus'); if (e) e.textContent = text; };
const rtcValue = (id, fallback = '') => $('#' + id)?.value ?? fallback;
function rtcHash(s) { let h = 0x811c9dc5; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 0x01000193); } return h >>> 0; }
function rtcRng(seed) { let x = (seed >>> 0) || 0x9e3779b9; return () => { x ^= x << 13; x ^= x >>> 17; x ^= x << 5; return x >>> 0; }; }
function rtcHex(value, fallback) { const s = String(value ?? '').trim().replace(/^0x/i, '').replace(/^\$/, ''); return /^[0-9a-f]+$/i.test(s) ? parseInt(s, 16) : fallback; }
function rtcSeedFromText(text) { const s = String(text).trim(); return /^0x[0-9a-f]{1,8}$/i.test(s) ? parseInt(s.slice(2), 16) >>> 0 : rtcHash(s); }
function rtcFreshSeed() {
  const a = new Uint32Array(2); RTC.randomCounter++;
  if (globalThis.crypto?.getRandomValues) crypto.getRandomValues(a);
  else { a[0] = Math.random() * 0x100000000; a[1] = rtcHash(Date.now() + ':' + performance.now() + ':' + RTC.randomCounter); }
  let seed = (a[0] ^ a[1] ^ Math.imul(RTC.randomCounter, 0x9e3779b9)) >>> 0;
  if (!seed || seed === RTC.lastSeed) seed = ((RTC.lastSeed || 0x9e3779b9) + 0x6d2b79f5) >>> 0;
  RTC.lastSeed = seed; return seed;
}
function rtcRomIdentity(bytes) {
  let a = 0x811c9dc5, b = 0x9e3779b9;
  for (let i = 0; i < bytes.length; i++) { a = Math.imul(a ^ bytes[i], 0x01000193); b = Math.imul(b ^ bytes[i], 0x85ebca6b); b = (b << 13) | (b >>> 19); }
  return bytes.length.toString(16) + ':' + (a >>> 0).toString(16).padStart(8, '0') + ':' + (b >>> 0).toString(16).padStart(8, '0');
}
function rtcEnsureOriginal(m = machine) {
  if (!m.rom) return;
  if (!m._rtcOriginalRom) {
    m._rtcOriginalRom = m.rom.slice(); m._rtcRomIdentity = rtcRomIdentity(m._rtcOriginalRom);
    m._rtcBaseChecksum = checksum16(m._rtcOriginalRom); m._rtcPatches = new Map(); m._rtcPatchCache = null;
  }
}
function rtcRomWrite(m, index, value) {
  rtcEnsureOriginal(m); value &= 255; m.rom[index] = value;
  if (value === m._rtcOriginalRom[index]) m._rtcPatches.delete(index); else m._rtcPatches.set(index, value);
  m._rtcPatchCache = null;
}
function rtcRomPatches(m) {
  rtcEnsureOriginal(m); if (m._rtcPatchCache) return m._rtcPatchCache;
  const entries = [...m._rtcPatches].sort((a, b) => a[0] - b[0]), patches = [];
  for (let i = 0; i < entries.length;) {
    const start = entries[i][0], bytes = [entries[i++][1]];
    while (i < entries.length && entries[i][0] === start + bytes.length) bytes.push(entries[i++][1]);
    patches.push([start, b64(new Uint8Array(bytes))]);
  }
  return m._rtcPatchCache = patches;
}
function rtcDecode(value) { if (value instanceof Uint8Array) return value; if (typeof value !== 'string') throw Error('Invalid state memory block.'); return unb64(value); }
function rtcApplyRomPatches(m, patches) {
  const decoded = (patches || []).map(p => {
    if (!Array.isArray(p) || !Number.isInteger(p[0]) || p[0] < 0) throw Error('Invalid ROM patch.');
    const bytes = rtcDecode(p[1]); if (p[0] + bytes.length > m.rom.length) throw Error('ROM patch is outside this ROM.'); return [p[0], bytes];
  });
  for (const i of m._rtcPatches.keys()) m.rom[i] = m._rtcOriginalRom[i];
  m._rtcPatches.clear();
  for (const [start, bytes] of decoded) for (let i = 0; i < bytes.length; i++) rtcRomWrite(m, start + i, bytes[i]);
  m._rtcPatchCache = null;
}
function rtcPrimitives(obj) { const result = {}; for (const [k, v] of Object.entries(obj)) if (!k.startsWith('_rtc') && (v === null || ['number', 'boolean', 'string'].includes(typeof v))) result[k] = v; return result; }
function rtcRestorePrimitives(target, values) {
  const allowed = rtcPrimitives(target);
  for (const [key, value] of Object.entries(values || {})) if (Object.hasOwn(allowed, key) && (value === null || ['number', 'boolean', 'string'].includes(typeof value))) target[key] = value;
}

// Compose with the actual emulator and the audio state wrapper. Saved ROMs are patches to
// an untouched, identified source ROM; the original file is never written or replaced.
const rtcOrigState = MegaDrive.prototype.state;
MegaDrive.prototype.state = function () {
  rtcEnsureOriginal(this); const s = rtcOrigState.call(this);
  s.rtcState = {
    version: 3, romIdentity: this._rtcRomIdentity, originalChecksum: this._rtcBaseChecksum,
    romPatches: rtcRomPatches(this), frame: this === machine ? RTC.frame : this.frames,
    blastCursor: RTC.blast, historySession: RTC.historySession,
    activeBlasts: RTC.history.filter(h => h.active !== false).map(h => h.n),
    machine: rtcPrimitives(this), cpu: rtcPrimitives(this.cpu), vdp: rtcPrimitives(this.vdp),
    bus: rtcPrimitives(this.bus), ym: b64(this.bus.ym), ymAddr: b64(this.bus.ymAddr),
    framebufferWidth: this.vdp.img.width, framebuffer: b64(this.vdp.pixels)
  };
  return s;
};
const rtcOrigLoadState = MegaDrive.prototype.loadState;
MegaDrive.prototype.loadState = function (state) {
  if (!this.rom) throw Error('Load the matching ROM first.'); rtcEnsureOriginal(this);
  const extra = state?.rtcState;
  if (extra && extra.romIdentity !== this._rtcRomIdentity) throw Error('This state belongs to a different original ROM.');
  if (!state?.cpu || !state?.bus || !state?.vdp || state.cpu.D?.length !== 8 || state.cpu.A?.length !== 8) throw Error('Invalid Genesis state.');
  const blocks = { ram: rtcDecode(state.bus.ram), zram: rtcDecode(state.bus.zram), vram: rtcDecode(state.vdp.vram), sram: state.sram == null ? null : rtcDecode(state.sram) };
  if (blocks.ram.length !== this.bus.ram.length || blocks.zram.length !== this.bus.zram.length || blocks.vram.length !== this.vdp.vram.length || state.vdp.cram?.length !== this.vdp.cram.length || state.vdp.vsram?.length !== this.vdp.vsram.length || state.vdp.reg?.length !== this.vdp.reg.length || (blocks.sram && blocks.sram.length !== this.sram?.length)) throw Error('State memory sizes do not match this cartridge.');
  let fb = null, ym = null, ymAddr = null;
  if (extra) {
    if (extra.framebuffer) { fb = rtcDecode(extra.framebuffer); if (![256, 320].includes(extra.framebufferWidth) || fb.length !== extra.framebufferWidth * 224 * 4) throw Error('Invalid state framebuffer.'); }
    if (extra.ym) { ym = rtcDecode(extra.ym); if (ym.length !== this.bus.ym.length) throw Error('Invalid YM2612 state.'); }
    if (extra.ymAddr) { ymAddr = rtcDecode(extra.ymAddr); if (ymAddr.length !== this.bus.ymAddr.length) throw Error('Invalid YM2612 address state.'); }
    rtcApplyRomPatches(this, extra.romPatches);
  } else if (state.romChecksum !== checksum16(this.rom)) {
    // Legacy states saved before ROM corruption may still be restored against the base.
    if (state.romChecksum !== this._rtcBaseChecksum) throw Error('State/ROM mismatch.');
    rtcApplyRomPatches(this, []);
  }
  const decodedState = { ...state, romChecksum: checksum16(this.rom), bus: { ...state.bus, ram: b64(blocks.ram), zram: b64(blocks.zram) }, vdp: { ...state.vdp, vram: b64(blocks.vram) }, sram: blocks.sram ? b64(blocks.sram) : null };
  rtcOrigLoadState.call(this, decodedState);
  if (extra) {
    rtcRestorePrimitives(this.cpu, extra.cpu); rtcRestorePrimitives(this.bus, extra.bus);
    if (ym) this.bus.ym.set(ym); if (ymAddr) this.bus.ymAddr.set(ymAddr);
    // A rendered frame may contain scanline changes which cannot be recreated from final registers.
    if (fb) { this.vdp.ensureBuffer(extra.framebufferWidth); this.vdp.pixels.set(fb); this.vdp.endFrame(); }
    rtcRestorePrimitives(this.vdp, extra.vdp); rtcRestorePrimitives(this, extra.machine);
    if (this === machine) {
      RTC.frame = extra.frame ?? this.frames;
      // Undo records belong to this running timeline. Imported states may have
      // the same blast numbers, but cannot safely use another session's byte undo.
      const active = new Set(extra.historySession === RTC.historySession ? extra.activeBlasts || [] : []);
      for (const h of RTC.history) h.active = active.has(h.n);
      RTC.undo = RTC.history.findLast ? RTC.history.findLast(h => h.active !== false) : [...RTC.history].reverse().find(h => h.active !== false);
      rtcHistoryRender();
    }
  } else {
    this.cpu.pendingIRQ = 0; this.vdp.latch = null;
    if (this === machine) {
      RTC.frame = this.vdp.frame || 0; RTC.undo = null;
      for (const h of RTC.history) h.active = false;
      rtcHistoryRender();
    }
  }
  // State loads intentionally pause. Quick load, recovery and rewind choose whether to resume.
  this.powered = true; this.running = true; this.paused = true;
  if (this === machine) {
    if (!RTC.rewinding && !RTC.preserveRewindOnLoad) rtcClearRewind();
    last = performance.now(); acc = 0;
  }
};
const rtcOrigSramKey = MegaDrive.prototype.sramKey;
MegaDrive.prototype.sramKey = function () {
  if (this._rtcOriginalRom) return 'mdjsd:sram:' + this._rtcBaseChecksum.toString(16).padStart(4, '0') + ':' + this._rtcOriginalRom.length;
  return rtcOrigSramKey.call(this);
};

function rtcWordDomain(key, label, arr) { return { key, label, size: arr.length * 2, get(i) { const w = arr[i >> 1]; return (i & 1) ? w & 255 : w >>> 8; }, set(i, v) { const j = i >> 1, w = arr[j]; arr[j] = (i & 1) ? (w & 0xff00) | (v & 255) : ((v & 255) << 8) | (w & 255); } }; }
function rtcByteDomain(key, label, arr) { return { key, label, size: arr?.length || 0, get: i => arr[i], set: (i, v) => { arr[i] = v & 255; } }; }
function rtcDomains() {
  const d = { ram: rtcByteDomain('ram', '68000 Work RAM', machine.bus.ram), zram: rtcByteDomain('zram', 'Z80 RAM', machine.bus.zram), vram: rtcByteDomain('vram', 'VRAM', machine.vdp.vram), cram: rtcWordDomain('cram', 'CRAM', machine.vdp.cram), vsram: rtcWordDomain('vsram', 'VSRAM', machine.vdp.vsram) };
  if (machine.sram) {
    d.sram = rtcByteDomain('sram', 'SRAM', machine.sram);
    d.sram.set = (i, v) => { machine.sram[i] = v & 255; machine.sramDirty = true; };
  }
  if (machine.rom) { d.rom = rtcByteDomain('rom', 'ROM copy', machine.rom); d.rom.set = (i, v) => rtcRomWrite(machine, i, v); }
  return d;
}
function rtcSelected() { return $$('[data-rtc-domain]:checked').map(x => x.dataset.rtcDomain); }
function rtcRemember(map, domain, index) { const k = domain.key + ':' + index; if (!map.has(k)) map.set(k, { domain: domain.key, index, old: domain.get(index) }); }
function rtcWrite(map, domain, index, value) { if (index < 0 || index >= domain.size) return; rtcRemember(map, domain, index); domain.set(index, value); }
function rtcParseExclusions(text) {
  return String(text || '').replace(/!/g, '').split(/[,;\s]+/).filter(Boolean).map(token => {
    const p = token.split('-'), a = rtcHex(p[0], NaN), b = p.length > 1 ? rtcHex(p[1], NaN) : a;
    if (p.length > 2 || !Number.isFinite(a) || !Number.isFinite(b) || b < a) throw Error('Invalid exclusion: ' + token + '. Use hex offsets such as 0000-001F,0200.');
    return [a, b];
  });
}
function rtcSaveRangeFields() { RTC.domainConfig[RTC.rangeScope] = { start: rtcValue('rtcStart'), end: rtcValue('rtcEnd'), exclusions: rtcValue('rtcExclusions') }; }
function rtcRangeScopeChanged() {
  rtcSaveRangeFields(); RTC.rangeScope = rtcValue('rtcRangeDomain', 'global');
  const c = RTC.domainConfig[RTC.rangeScope] || { start: '', end: '', exclusions: '' };
  for (const [id, key] of [['rtcStart', 'start'], ['rtcEnd', 'end'], ['rtcExclusions', 'exclusions']]) if ($('#' + id)) $('#' + id).value = c[key];
}
function rtcRangeConfig(key, size) {
  const global = RTC.domainConfig.global || {}, local = RTC.domainConfig[key] || {};
  let start = local.start || global.start || '', end = local.end || global.end || '';
  let exclusionText = [global.exclusions || '', local.exclusions || ''].filter(Boolean).join(',');
  for (const line of rtcValue('rtcDomainRanges').split('\n')) {
    if (!line.trim()) continue;
    const m = line.trim().match(/^([a-z]+)\s*:\s*([^!]*)(?:!\s*(.*))?$/i);
    if (!m || !['ram', 'zram', 'vram', 'cram', 'vsram', 'sram', 'rom'].includes(m[1].toLowerCase())) throw Error('Invalid domain range. Use ram: 0000-FFFF !0000-001F.');
    if (m[1].toLowerCase() !== key) continue;
    const range = m[2].trim().split('-'); if (range.length > 2) throw Error('Invalid address range for ' + key + '.');
    if (range[0]) start = range[0].trim(); if (range[1]) end = range[1].trim();
    if (m[3]) exclusionText += ',' + m[3];
  }
  if (start.trim() && !Number.isFinite(rtcHex(start, NaN))) throw Error('Invalid start address for ' + key + '.');
  if (end.trim() && !Number.isFinite(rtcHex(end, NaN))) throw Error('Invalid end address for ' + key + '.');
  return { start: rtcHex(start, 0), end: rtcHex(end, size - 1), exclusions: rtcParseExclusions(exclusionText) };
}
// Precompute legal aligned spans: a word can never cross the range, a domain boundary,
// or an excluded byte. Picks are independent and uniform across legal locations.
function rtcLegalPicker(domain, rand, width, start, end, exclusions = []) {
  let spans = [[Math.max(0, start || 0), Math.min(domain.size - 1, end == null ? domain.size - 1 : end)]];
  for (const [a, b] of exclusions) {
    const next = []; for (const [lo, hi] of spans) { if (b < lo || a > hi) next.push([lo, hi]); else { if (a > lo) next.push([lo, a - 1]); if (b < hi) next.push([b + 1, hi]); } } spans = next;
  }
  const alignment = width === 4 ? 4 : width === 2 ? 2 : 1, valid = []; let total = 0;
  for (const [lo, hi] of spans) { const first = Math.ceil(lo / alignment) * alignment, last = hi - width + 1, n = Math.floor((last - first) / alignment) + 1; if (n > 0) { valid.push({ first, n }); total += n; } }
  if (!total) return null;
  return () => { let pick = rand() % total; for (const s of valid) { if (pick < s.n) return s.first + pick * alignment; pick -= s.n; } return valid[0].first; };
}
function rtcMutationWidth(mode) { return mode === 'word32' ? 4 : (mode === 'word16' || mode === 'nop') ? 2 : 1; }
function rtcApplyMutation(domain, rand, mode, undo, pick) {
  const i = pick(), old = domain.get(i); let v = old;
  if (mode === 'bitflip') v = old ^ (1 << (rand() % 8));
  else if (mode === 'random') v = rand() & 255;
  else if (mode === 'tilt') { const delta = 1 + (rand() % 4); v = (old + ((rand() & 1) ? delta : -delta)) & 255; }
  else if (mode === 'add') v = (old + 1 + rand() % 31) & 255;
  else if (mode === 'sub') v = (old - 1 - rand() % 31) & 255;
  else if (mode === 'zero') v = 0;
  else if (mode === 'ff') v = 255;
  else if (mode === 'swap') { const j = pick(), b = domain.get(j); rtcWrite(undo, domain, i, b); rtcWrite(undo, domain, j, old); return 2; }
  else if (mode === 'word16' || mode === 'nop') { const w = mode === 'nop' ? 0x4e71 : rand() & 0xffff; rtcWrite(undo, domain, i, w >>> 8); rtcWrite(undo, domain, i + 1, w); return 2; }
  else if (mode === 'word32') { const w = rand(); for (let n = 0; n < 4; n++) rtcWrite(undo, domain, i + n, w >>> (24 - n * 8)); return 4; }
  else throw Error('Unknown corruption mode.');
  rtcWrite(undo, domain, i, v); return 1;
}
function rtcMutate(domain, rand, count, mode, start, end, undo, exclusions = []) {
  const pick = rtcLegalPicker(domain, rand, rtcMutationWidth(mode), start, end, exclusions); if (!pick) return 0;
  let writes = 0; for (let n = 0; n < count; n++) writes += rtcApplyMutation(domain, rand, mode, undo, pick); return writes;
}
function rtcHistoryRender() {
  const e = $('#rtcHistory'); if (!e) return;
  e.textContent = RTC.history.slice(-12).reverse().map(h => `${h.active === false ? '×' : '#'}${h.n} @F${h.frame} ${h.mode} [${h.domains.join(', ')}] ${h.operations ?? '?'} mutations / ${h.writes} byte writes`).join('\n');
}
function rtcBlast(auto = false) {
  if (!machine.rom || !machine.powered) return rtcStatus('Load a ROM and power it on first.');
  try {
    rtcSaveRangeFields(); const all = rtcDomains(), mode = rtcValue('rtcMode', 'bitflip');
    let keys = rtcSelected().filter(k => all[k]?.size); if (mode === 'nop') keys = keys.filter(k => k === 'ram' || k === 'rom');
    if (!keys.length) return rtcStatus(mode === 'nop' ? 'NOP mode targets 68000 Work RAM or the ROM copy.' : 'Select an available memory domain.');
    const manual = rtcValue('rtcSeedMode', 'random') === 'manual', seedText = rtcValue('rtcSeed') || 'BADGENESIS';
    const seed = manual ? rtcSeedFromText(seedText) : rtcFreshSeed(), rand = rtcRng(seed), eligible = [];
    for (const k of keys) { const range = rtcRangeConfig(k, all[k].size), pick = rtcLegalPicker(all[k], rand, rtcMutationWidth(mode), range.start, range.end, range.exclusions); if (pick) eligible.push({ domain: all[k], pick, range }); }
    if (!eligible.length) return rtcStatus('No writable addresses remain in the selected ranges and exclusions.');
    RTC.recovery = rtcSnapshot(); rtcPersistRecovery(auto);
    const total = clamp(parseInt(rtcValue('rtcIntensity', '24')) || 1, 1, 4096), undo = new Map(); let writes = 0;
    for (let n = 0; n < total; n++) { const e = eligible[rand() % eligible.length]; writes += rtcApplyMutation(e.domain, rand, mode, undo, e.pick); }
    const rec = { n: ++RTC.blast, frame: RTC.frame, seed: '0x' + seed.toString(16).padStart(8, '0'), seedValue: seed, seedText: manual ? seedText : null, random: !manual, mode, domains: eligible.map(e => e.domain.label), ranges: eligible.map(e => ({ domain: e.domain.key, ...e.range })), operations: total, writes, undo: [...undo.values()], active: true };
    RTC.undo = rec; RTC.history.push(rec); if (RTC.history.length > 100) RTC.history.shift();
    machine.vdp.render(); rtcHistoryRender();
    rtcStatus(`${auto ? 'AUTO ' : ''}BLAST #${rec.n}\nFrame ${rec.frame} · ${mode} · ${total} mutations / ${writes} byte writes\n${rec.domains.join(', ')}\n${manual ? 'Manual seed: ' + seedText : 'Fresh random corruption; reproduction seed recorded in history.'}`);
  } catch (e) { rtcStatus('Blast error: ' + e.message); }
}
function rtcUndo() {
  const r = RTC.undo; if (!r || r.active === false) return rtcStatus('Nothing to undo.');
  const all = rtcDomains(); for (let i = r.undo.length - 1; i >= 0; i--) { const c = r.undo[i], d = all[c.domain]; if (d && c.index < d.size) d.set(c.index, c.old); }
  r.active = false; RTC.undo = [...RTC.history].reverse().find(h => h.active !== false) || null;
  machine.vdp.render(); rtcHistoryRender(); rtcStatus(`Undid BLAST #${r.n}.`);
}

function rtcCompactState(state) {
  state.bus.ram = rtcDecode(state.bus.ram).slice(); state.bus.zram = rtcDecode(state.bus.zram).slice(); state.vdp.vram = rtcDecode(state.vdp.vram).slice();
  if (state.sram) state.sram = rtcDecode(state.sram).slice();
  if (state.rtcState?.framebuffer) state.rtcState.framebuffer = rtcDecode(state.rtcState.framebuffer).slice();
  return state;
}
function rtcSerializableState(state) {
  return { ...state, bus: { ...state.bus, ram: b64(rtcDecode(state.bus.ram)), zram: b64(rtcDecode(state.bus.zram)) }, vdp: { ...state.vdp, vram: b64(rtcDecode(state.vdp.vram)) }, sram: state.sram ? b64(rtcDecode(state.sram)) : null, rtcState: state.rtcState ? { ...state.rtcState, framebuffer: state.rtcState.framebuffer ? b64(rtcDecode(state.rtcState.framebuffer)) : null } : undefined };
}
function rtcStateBytes(value) {
  if (value == null) return 0; if (typeof value === 'string') return value.length * 2;
  if (typeof value !== 'object') return 8; if (ArrayBuffer.isView(value)) return value.byteLength;
  return 32 + Object.values(value).reduce((n, v) => n + rtcStateBytes(v), 0);
}
function rtcSnapshot() { if (!machine.rom) return null; const state = rtcCompactState(machine.state()); return { frame: RTC.frame, state, bytes: rtcStateBytes(state) }; }
function rtcRewindProfile() {
  const seconds = clamp(parseInt(rtcValue('rtcRewindSeconds', '15')) || 15, 1, 120);
  const minimumEvery = clamp(parseInt(rtcValue('rtcRewindEvery', '5')) || 5, 1, 60);
  const frames = seconds * (machine.pal ? 50 : 60);
  // Every snapshot is independently restorable, including pixels, sound and ROM
  // patches. Long presets trade capture spacing for duration rather than growing
  // the RAM budget or silently losing most of the requested history.
  const capacity = Math.max(1, Math.min(900, Math.floor(RTC.rewindLimit / Math.max(1, RTC.rewindStateBytes))));
  const every = Math.max(minimumEvery, Math.ceil(frames / Math.max(1, capacity - 1)));
  return { seconds, frames, minimumEvery, every, max: Math.min(capacity, Math.floor(frames / every) + 1) };
}
function rtcMaxRewind() { return rtcRewindProfile().max; }
function rtcClearRewind() {
  RTC.rewind.length = 0; RTC.rewindBytes = 0; RTC.rewindStateBytes = 0;
  RTC.rewindLastFrame = RTC.frame; RTC.rewindInterval = 0;
}
function rtcPruneRewind(profile) {
  // If memory use or the selected duration requires wider spacing, retain full
  // older states while dropping redundant nearby captures. This also lets a
  // longer preset reuse the history that was already collected.
  if (profile.every > RTC.rewindInterval && RTC.rewind.length > 2) {
    const spaced = [], newest = RTC.rewind[RTC.rewind.length - 1]; let previous = newest.frame;
    for (let i = RTC.rewind.length - 2; i >= 0; i--) {
      const snapshot = RTC.rewind[i];
      if (previous - snapshot.frame >= profile.every || i === 0) { spaced.push(snapshot); previous = snapshot.frame; }
    }
    spaced.reverse(); spaced.push(newest); RTC.rewind = spaced;
    RTC.rewindBytes = spaced.reduce((bytes, snapshot) => bytes + snapshot.bytes, 0);
  }
  RTC.rewindInterval = profile.every;
  while (RTC.rewind.length > profile.max || RTC.rewindBytes > RTC.rewindLimit ||
      (RTC.rewind.length > 1 && RTC.rewind[RTC.rewind.length - 1].frame - RTC.rewind[0].frame > profile.frames + profile.every)) {
    RTC.rewindBytes -= RTC.rewind.shift().bytes;
  }
}
function rtcCapture() {
  if (RTC.rewinding || !machine.powered) return;
  try { const s = rtcSnapshot(); if (!s || s.bytes > RTC.rewindLimit) return; RTC.rewind.push(s); RTC.rewindBytes += s.bytes;
    RTC.rewindLastFrame = s.frame; RTC.rewindStateBytes = Math.max(RTC.rewindStateBytes, s.bytes);
    rtcPruneRewind(rtcRewindProfile());
  } catch (e) { rtcStatus('Rewind capture error: ' + e.message); }
}
function rtcLoadSnapshot(snapshot, resume = true, clearRewind = true) {
  if (!snapshot) return false;
  const preserve = RTC.preserveRewindOnLoad; RTC.preserveRewindOnLoad = !clearRewind;
  try { machine.loadState(snapshot.state); } finally { RTC.preserveRewindOnLoad = preserve; }
  RTC.frame = snapshot.frame;
  if (clearRewind) rtcClearRewind(); machine.paused = !resume; machine.running = true; last = performance.now(); acc = 0;
  refreshUI(); return true;
}
function rtcRewindStep() {
  if (!RTC.rewind.length) return;
  try { const s = RTC.rewind.pop(); RTC.rewindBytes = Math.max(0, RTC.rewindBytes - s.bytes); rtcLoadSnapshot(s, false, false);
    rtcStatus(`REWIND · frame ${RTC.frame} · ${RTC.rewind.length} snapshots · ${(RTC.rewindBytes / 1048576).toFixed(1)} MB`);
  } catch (e) { rtcRewindStop(false); rtcStatus('Rewind error: ' + e.message); }
}
function rtcRewindStart() {
  if (!machine.powered || RTC.rewinding) return; RTC.rewindResume = !machine.paused;
  RTC.rewinding = true; machine.paused = true; $('#rtcRewind')?.classList.add('held'); rtcRewindStep(); RTC.rewTimer = setInterval(rtcRewindStep, 70);
}
function rtcRewindStop(resume = true) {
  // Event handlers may pass a PointerEvent: only explicit false disables resuming.
  if (!RTC.rewinding) return; RTC.rewinding = false; clearInterval(RTC.rewTimer); RTC.rewTimer = 0; $('#rtcRewind')?.classList.remove('held');
  machine.paused = !(resume !== false && RTC.rewindResume); machine.running = true; last = performance.now(); acc = 0;
  RTC.rewindLastFrame = RTC.frame;
  rtcStatus(`Rewind released at frame ${RTC.frame}.`);
}
function rtcStorageKey(kind) { return 'badgenesis:' + kind + ':' + machine._rtcRomIdentity; }
function rtcPersistRecovery(auto = false) {
  if (!RTC.recovery) return;
  const now = performance.now();
  // Auto Blast may fire every emulated frame. Its immediate recovery always
  // stays in RAM; limit synchronous phone-storage writes to once per second.
  if (auto && RTC.recoveryPersistAt && now - RTC.recoveryPersistAt < 1000) return;
  RTC.recoveryPersistAt = now;
  try { const json = JSON.stringify({ frame: RTC.recovery.frame, state: rtcSerializableState(RTC.recovery.state) }); if (json.length < 1800000) localStorage.setItem(rtcStorageKey('recovery'), json); } catch (_) { /* RAM recovery remains available when phone storage is full. */ }
}
function rtcRecover() {
  try { if (!RTC.recovery) { const raw = localStorage.getItem(rtcStorageKey('recovery')); if (raw) RTC.recovery = JSON.parse(raw); }
    if (rtcLoadSnapshot(RTC.recovery)) rtcStatus('Recovered the full state immediately before the latest blast.'); else rtcStatus('No recovery state for this ROM yet.');
  } catch (e) { rtcStatus('Recovery error: ' + e.message); }
}
function rtcSaveSlot() {
  if (!machine.rom) return; try { const s = rtcSnapshot(); localStorage.setItem(rtcStorageKey('slot:' + rtcValue('rtcSlot', '1')), JSON.stringify({ frame: s.frame, state: rtcSerializableState(s.state) })); rtcStatus('Saved persistent slot ' + rtcValue('rtcSlot', '1') + '.'); }
  catch (e) { rtcStatus('Save slot error: ' + e.message + '. Export a state file if phone storage is full.'); }
}
function rtcLoadSlot() {
  if (!machine.rom) return; try { const raw = localStorage.getItem(rtcStorageKey('slot:' + rtcValue('rtcSlot', '1'))); if (!raw) return rtcStatus('This save slot is empty for the current ROM.'); rtcLoadSnapshot(JSON.parse(raw)); rtcStatus('Loaded slot ' + rtcValue('rtcSlot', '1') + '.'); } catch (e) { rtcStatus('Load slot error: ' + e.message); }
}
function rtcSetClean() { if (!machine.rom) return; RTC.clean = rtcSnapshot(); rtcStatus('Clean harvester state saved, including audio and the current ROM copy.'); }
function rtcRestoreClean() { if (!RTC.clean) return rtcStatus('No clean state yet.'); try { rtcLoadSnapshot(RTC.clean); rtcStatus('Clean state restored.'); } catch (e) { rtcStatus('Restore error: ' + e.message); } }
function rtcNext() { if (!RTC.clean) rtcSetClean(); if (!RTC.clean) return; rtcRestoreClean(); rtcBlast(false); rtcStatus($('#rtcStatus').textContent + '\nHarvester candidate is running. Keep or discard it, then choose NEXT GLITCH.'); }
function rtcDiscard() { if (!RTC.clean) return rtcStatus('No clean state yet.'); rtcRestoreClean(); rtcStatus('Candidate discarded; clean state restored. Choose NEXT GLITCH for a fresh candidate.'); }
function rtcKeptRender() {
  const select = $('#rtcKept'); if (!select) return; const previous = select.value; select.replaceChildren();
  if (!RTC.kept.length) { const o = document.createElement('option'); o.value = ''; o.textContent = 'No kept glitches'; select.append(o); return; }
  RTC.kept.forEach((k, i) => { const o = document.createElement('option'); o.value = String(i); o.textContent = `#${i + 1} · BLAST ${k.blast} · frame ${k.frame} · ${k.mode}`; select.append(o); });
  select.value = RTC.kept[Number(previous)] ? previous : String(RTC.kept.length - 1);
}
function rtcKeep() {
  if (!machine.rom) return; const s = rtcSnapshot(), h = RTC.history.find(h => h.n === RTC.blast);
  RTC.kept.push({ ...s, blast: h?.n || RTC.blast, seed: h?.seed || null, mode: h?.mode || 'state', domains: h?.domains || [], created: Date.now() }); RTC.keptBytes += s.bytes;
  while (RTC.kept.length > 24 || (RTC.keptBytes > 32 * 1048576 && RTC.kept.length > 1)) RTC.keptBytes -= RTC.kept.shift().bytes;
  rtcKeptRender(); if ($('#rtcKept')) $('#rtcKept').value = String(RTC.kept.length - 1);
  rtcStatus(`Kept result #${RTC.kept.length} from BLAST #${RTC.blast}. Export kept glitches to preserve them after closing the app.`);
}
function rtcLoadKept() { const k = RTC.kept[parseInt(rtcValue('rtcKept'))]; if (!k) return rtcStatus('No kept glitch selected.'); try { rtcLoadSnapshot(k); rtcStatus('Kept glitch loaded with its complete ROM, audio and machine state.'); } catch (e) { rtcStatus('Kept load error: ' + e.message); } }
function rtcExportKept() {
  const k = RTC.kept[parseInt(rtcValue('rtcKept'))]; if (!k) return rtcStatus('No kept glitch selected.');
  const data = { format: 'BadGenesis kept glitch', version: 1, romName: machine.romName, romIdentity: machine._rtcRomIdentity, frame: k.frame, blast: k.blast, seed: k.seed, mode: k.mode, domains: k.domains, created: k.created, state: rtcSerializableState(k.state) };
  download((machine.romName.replace(/\.[^.]+$/, '') || 'badgenesis') + '-glitch-' + k.blast + '.badglitch', new Blob([JSON.stringify(data)], { type: 'application/json' })); rtcStatus('Kept glitch exported. Load the original ROM before importing it on another device.');
}
async function rtcImportKept(e) {
  try { const file = e.target.files?.[0]; if (!file) return; const data = JSON.parse(await file.text());
    if (!machine.rom || data.romIdentity !== machine._rtcRomIdentity || data.format !== 'BadGenesis kept glitch' || !data.state) throw Error('Load the matching original ROM before importing this glitch.');
    const state = rtcCompactState(data.state), bytes = rtcStateBytes(state); RTC.kept.push({ ...data, state, bytes }); RTC.keptBytes += bytes;
    while (RTC.kept.length > 24 || (RTC.keptBytes > 32 * 1048576 && RTC.kept.length > 1)) RTC.keptBytes -= RTC.kept.shift().bytes;
    rtcKeptRender(); $('#rtcKept').value = String(RTC.kept.length - 1); rtcStatus('Kept glitch imported. Choose LOAD KEPT to run it.');
  } catch (err) { rtcStatus('Glitch import error: ' + err.message); } finally { e.target.value = ''; }
}
function rtcExportRom() { if (!machine.rom) return; download((machine.romName.replace(/\.[^.]+$/, '') || 'badgenesis') + '-corrupted.bin', new Blob([machine.rom], { type: 'application/octet-stream' })); rtcStatus('Corrupted ROM exported as a new file; the original ROM is untouched.'); }
function rtcResetSession() {
  rtcRewindStop(false); RTC.frame = 0; RTC.blast = 0; RTC.auto = false; RTC.undo = null; RTC.history.length = 0; rtcClearRewind(); RTC.quick = null; RTC.clean = null; RTC.recovery = null; RTC.kept.length = 0; RTC.keptBytes = 0;
  RTC.historySession = rtcFreshSeed().toString(16) + ':' + Date.now().toString(16); RTC.recoveryPersistAt = 0;
  rtcHistoryRender(); rtcKeptRender(); if ($('#rtcAuto')) { $('#rtcAuto').textContent = 'AUTO OFF'; $('#rtcAuto').classList.remove('primary'); }
}
const rtcOrigLoadROM = MegaDrive.prototype.loadROM;
MegaDrive.prototype.loadROM = function (bytes, name = 'ROM') {
  delete this._rtcOriginalRom; delete this._rtcBaseChecksum; delete this._rtcRomIdentity; delete this._rtcPatches; delete this._rtcPatchCache;
  // Normalization and all later ROM corruption operate on an owned copy of the input.
  const info = rtcOrigLoadROM.call(this, bytes instanceof Uint8Array ? bytes.slice() : new Uint8Array(bytes).slice(), name); rtcEnsureOriginal(this);
  if (this === machine) { RTC.originalRom = this._rtcOriginalRom; RTC.romName = name; rtcResetSession(); rtcStatus('RTC ready for ' + name + '. Blasts use fresh randomness by default.'); }
  return info;
};
// Timeout is emulated 68000 time, so a long or paused phone frame cannot disrupt the 6-button handshake.
Object.assign(machine.pad.keys, { x: false, y: false, z: false, mode: false });
function rtcPadTimeout(pad) { const cycles = machine.cpu.total; if (cycles < (pad.lastToggleCycles || 0) || cycles - (pad.lastToggleCycles || 0) > 12000) pad.phase = 0; return cycles; }
Pad3.prototype.writeData = function (v) { const cycles = rtcPadTimeout(this), old = this.currentTH(); this.data = (this.data & ~this.ctrl) | ((v & 0x7f) & this.ctrl); const next = this.currentTH(); if (old !== next) { this.phase = ((this.phase || 0) + 1) & 7; this.lastToggleCycles = cycles; this.lastTH = next; } };
const rtcPadRead = Pad3.prototype.read;
Pad3.prototype.read = function () { rtcPadTimeout(this); this.lastToggle = performance.now(); return rtcPadRead.call(this); };
const rtcPadState = Pad3.prototype.state, rtcPadLoad = Pad3.prototype.load;
Pad3.prototype.state = function () { return { ...rtcPadState.call(this), lastToggleCycles: this.lastToggleCycles || 0 }; };
Pad3.prototype.load = function (s) { rtcPadLoad.call(this, s); this.lastToggleCycles = s?.lastToggleCycles || 0; };
const rtcOrigRunFrame = MegaDrive.prototype.runFrame;
MegaDrive.prototype.runFrame = function () {
  const before = this.frames, wasRunning = this.running; const result = rtcOrigRunFrame.apply(this, arguments);
  if (this === machine && this.frames !== before) {
    RTC.frame++; const every = rtcRewindProfile().every;
    if (!RTC.rewinding && (RTC.frame < RTC.rewindLastFrame || RTC.frame - RTC.rewindLastFrame >= every)) rtcCapture();
    const af = clamp(parseInt(rtcValue('rtcAutoFrames', '60')) || 60, 1, 3600);
    if (RTC.auto && !RTC.rewinding && this.running && RTC.frame % af === 0) rtcBlast(true);
    if (wasRunning && !this.running && RTC.recovery) rtcStatus('The emulated program stopped after a glitch. Use RECOVER, UNDO, or hold REWIND.\n' + this.stopReason);
  }
  return result;
};
// Preserve pointer-ID multitouch in the offline HTML as well as the later Android mobile layer.
const rtcPointers = new Map(), rtcCounts = new Map();
function rtcTouchSet(k, on) { const n = on ? (rtcCounts.get(k) || 0) + 1 : Math.max(0, (rtcCounts.get(k) || 0) - 1); rtcCounts.set(k, n); setPhysicalPad(k, n > 0); }
$$('[data-key]').forEach(b => {
  b.onpointerleave = null; b.onpointerdown = e => { e.preventDefault(); if (rtcPointers.has(e.pointerId)) return; rtcPointers.set(e.pointerId, b.dataset.key); try { b.setPointerCapture(e.pointerId); } catch (_) {} rtcTouchSet(b.dataset.key, true); };
  const up = e => { e.preventDefault(); const k = rtcPointers.get(e.pointerId); if (k) { rtcPointers.delete(e.pointerId); rtcTouchSet(k, false); } }; b.onpointerup = up; b.onpointercancel = up; b.onlostpointercapture = up;
});
function rtcBind(id, handler) { if ($('#' + id)) $('#' + id).onclick = handler; }
rtcBind('rtcBlast', () => rtcBlast(false)); rtcBind('rtcBlastQuick', () => rtcBlast(false)); rtcBind('rtcUndo', rtcUndo);
rtcBind('rtcAuto', () => { RTC.auto = !RTC.auto; $('#rtcAuto').textContent = RTC.auto ? 'AUTO ON' : 'AUTO OFF'; $('#rtcAuto').classList.toggle('primary', RTC.auto); rtcStatus('Auto Blast ' + (RTC.auto ? 'enabled; each blast uses fresh random corruption.' : 'disabled.')); });
rtcBind('rtcQuickSave', () => { if (machine.rom) { RTC.quick = rtcSnapshot(); rtcStatus('Quick state saved, including audio and ROM mutations.'); } });
rtcBind('rtcQuickLoad', () => { try { if (rtcLoadSnapshot(RTC.quick)) rtcStatus('Quick state loaded.'); else rtcStatus('No quick state yet.'); } catch (e) { rtcStatus('Quick load error: ' + e.message); } });
for (const [id, fn] of [['rtcClean', rtcSetClean], ['rtcRestore', rtcRestoreClean], ['rtcNext', rtcNext], ['rtcKeep', rtcKeep], ['rtcDiscard', rtcDiscard], ['rtcExportRom', rtcExportRom], ['rtcLoadKept', rtcLoadKept], ['rtcExportKept', rtcExportKept], ['rtcRecover', rtcRecover], ['rtcSlotSave', rtcSaveSlot], ['rtcSlotLoad', rtcLoadSlot]]) rtcBind(id, fn);
if ($('#rtcRangeDomain')) $('#rtcRangeDomain').onchange = rtcRangeScopeChanged;
if ($('#rtcKeptInput')) $('#rtcKeptInput').onchange = rtcImportKept;
if ($('#rtcSeedMode')) $('#rtcSeedMode').onchange = () => { if ($('#rtcSeed')) $('#rtcSeed').disabled = rtcValue('rtcSeedMode') !== 'manual'; };
if ($('#rtcSeed')) $('#rtcSeed').disabled = rtcValue('rtcSeedMode', 'random') !== 'manual';
function rtcHoldBind(el) { if (!el) return; el.onpointerdown = e => { e.preventDefault(); try { el.setPointerCapture(e.pointerId); } catch (_) {} rtcRewindStart(); }; el.onpointerup = rtcRewindStop; el.onpointercancel = rtcRewindStop; el.onlostpointercapture = rtcRewindStop; }
rtcHoldBind($('#rtcRewind')); addEventListener('blur', () => { if (RTC.rewinding) rtcRewindStop(false); });
const rtcOldPollGamepad = pollGamepad;
pollGamepad = function () { rtcOldPollGamepad(); const g = [...(navigator.getGamepads?.() || [])].find(Boolean); const ext = { x: !!g?.buttons[4]?.pressed, y: !!g?.buttons[5]?.pressed, z: !!g?.buttons[3]?.pressed, mode: !!g?.buttons[8]?.pressed }; for (const [k, pressed] of Object.entries(ext)) if (gamepadKeys.has(k) !== pressed) { if (pressed) gamepadKeys.add(k); else gamepadKeys.delete(k); applyMergedPad(k); } };
rtcHistoryRender(); rtcKeptRender();

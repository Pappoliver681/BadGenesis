package com.badgenesis.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.content.res.ColorStateList;
import android.hardware.input.InputManager;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.OpenableColumns;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Native Android frontend. No browser, script clock or script emulator is present. */
public final class MainActivity extends Activity implements InputManager.InputDeviceListener {
    private static final int PICK_DOCUMENT=41, EXPORT_DOCUMENT=42, MAX_DOCUMENT=64*1024*1024;
    private static final String[] DOMAIN_IDS={"wram","zram","vram","cram","vsram","sram","rom"};
    private static final String[] DOMAIN_NAMES={"68000 Work RAM","Z80 RAM","VRAM","CRAM","VSRAM","Cartridge SRAM / CARTRAM","ROM working copy"};
    private static final String[] ENGINE_IDS={"bitflip","random","add","sub","tilt","zero","ff","swap","word16","word32","nop"};
    private static final String[] ENGINE_NAMES={"Bit Flip","Random Byte","Add","Subtract","Tilt / small +/- changes","Zero","FF","Swap","16-bit big-endian","32-bit big-endian","Advanced: 68000 NOP 4E71"};
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private final Map<Integer,Set<Integer>> padKeys=new HashMap<>();
    private final Map<Integer,Integer> padAxes=new HashMap<>();
    private final Map<Integer,Set<Integer>> rewindKeys=new HashMap<>();
    private final Map<Integer,Boolean> rewindAxes=new HashMap<>();
    private final Map<Integer,Set<Integer>> fastForwardKeys=new HashMap<>();
    private final Map<Integer,Boolean> fastForwardAxes=new HashMap<>();
    private final List<MenuPanel> openMenus=new ArrayList<>();
    private SharedPreferences prefs;
    private FrameLayout root;
    private ControlsView controls;
    private SurfaceView surface;
    private TextView harvestStatus;
    private Button menuButton,editDone;
    private InputManager inputManager;
    private AudioManager audioManager;
    private AudioFocusRequest focusRequest;
    private Vibrator vibrator;
    private OnBackInvokedCallback backCallback;
    private long engine;
    private volatile boolean destroyed;
    private boolean resumed,hasAudioFocus=true,engineReady,loaded,editingControls;
    private int dialogs,touchMask,sentMask;
    private boolean touchRewind,sentRewind,touchFastForward,sentFastForward;
    private String pendingImport="rom",romName="",lastError="";
    private byte[] pendingExport;
    private JSONObject lastStatus=new JSONObject();
    private interface Result { void done(String text); }

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved); prefs=getSharedPreferences("badgenesis_native",MODE_PRIVATE);
        audioManager=(AudioManager)getSystemService(AUDIO_SERVICE);
        vibrator=(Vibrator)getSystemService(VIBRATOR_SERVICE);
        inputManager=(InputManager)getSystemService(INPUT_SERVICE);
        inputManager.registerInputDeviceListener(this,main);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if(Build.VERSION.SDK_INT>=28) {
            WindowManager.LayoutParams p=getWindow().getAttributes();
            p.layoutInDisplayCutoutMode=Build.VERSION.SDK_INT>=30?WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS:WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(p);
        }
        String orientation=prefs.getString("orientation","landscape");
        applyOrientation(orientation); buildViews(); configureFocus();
        if(Build.VERSION.SDK_INT>=33) {
            backCallback=this::showMenu;
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT,backCallback);
        }
        io.execute(()->{
            try {
                long handle=NativeBridge.create(getFilesDir().getAbsolutePath());
                if(handle==0) throw new IllegalStateException("The native emulator could not initialize.");
                engine=handle;
                main.post(()->{
                    if(destroyed) return;
                    engineReady=true;
                    if(surface.getHolder().getSurface().isValid()) attachSurface(surface.getHolder());
                    command("controller",json("sixButton",controlPrefs().getBoolean("sixButton",true)),null);
                    dispatchPause(); dispatchAudio(); applyRtc(); applyRewind(); applySpeed();applyDisplay();
                    main.post(statusTick);
                    if(saved==null) showMenu();
                });
            } catch(Throwable e) { main.post(()->showError("Native initialization failed",e.getMessage()==null?e.toString():e.getMessage())); }
        });
    }
    private SharedPreferences controlPrefs() { return getSharedPreferences("native_controls",MODE_PRIVATE); }
    private void buildViews() {
        root=new FrameLayout(this); root.setBackgroundColor(Color.BLACK);
        surface=new SurfaceView(this); surface.setKeepScreenOn(true);
        root.addView(surface,new FrameLayout.LayoutParams(-1,-1));
        surface.getHolder().addCallback(new SurfaceHolder.Callback(){
            public void surfaceCreated(SurfaceHolder holder) { attachSurface(holder); }
            public void surfaceChanged(SurfaceHolder holder,int format,int width,int height) { attachSurface(holder); }
            public void surfaceDestroyed(SurfaceHolder holder) {
                if(engineReady) io.execute(()->{if(engine!=0)NativeBridge.attachSurface(engine,null);});
            }
        });
        controls=new ControlsView(this,new ControlsView.Listener(){
            public void buttonsChanged(int mask) { touchMask=mask; sendButtons(); }
            public void rewindHeld(boolean held) { touchRewind=held;sendRewind(); }
            public void fastForwardHeld(boolean held) { touchFastForward=held;sendFastForward(); }
            public void pressed() { vibrate(); }
        });
        root.addView(controls,new FrameLayout.LayoutParams(-1,-1));
        // The virtual controller owns held rewind / fast-forward icons at the top left.
        // The overflow menu stays transparent, without a persistent game status banner.
        menuButton=new Button(this);menuButton.setText("⋮");menuButton.setTextSize(30);menuButton.setTextColor(0xAFFFFFFF);menuButton.setBackgroundColor(Color.TRANSPARENT);menuButton.setContentDescription("Open BadGenesis menu");menuButton.setPadding(0,0,0,0);menuButton.setOnClickListener(v->showMenu());
        FrameLayout.LayoutParams menuPosition=new FrameLayout.LayoutParams(dp(52),dp(52),android.view.Gravity.TOP|android.view.Gravity.RIGHT);
        root.addView(menuButton,menuPosition);
        editDone=MenuPanel.row(this,"Done");editDone.setTextSize(18);editDone.setVisibility(View.GONE);editDone.setOnClickListener(v->finishControlEdit());
        root.addView(editDone,new FrameLayout.LayoutParams(dp(90),dp(48),android.view.Gravity.TOP|android.view.Gravity.CENTER_HORIZONTAL));
        root.setOnApplyWindowInsetsListener((v,insets)->{
            int safeRight=0,safeTop=0;
            if(Build.VERSION.SDK_INT>=30) {android.graphics.Insets safe=insets.getInsets(WindowInsets.Type.displayCutout());safeRight=safe.right;safeTop=safe.top;}
            else if(Build.VERSION.SDK_INT>=28&&insets.getDisplayCutout()!=null){android.view.DisplayCutout c=insets.getDisplayCutout();safeRight=c.getSafeInsetRight();safeTop=c.getSafeInsetTop();}
            FrameLayout.LayoutParams position=(FrameLayout.LayoutParams)menuButton.getLayoutParams();position.rightMargin=safeRight;position.topMargin=safeTop;menuButton.setLayoutParams(position);
            return insets;
        });
        setContentView(root); immersive();
    }
    private void attachSurface(SurfaceHolder holder) {
        if(!engineReady||!holder.getSurface().isValid()) return;
        android.view.Surface nativeSurface=holder.getSurface();
        io.execute(()->{if(engine!=0&&!destroyed)NativeBridge.attachSurface(engine,nativeSurface);});
    }
    private void configureFocus() {
        AudioAttributes attr=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();
        focusRequest=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN).setAudioAttributes(attr)
            .setOnAudioFocusChangeListener(change->{hasAudioFocus=change==AudioManager.AUDIOFOCUS_GAIN;dispatchAudio();},main).build();
    }
    private void dispatchAudio() { command("audio",json("enabled",resumed&&hasAudioFocus&&prefs.getBoolean("audio",true)),null); }
    private void dispatchPause() { command("pause",json("paused",!resumed||dialogs>0||editingControls),null); }
    private void command(String name,JSONObject options,Result result) {
        if(!engineReady||destroyed) { if(result!=null)result.done("{\"ok\":false,\"error\":\"Native emulator is not ready.\"}");return; }
        String data=options==null?"{}":options.toString();
        io.execute(()->{
            if(engine==0||destroyed) return;
            try {
                String output=NativeBridge.command(engine,name,data);
                if(result!=null) main.post(()->{if(!destroyed)result.done(output==null?"{}":output);});
            } catch(Throwable e) { main.post(()->showError("Native command failed",e.toString())); }
        });
    }
    private JSONObject json(String name,Object value) { JSONObject obj=new JSONObject();try{obj.put(name,value);}catch(Exception ignored){}return obj; }
    private boolean successful(String text) {
        try { JSONObject data=new JSONObject(text); if(!data.optBoolean("ok",true)) { showError("BadGenesis",data.optString("error","The native operation failed."));return false; } }
        catch(Exception e) { if(text!=null&&!text.isEmpty()) {showError("BadGenesis",text);return false;} }
        return true;
    }
    private final Runnable statusTick=new Runnable(){ public void run(){
        if(destroyed||!engineReady)return;
        io.execute(()->{
            try { String text=NativeBridge.status(engine);JSONObject info=new JSONObject(text);
                main.post(()->{if(destroyed)return;lastStatus=info;loaded=info.optBoolean("loaded",loaded);romName=info.optString("romName",romName);
                    if(harvestStatus!=null)harvestStatus.setText((info.optBoolean("harvestRunning")?"Running emulated frames…":"Harvester paused / ready")+"\n"+info.optString("message","")+"\nNative frame "+info.optLong("frame",0));
                    String error=info.optString("error",""); if(!error.isEmpty()&&!error.equals(lastError)){lastError=error;showError("Native emulator",error);} main.postDelayed(this,1000);
                });
            }catch(Throwable e){main.post(()->{if(!destroyed)main.postDelayed(this,2000);});}
        });
    }};
    private void showMenu() {
        if(destroyed) return;
        if(editingControls){finishControlEdit();return;}
        if(!openMenus.isEmpty())return;
        String[] items={"Open Content","Recent Content","System Actions","On-screen Input Setup","Key/Gamepad Input Setup","Options","Benchmark Content","RTC Corruption","Memory / Resource Tools","About BadGenesis"};
        MenuPanel dialog=new MenuPanel.Builder(this).setTitle("BadGenesis").setItems(items,(d,which)->{
            switch(which){
                case 0:pick("rom");break;case 1:showRecent();break;case 2:showSystemActions();break;
                case 3:showControls();break;case 4:showGamepads();break;case 5:showOptions();break;
                case 6:showBenchmark();break;case 7:showRtcActions();break;case 8:showInspector();break;
                case 9:showAbout();break;
            }
        }).setEnabledItems(new boolean[]{true,true,loaded,true,true,true,loaded,true,loaded,true}).setKeepOpen(true).create();trackDialog(dialog);
    }
    private void showSystemActions(){
        String[] items={"Resume Game","Save States / Rewind","Reset Game","Recover Last Safe State","Import / Export"};
        trackDialog(new MenuPanel.Builder(this).setTitle("System Actions").setItems(items,(d,which)->{
            switch(which){case 0:closeMenus();break;case 1:showStates();break;
                case 2:command("reset",null,t->{if(successful(t))closeMenus();});break;
                case 3:command("recover",null,t->{if(successful(t))closeMenus();});break;case 4:showImportExport();break;}
        }).setKeepOpen(true).setNegativeButton("Back",null).create());
    }
    private void showRtcActions(){
        String[] items={"Corruption Settings","Blast Once","Undo Last Blast","Blast History","Glitch Harvester"};
        trackDialog(new MenuPanel.Builder(this).setTitle("RTC Corruption").setItems(items,(d,which)->{
            switch(which){case 0:showRtc();break;case 1:command("blast",null,t->{if(successful(t))closeMenus();});break;
                case 2:command("undo",null,t->{if(successful(t))closeMenus();});break;case 3:showHistory();break;case 4:showHarvester();break;}
        }).setEnabledItems(new boolean[]{true,loaded,loaded,loaded,loaded}).setKeepOpen(true).setNegativeButton("Back",null).create());
    }
    private void showOptions(){
        trackDialog(new MenuPanel.Builder(this).setTitle("Options").setItems(new String[]{"Fast-forward / Rewind Speed","Sound / Display / Touch Controls","Save States / Rewind Buffer","Import / Export"},(d,which)->{
            switch(which){case 0:showSpeedSettings();break;case 1:showControls();break;case 2:showStates();break;case 3:showImportExport();break;}
        }).setKeepOpen(true).setNegativeButton("Back",null).create());
    }
    private void showGamepads(){
        LinearLayout view=column();label(view,"Connected gamepads: "+gamepadNames());
        label(view,"Bluetooth and USB gamepads use Android native input. D-pad, hats and analog sticks support diagonals; touch and gamepad buttons can be held together.");
        label(view,"A → B     B → C     X → A     Y → X\nL1 → Y     R1 → Z\nSTART → START     SELECT → MODE\nHold L2: rewind     Hold R2: fast-forward");
        label(view,"Keyboard\nArrows: direction\nZ / X / C: A / B / C\nA / S / D: X / Y / Z\nEnter: START     Shift: MODE\nHold R: rewind     Hold F: fast-forward");
        button(view,"Speed Settings",this::showSpeedSettings);
        trackDialog(new MenuPanel.Builder(this).setTitle("Key/Gamepad Input Setup").setView(scrolling(view)).setNegativeButton("Back",null).create());
    }
    private void showBenchmark(){
        LinearLayout view=column();TextView result=label(view,"Run a native core benchmark for 120 emulated frames. Your complete emulator state is restored afterward; audio is not played during measurement.");
        button(view,"Run Benchmark",()->command("benchmark",json("frames",120),text->{if(successful(text))result.setText(pretty(text));}));
        trackDialog(new MenuPanel.Builder(this).setTitle("Benchmark Content").setView(scrolling(view)).setNegativeButton("Back",null).create());
    }
    private void closeMenus(){for(MenuPanel menu:new ArrayList<>(openMenus))menu.dismiss();}
    private void showSpeedSettings(){
        LinearLayout view=column();float ff=prefs.getFloat("speed.fastForward",2),rew=prefs.getFloat("speed.rewind",2);
        Spinner forward=spinner(view,"Fast-forward Speed",new String[]{"2×","3×","4×","8×"},speedIndex(new float[]{2,3,4,8},ff));
        Spinner reverse=spinner(view,"Rewind Speed",new String[]{"0.5×","1×","2×","4×","8×","16×"},speedIndex(new float[]{.5f,1,2,4,8,16},rew));
        CheckBox audible=check(view,"Play Audio While Rewinding",prefs.getBoolean("speed.rewindAudio",true));
        label(view,"Hold the double-triangle button to fast-forward. Hold the reverse button to rewind. Release to return to normal speed.");
        MenuPanel dialog=new MenuPanel.Builder(this).setTitle("Fast-forward / Rewind Speed").setView(scrolling(view)).setNegativeButton("Cancel",null).setPositiveButton("Apply",null).create();
        trackDialog(dialog);dialog.getButton(MenuPanel.BUTTON_POSITIVE).setOnClickListener(v->{
            prefs.edit().putFloat("speed.fastForward",new float[]{2,3,4,8}[forward.getSelectedItemPosition()]).putFloat("speed.rewind",new float[]{.5f,1,2,4,8,16}[reverse.getSelectedItemPosition()]).putBoolean("speed.rewindAudio",audible.isChecked()).apply();applySpeed();dialog.dismiss();
        });
    }
    private int speedIndex(float[] values,float value){for(int i=0;i<values.length;i++)if(Math.abs(values[i]-value)<.01f)return i;return Math.min(2,values.length-1);}
    private void applySpeed(){
        try{JSONObject settings=new JSONObject().put("fastForwardMultiplier",prefs.getFloat("speed.fastForward",2)).put("rewindMultiplier",prefs.getFloat("speed.rewind",2)).put("rewindAudio",prefs.getBoolean("speed.rewindAudio",true));command("speed_config",settings,this::successful);}
        catch(Exception e){showError("Playback Speed",e.toString());}
    }
    private void applyDisplay(){command("display_config",json("aspect",prefs.getString("display.aspect","4:3")),this::successful);}
    private JSONArray recentContent(){try{return new JSONArray(prefs.getString("recent.content","[]"));}catch(Exception ignored){return new JSONArray();}}
    private void recordRecent(Uri source,String name,String entry){
        if(source==null)return;
        try{JSONArray previous=recentContent(),saved=new JSONArray();String uri=source.toString(),zipEntry=entry==null?"":entry;
            saved.put(new JSONObject().put("uri",uri).put("name",name).put("entry",zipEntry));
            for(int i=0;i<previous.length()&&saved.length()<12;i++){JSONObject item=previous.optJSONObject(i);if(item!=null&&!(uri.equals(item.optString("uri"))&&zipEntry.equals(item.optString("entry"))))saved.put(item);}
            prefs.edit().putString("recent.content",saved.toString()).apply();
        }catch(Exception ignored){}
    }
    private void showRecent(){
        JSONArray history=recentContent();if(history.length()==0){trackDialog(new MenuPanel.Builder(this).setTitle("Recent Content").setMessage("Open Genesis / Mega Drive content to add it to this list.").setNegativeButton("Back",null).create());return;}
        String[] names=new String[history.length()];for(int i=0;i<names.length;i++){JSONObject item=history.optJSONObject(i);names[i]=item==null?"Unavailable content":item.optString("name","Genesis ROM");}
        trackDialog(new MenuPanel.Builder(this).setTitle("Recent Content").setItems(names,(d,index)->{
            JSONObject item=history.optJSONObject(index);if(item==null)return;openRomDocument(Uri.parse(item.optString("uri")),item.optString("entry",""));
        }).setNegativeButton("Back",null).setNeutralButton("Clear Recent Content",(d,w)->prefs.edit().remove("recent.content").apply()).create());
    }
    private void openRomDocument(Uri uri,String selectedEntry){
        io.execute(()->{try{
            String name=documentName(uri),entry=selectedEntry;byte[] bytes;
            try(InputStream input=getContentResolver().openInputStream(uri)){if(input==null)throw new IllegalStateException("The selected content could not be opened.");bytes=readLimited(input,MAX_DOCUMENT);}
            if(bytes.length>=4&&bytes[0]=='P'&&bytes[1]=='K'){
                if(entry==null||entry.isEmpty()){List<String> names=zipRomNames(bytes);if(names.isEmpty())throw new IllegalArgumentException("The ZIP contains no .bin, .md, .gen or .smd ROM.");if(names.size()>1){byte[] archive=bytes;main.post(()->chooseZip(archive,names,uri));return;}entry=names.get(0);}
                name=entry;bytes=zipRom(bytes,entry);
            }
            loadRom(bytes,name,uri,entry);
        }catch(Throwable e){main.post(()->showError("Open Content",e.getMessage()==null?e.toString():e.getMessage()));}});
    }
    private void trackDialog(MenuPanel dialog) {
        dialogs++;openMenus.add(dialog);dispatchPause();releaseHeldInputs();
        dialog.setOnDismissListener(d->{openMenus.remove(dialog);dialogs=Math.max(0,dialogs-1);dispatchPause();immersive();});
        dialog.show();
    }
    private void showError(String title,String text) {
        if(destroyed)return;trackDialog(new MenuPanel.Builder(this).setTitle(title).setMessage(text).setPositiveButton("OK",null).create());
    }
    private void showAbout() {
        String text="BadGenesis native Android port\n\nEmulation: Genesis Plus GX C core. Live native memory corruption. Native audio and Surface rendering. Hardware emulation timing is independent of the Android display refresh rate.\n\nROM files are opened read-only. ROM corruption changes the in-memory working copy. Native full savestates power rewind.\n\nGenesis Plus GX uses a non-commercial license; source and attribution are included with this project.";
        trackDialog(new MenuPanel.Builder(this).setTitle("About BadGenesis").setMessage(text).setNeutralButton("Open source licenses",(d,w)->showLicenses()).setPositiveButton("OK",null).create());
    }
    private void showLicenses(){io.execute(()->{try{StringBuilder text=new StringBuilder();for(String name:new String[]{"Genesis-Plus-GX.txt","THIRD_PARTY_NOTICES.txt"})try(InputStream in=getAssets().open("licenses/"+name)){text.append(new String(readLimited(in,MAX_DOCUMENT),java.nio.charset.StandardCharsets.UTF_8)).append("\n\n");}main.post(()->{LinearLayout view=column();TextView data=label(view,text.toString());data.setTextIsSelectable(true);trackDialog(new MenuPanel.Builder(this).setTitle("Open source licenses").setView(scrolling(view)).setPositiveButton("Close",null).create());});}catch(Exception e){main.post(()->showError("Licenses",e.toString()));}});}
    private LinearLayout column() {LinearLayout view=new LinearLayout(this);view.setOrientation(LinearLayout.VERTICAL);view.setPadding(dp(16),dp(8),dp(16),dp(8));return view;}
    private ScrollView scrolling(LinearLayout view){ScrollView sc=new ScrollView(this);sc.addView(view);return sc;}
    private TextView label(LinearLayout parent,String value){TextView t=new TextView(this);t.setText(value);t.setTextColor(Color.WHITE);t.setTextSize(18);t.setPadding(0,dp(7),0,dp(7));parent.addView(t);return t;}
    private Button button(LinearLayout parent,String name,Runnable action){Button b=MenuPanel.row(this,name);b.setOnClickListener(v->action.run());parent.addView(b,new LinearLayout.LayoutParams(-1,-2));MenuPanel.addDivider(this,parent);return b;}
    private CheckBox check(LinearLayout parent,String name,boolean value){CheckBox c=new CheckBox(this);c.setText(name);c.setTextColor(Color.WHITE);c.setTextSize(20);c.setButtonTintList(ColorStateList.valueOf(0xFF9696FF));c.setBackgroundColor(Color.BLACK);c.setChecked(value);c.setPadding(0,dp(8),0,dp(8));parent.addView(c);MenuPanel.addDivider(this,parent);return c;}
    private GradientDrawable formBackground(){GradientDrawable background=new GradientDrawable();background.setColor(Color.BLACK);background.setStroke(dp(1),0xFF454545);return background;}
    private EditText field(LinearLayout parent,String name,String value){label(parent,name);EditText e=new EditText(this);e.setSingleLine(true);e.setText(value);e.setTextColor(Color.WHITE);e.setTextSize(18);e.setBackground(formBackground());e.setPadding(dp(8),dp(8),dp(8),dp(8));parent.addView(e);return e;}
    private Spinner spinner(LinearLayout parent,String title,String[] values,int selected){
        label(parent,title);Spinner s=new Spinner(this,Spinner.MODE_DROPDOWN);
        ArrayAdapter<String>a=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,values){
            private View item(int position,boolean expanded){TextView text=new TextView(MainActivity.this);text.setText(values[position]+(expanded?"":"  ▾"));text.setTextColor(Color.WHITE);text.setTextSize(20);text.setBackgroundColor(Color.BLACK);text.setPadding(dp(8),dp(10),dp(8),dp(10));text.setMinHeight(dp(44));return text;}
            @Override public View getView(int position,View recycled,android.view.ViewGroup parent){return item(position,false);}
            @Override public View getDropDownView(int position,View recycled,android.view.ViewGroup parent){return item(position,true);}
        };
        s.setAdapter(a);s.setSelection(selected);s.setPopupBackgroundDrawable(new ColorDrawable(Color.BLACK));s.setBackground(formBackground());parent.addView(s,new LinearLayout.LayoutParams(-1,-2));return s;
    }
    private SeekBar slider(LinearLayout parent,String title,int max,int progress){TextView name=label(parent,title+": "+progress);SeekBar seek=new SeekBar(this);seek.setProgressTintList(ColorStateList.valueOf(0xFF9696FF));seek.setThumbTintList(ColorStateList.valueOf(Color.WHITE));seek.setMax(max);seek.setProgress(progress);seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}public void onProgressChanged(SeekBar b,int p,boolean user){name.setText(title+": "+p);}});parent.addView(seek);return seek;}
    private int indexOf(String[] values,String value){for(int i=0;i<values.length;i++)if(values[i].equals(value))return i;return 0;}
    private void showRtc() {
        LinearLayout view=column();
        Spinner engineChoice=spinner(view,"Corruption engine",ENGINE_NAMES,indexOf(ENGINE_IDS,prefs.getString("rtc.engine","bitflip")));
        EditText intensity=field(view,"Intensity (corruption units per blast)",Integer.toString(prefs.getInt("rtc.intensity",16)));
        JSONObject liveRtc=lastStatus.optJSONObject("rtc");
        CheckBox auto=check(view,"Auto Blast",loaded&&liveRtc!=null?liveRtc.optBoolean("autoBlast"):prefs.getBoolean("rtc.auto",false));
        EditText interval=field(view,"Auto Blast interval in emulated frames",Integer.toString(prefs.getInt("rtc.interval",60)));
        label(view,"Random mode is the default. Every Blast and Auto Blast independently selects new addresses and mutation values.");
        CheckBox seedMode=check(view,"Advanced: reproducible manual seed",prefs.getBoolean("rtc.manualSeed",false));
        EditText seed=field(view,"Advanced seed",prefs.getString("rtc.seed","1"));
        List<CheckBox> enabled=new ArrayList<>();List<EditText> starts=new ArrayList<>(),ends=new ArrayList<>(),exclusions=new ArrayList<>();
        for(int i=0;i<DOMAIN_IDS.length;i++){
            String id=DOMAIN_IDS[i];label(view,"── "+DOMAIN_NAMES[i]+" ──");
            enabled.add(check(view,"Enable domain",prefs.getBoolean("rtc."+id+".enabled",id.equals("wram"))));
            starts.add(field(view,"Start address (hex)",prefs.getString("rtc."+id+".start","0")));
            ends.add(field(view,"End address (hex, inclusive; blank = whole domain)",prefs.getString("rtc."+id+".end","")));
            exclusions.add(field(view,"Excluded hex ranges, e.g. 0-1F,100-10F",prefs.getString("rtc."+id+".exclude","")));
            if(id.equals("rom"))label(view,"Optional: changes only the in-memory ROM working copy. Original ROM is never overwritten.");
            if(id.equals("sram"))label(view,"Available only when the cartridge exposes SRAM / CARTRAM.");
        }
        MenuPanel dialog=new MenuPanel.Builder(this).setTitle("RTC live memory corruption").setView(scrolling(view)).setNegativeButton("Cancel",null).setPositiveButton("Apply",null).create();
        trackDialog(dialog);dialog.getButton(MenuPanel.BUTTON_POSITIVE).setOnClickListener(v->{
            try{
                int units=Integer.parseInt(intensity.getText().toString().trim()),frames=Integer.parseInt(interval.getText().toString().trim());
                if(units<1||units>100000||frames<1)throw new IllegalArgumentException("Intensity must be 1–100000 and interval must be positive.");
                SharedPreferences.Editor save=prefs.edit().putString("rtc.engine",ENGINE_IDS[engineChoice.getSelectedItemPosition()]).putInt("rtc.intensity",units).putBoolean("rtc.auto",auto.isChecked()).putInt("rtc.interval",frames).putBoolean("rtc.manualSeed",seedMode.isChecked()).putString("rtc.seed",seed.getText().toString().trim());
                for(int i=0;i<DOMAIN_IDS.length;i++){
                    String start=starts.get(i).getText().toString().trim(),end=ends.get(i).getText().toString().trim(),excluded=exclusions.get(i).getText().toString().trim();
                    long a=parseHex(start),b=end.isEmpty()?-1:parseHex(end);if(b>=0&&b<a)throw new IllegalArgumentException("Domain end must be at or after start.");parseExclusions(excluded);
                    String prefix="rtc."+DOMAIN_IDS[i]+".";save.putBoolean(prefix+"enabled",enabled.get(i).isChecked()).putString(prefix+"start",start).putString(prefix+"end",end).putString(prefix+"exclude",excluded);
                }
                save.apply();applyRtc();dialog.dismiss();
            }catch(Exception e){showError("RTC settings",e.getMessage());}
        });
    }
    private long parseHex(String text){String value=text.trim();if(value.startsWith("0x")||value.startsWith("0X"))value=value.substring(2);if(value.isEmpty())return 0;long n=Long.parseLong(value,16);if(n<0||n>0x7FFFFFFFL)throw new IllegalArgumentException("Address is outside the supported range.");return n;}
    private JSONArray parseExclusions(String text)throws Exception{
        JSONArray a=new JSONArray();if(text.trim().isEmpty())return a;
        for(String item:text.split(",")){String[]pair=item.trim().split("-");if(pair.length>2)throw new IllegalArgumentException("Use hex exclusions such as 0-1F,100-10F.");long start=parseHex(pair[0]),end=pair.length==2?parseHex(pair[1]):start;if(end<start)throw new IllegalArgumentException("Exclusion end precedes start.");a.put(new JSONArray().put(start).put(end));}return a;
    }
    private void applyRtc(){
        try{
            JSONObject o=new JSONObject();o.put("engine",prefs.getString("rtc.engine","bitflip")).put("intensity",prefs.getInt("rtc.intensity",16)).put("auto",prefs.getBoolean("rtc.auto",false)).put("interval",prefs.getInt("rtc.interval",60)).put("manualSeed",prefs.getBoolean("rtc.manualSeed",false)).put("seed",prefs.getString("rtc.seed","1"));
            JSONArray domains=new JSONArray();for(String id:DOMAIN_IDS){String p="rtc."+id+".";String end=prefs.getString(p+"end","");JSONObject domain=new JSONObject().put("id",id).put("enabled",prefs.getBoolean(p+"enabled",id.equals("wram"))).put("start",parseHex(prefs.getString(p+"start","0"))).put("end",end.isEmpty()?0xFFFFFFFFL:parseHex(end)).put("exclusions",parseExclusions(prefs.getString(p+"exclude","")));domains.put(domain);}o.put("domains",domains);command("rtc_config",o,this::successful);
        }catch(Exception e){showError("RTC settings",e.toString());}
    }
    private void showHistory(){command("history",null,text->{if(!successful(text))return;LinearLayout view=column();label(view,"Native blast history records domain, address, old/new values, engine, blast number and generated seed.");TextView data=label(view,pretty(text));data.setTextIsSelectable(true);button(view,"Export Blast History",()->exportFile("history","BadGenesis-blast-history.json"));
        EditText blast=field(view,"Advanced: replay recorded blast number","");CheckBox match=check(view,"Require previous values to match",true);button(view,"Replay recorded corruption",()->{try{long number=Long.parseLong(blast.getText().toString().trim());if(number<1)throw new IllegalArgumentException("Enter a positive blast number from this history.");JSONObject options=json("blast",number);options.put("requirePrevious",match.isChecked());command("replay",options,t->{successful(t);});}catch(Exception e){showError("Replay blast",e.getMessage());}});
        trackDialog(new MenuPanel.Builder(this).setTitle("Blast History").setView(scrolling(view)).setPositiveButton("Close",null).create());});}
    private void showHarvester(){
        LinearLayout view=column();label(view,"Clean state → blast → run → keep or discard → restore → next. All emulation and capture use the native core.");
        harvestStatus=label(view,lastStatus.optString("message","Capture a clean native state to begin."));
        EditText frames=field(view,"Run length in emulated frames",Integer.toString(prefs.getInt("harvest.frames",180)));
        Result done=t->{successful(t);};
        button(view,"Capture clean state / Start",()->harvestCommand("harvester_start",frames,done));
        button(view,"Blast and run / Next",()->harvestCommand("harvester_next",frames,t->{if(successful(t))closeMenus();}));
        button(view,"View Current Result",this::closeMenus);
        button(view,"Keep result",()->command("harvester_keep",null,done));
        button(view,"Discard result / restore clean state",()->command("harvester_discard",null,done));
        button(view,"Stop harvester",()->command("harvester_stop",null,done));
        button(view,"Export last kept result",()->exportFile("harvest","BadGenesis-harvest.bgh"));
        button(view,"Import kept results",()->pick("harvest"));
        trackDialog(new MenuPanel.Builder(this).setTitle("Glitch Harvester").setView(scrolling(view)).setPositiveButton("Close",null).create());
    }
    private void harvestCommand(String action,EditText frames,Result done){try{int n=Integer.parseInt(frames.getText().toString().trim());if(n<1||n>3600)throw new IllegalArgumentException("Run length must be 1–3600 frames.");prefs.edit().putInt("harvest.frames",n).apply();command(action,json("runFrames",n),done);}catch(Exception e){showError("Glitch Harvester",e.getMessage());}}
    private void showStates(){
        LinearLayout view=column();label(view,"Manual save slots are separate from the RAM rewind ring.");
        button(view,"Quick Save",()->command("quick_save",null,t->{successful(t);}));
        button(view,"Quick Load",()->command("quick_load",null,t->{successful(t);}));
        for(int slot=1;slot<=4;slot++){final int selected=slot;LinearLayout row=new LinearLayout(this);Button save=MenuPanel.row(this,"Save slot "+slot),load=MenuPanel.row(this,"Load slot "+slot);save.setOnClickListener(v->command("save_slot",json("slot",selected),this::successful));load.setOnClickListener(v->command("load_slot",json("slot",selected),this::successful));row.addView(save,new LinearLayout.LayoutParams(0,-2,1));row.addView(load,new LinearLayout.LayoutParams(0,-2,1));view.addView(row);MenuPanel.addDivider(this,view);}
        int[] seconds={15,30,60,120};int selected=indexOf(new String[]{"15","30","60","120"},Integer.toString(prefs.getInt("rewind.seconds",30)));
        Spinner preset=spinner(view,"Rewind duration",new String[]{"15 seconds","30 seconds","60 seconds","120 seconds"},selected);
        EditText interval=field(view,"Snapshot interval in emulated frames",Integer.toString(prefs.getInt("rewind.interval",6)));
        label(view,"Hold the reverse-triangle button to rewind continuously. Release to continue from the restored full state. Native RAM snapshots restore CPUs, memory, video, sound and cartridge state.");
        button(view,"Rewind Speed / Audio",this::showSpeedSettings);
        button(view,"Apply rewind settings",()->{try{int n=Integer.parseInt(interval.getText().toString().trim());if(n<1||n>120)throw new IllegalArgumentException("Snapshot interval must be 1–120 frames.");prefs.edit().putInt("rewind.seconds",seconds[preset.getSelectedItemPosition()]).putInt("rewind.interval",n).apply();applyRewind();}catch(Exception e){showError("Rewind settings",e.getMessage());}});
        button(view,"Export state",()->exportFile("state","BadGenesis-state.bgs"));button(view,"Import state",()->pick("state"));
        trackDialog(new MenuPanel.Builder(this).setTitle("Save states and rewind").setView(scrolling(view)).setPositiveButton("Close",null).create());
    }
    private void applyRewind(){JSONObject data=json("seconds",prefs.getInt("rewind.seconds",30));try{data.put("intervalFrames",prefs.getInt("rewind.interval",6));}catch(Exception ignored){}command("rewind_config",data,this::successful);}
    private void showControls(){
        LinearLayout view=column();SharedPreferences c=controlPrefs();
        CheckBox six=check(view,"Six-button controller (X / Y / Z)",c.getBoolean("sixButton",true));
        CheckBox hidden=check(view,"Hide touch controls",c.getBoolean("hidden",false));
        CheckBox vibration=check(view,"Vibration",prefs.getBoolean("vibration",true));
        CheckBox sound=check(view,"Sound",prefs.getBoolean("audio",true));
        SeekBar size=slider(view,"Control size %",180,(int)(c.getFloat("size",1)*100));
        SeekBar opacity=slider(view,"Control opacity %",100,(int)(c.getFloat("opacity",.65f)*100));
        Spinner orientation=spinner(view,"Orientation",new String[]{"Landscape","Portrait","Automatic"},indexOf(new String[]{"landscape","portrait","auto"},prefs.getString("orientation","landscape")));
        Spinner aspect=spinner(view,"Display aspect ratio",new String[]{"Original 4:3","Square pixels"},indexOf(new String[]{"4:3","pixel"},prefs.getString("display.aspect","4:3")));
        label(view,"Sharp native framebuffer. No display filters or CRT effects.");
        button(view,"Move touch controls",()->{c.edit().putFloat("size",Math.max(.55f,size.getProgress()/100f)).putFloat("opacity",Math.max(.1f,opacity.getProgress()/100f)).apply();controls.reload();editingControls=true;controls.setEditing(true);editDone.setVisibility(View.VISIBLE);dispatchPause();closeMenus();});
        button(view,"Reset control positions",()->{c.edit().remove("padX").remove("padY").remove("buttonsX").remove("buttonsY").remove("systemX").remove("systemY").apply();controls.reload();});
        button(view,"Key/Gamepad Input Setup",this::showGamepads);
        MenuPanel dialog=new MenuPanel.Builder(this).setTitle("On-screen Input Setup").setView(scrolling(view)).setNegativeButton("Cancel",null).setPositiveButton("Apply",null).create();
        trackDialog(dialog);dialog.getButton(MenuPanel.BUTTON_POSITIVE).setOnClickListener(v->{
            c.edit().putBoolean("sixButton",six.isChecked()).putBoolean("hidden",hidden.isChecked()).putFloat("size",Math.max(.55f,size.getProgress()/100f)).putFloat("opacity",Math.max(.1f,opacity.getProgress()/100f)).apply();
            String o=new String[]{"landscape","portrait","auto"}[orientation.getSelectedItemPosition()];prefs.edit().putBoolean("vibration",vibration.isChecked()).putBoolean("audio",sound.isChecked()).putString("orientation",o).putString("display.aspect",new String[]{"4:3","pixel"}[aspect.getSelectedItemPosition()]).apply();
            controls.reload();command("controller",json("sixButton",six.isChecked()),null);dispatchAudio();applyDisplay();applyOrientation(o);dialog.dismiss();
        });
    }
    private void finishControlEdit(){editingControls=false;controls.setEditing(false);controls.reload();editDone.setVisibility(View.GONE);dispatchPause();}
    private String gamepadNames(){List<String> names=new ArrayList<>();for(int id:InputDevice.getDeviceIds()){InputDevice d=InputDevice.getDevice(id);if(d!=null&&(d.supportsSource(InputDevice.SOURCE_GAMEPAD)||d.supportsSource(InputDevice.SOURCE_JOYSTICK)))names.add(d.getName());}return names.isEmpty()?"none":String.join(", ",names);}
    private void applyOrientation(String value){setRequestedOrientation(value.equals("portrait")?ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT:value.equals("auto")?ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR:ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);}
    private void showInspector(){
        LinearLayout view=column();label(view,"Inspect actual native emulator memory without serializing or reloading a state.");
        Spinner domain=spinner(view,"Memory domain",DOMAIN_NAMES,0);EditText address=field(view,"Start address (hex)","0");
        TextView data=label(view,"");data.setTypeface(android.graphics.Typeface.MONOSPACE);data.setTextIsSelectable(true);
        button(view,"Read 256 bytes",()->{try{int start=(int)parseHex(address.getText().toString());String id=DOMAIN_IDS[domain.getSelectedItemPosition()];io.execute(()->{try{byte[]bytes=NativeBridge.readMemory(engine,id,start,256);StringBuilder out=new StringBuilder();for(int i=0;i<bytes.length;i++){if(i%16==0)out.append(String.format(Locale.US,"%n%06X: ",start+i));out.append(String.format(Locale.US,"%02X ",bytes[i]&255));}main.post(()->data.setText(out.toString()));}catch(Throwable e){main.post(()->showError("Memory inspector",e.toString()));}});}catch(Exception e){showError("Memory inspector",e.getMessage());}});
        button(view,"Domain metadata / native resources",()->io.execute(()->{String text=NativeBridge.domains(engine);main.post(()->data.setText("Domains\n"+pretty(text)+"\n\nNative resources\n"+pretty(lastStatus.toString())));}));
        button(view,"Palette / tile / register viewer",this::showResourceTools);
        trackDialog(new MenuPanel.Builder(this).setTitle("Memory inspector / resources").setView(scrolling(view)).setPositiveButton("Close",null).create());
    }
    private void showResourceTools(){
        LinearLayout view=column();label(view,"Read-only snapshots of live native VDP resources. These tools do not change emulator memory.");
        ImageView paletteImage=new ImageView(this);paletteImage.setAdjustViewBounds(true);view.addView(paletteImage,new LinearLayout.LayoutParams(-1,dp(120)));
        button(view,"Read all 64 CRAM colors",()->io.execute(()->{
            try{byte[]cram=NativeBridge.readMemory(engine,"cram",0,128);int[]colors=cramColors(cram);Bitmap image=Bitmap.createBitmap(16*16,4*16,Bitmap.Config.ARGB_8888);for(int y=0;y<64;y++)for(int x=0;x<256;x++)image.setPixel(x,y,colors[(y/16)*16+x/16]);main.post(()->setSharpImage(paletteImage,image));}
            catch(Throwable e){main.post(()->showError("Palette viewer",e.toString()));}
        }));
        Spinner palette=spinner(view,"Tile palette",new String[]{"Palette 0","Palette 1","Palette 2","Palette 3"},0);
        EditText first=field(view,"First tile index (hex, 0–7FF)","0");
        ImageView tilesImage=new ImageView(this);tilesImage.setAdjustViewBounds(true);view.addView(tilesImage,new LinearLayout.LayoutParams(-1,dp(280)));
        button(view,"Read 256 VRAM tiles",()->{
            try{int tile=(int)parseHex(first.getText().toString());if(tile>0x7FF)throw new IllegalArgumentException("Tile index must be 0–7FF.");int selectedPalette=palette.getSelectedItemPosition();io.execute(()->{
                try{byte[]vram=NativeBridge.readMemory(engine,"vram",tile*32,Math.min(8192,65536-tile*32));int[]colors=cramColors(NativeBridge.readMemory(engine,"cram",0,128));Bitmap image=Bitmap.createBitmap(128,128,Bitmap.Config.ARGB_8888);image.eraseColor(Color.BLACK);
                    for(int t=0;t<vram.length/32;t++)for(int y=0;y<8;y++)for(int x=0;x<8;x++){int pair=vram[t*32+y*4+x/2]&255,index=x%2==0?pair>>>4:pair&15;image.setPixel((t%16)*8+x,(t/16)*8+y,colors[selectedPalette*16+index]);}
                    main.post(()->setSharpImage(tilesImage,image));
                }catch(Throwable e){main.post(()->showError("Tile viewer",e.toString()));}
            });}catch(Exception e){showError("Tile viewer",e.getMessage());}
        });
        TextView registers=label(view,"");registers.setTypeface(android.graphics.Typeface.MONOSPACE);registers.setTextIsSelectable(true);
        button(view,"Read CPU / VDP registers",()->command("debug",json("kind","registers"),text->{if(successful(text))registers.setText(pretty(text));}));
        trackDialog(new MenuPanel.Builder(this).setTitle("Native palette, tiles and registers").setView(scrolling(view)).setPositiveButton("Close",null).create());
    }
    private int[] cramColors(byte[]bytes){int[]colors=new int[64];for(int i=0;i<64;i++){int word=i*2+1<bytes.length?((bytes[i*2]&255)<<8)|(bytes[i*2+1]&255):0;colors[i]=Color.rgb(((word>>>1)&7)*255/7,((word>>>5)&7)*255/7,((word>>>9)&7)*255/7);}return colors;}
    private void setSharpImage(ImageView target,Bitmap image){BitmapDrawable drawable=new BitmapDrawable(getResources(),image);drawable.setFilterBitmap(false);drawable.setAntiAlias(false);target.setImageDrawable(drawable);}
    private String pretty(String text){try{return new JSONObject(text).toString(2);}catch(Exception e){try{return new JSONArray(text).toString(2);}catch(Exception ignored){return text;}}}
    private void showImportExport(){
        LinearLayout view=column();button(view,"Export native save state",()->exportFile("state","BadGenesis-state.bgs"));button(view,"Import native save state",()->pick("state"));
        button(view,"Export cartridge SRAM",()->exportFile("sram","BadGenesis-SRAM.srm"));button(view,"Import cartridge SRAM",()->pick("sram"));
        button(view,"Export corrupted ROM working copy",()->exportFile("rom","BadGenesis-corrupted.bin"));
        button(view,"Export Blast History",()->exportFile("history","BadGenesis-blast-history.json"));button(view,"Export harvested results",()->exportFile("harvest","BadGenesis-harvest.bgh"));button(view,"Import harvested results",()->pick("harvest"));
        label(view,"Export always creates a new document. BadGenesis never opens the original ROM for writing.");
        trackDialog(new MenuPanel.Builder(this).setTitle("Import / export").setView(scrolling(view)).setPositiveButton("Close",null).create());
    }
    private void pick(String kind){pendingImport=kind;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);try{startActivityForResult(i,PICK_DOCUMENT);}catch(Exception e){showError("Open document",e.toString());}}
    private void exportFile(String kind,String filename){
        if(!loaded){showError("No content loaded","Open Genesis / Mega Drive content first.");return;}
        io.execute(()->{try{byte[]bytes=kind.equals("state")?NativeBridge.exportState(engine):NativeBridge.exportData(engine,kind);if(bytes==null||bytes.length==0)throw new IllegalStateException("No "+kind+" data is available.");main.post(()->{pendingExport=bytes;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/octet-stream").putExtra(Intent.EXTRA_TITLE,filename);try{startActivityForResult(i,EXPORT_DOCUMENT);}catch(Exception e){pendingExport=null;showError("Export",e.toString());}});}catch(Throwable e){main.post(()->showError("Export",e.toString()));}});
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null||data.getData()==null){if(request==EXPORT_DOCUMENT)pendingExport=null;return;}Uri uri=data.getData();
        if(request==PICK_DOCUMENT){String kind=pendingImport;
            try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
            if(kind.equals("rom")){openRomDocument(uri,null);return;}
            io.execute(()->{try{String name=documentName(uri);byte[]bytes;try(InputStream in=getContentResolver().openInputStream(uri)){if(in==null)throw new IllegalStateException("The selected document could not be opened.");bytes=readLimited(in,MAX_DOCUMENT);}
                String error=kind.equals("state")?NativeBridge.importState(engine,bytes):NativeBridge.importData(engine,kind,bytes);main.post(()->{if(error!=null&&!error.isEmpty())showError("Import",error);});
            }catch(Throwable e){main.post(()->showError("Open document",e.getMessage()==null?e.toString():e.getMessage()));}});
        }else if(request==EXPORT_DOCUMENT){byte[]bytes=pendingExport;pendingExport=null;if(bytes==null)return;io.execute(()->{try(OutputStream out=getContentResolver().openOutputStream(uri,"w")){if(out==null)throw new IllegalStateException("Could not create the export document.");out.write(bytes);}catch(Exception e){main.post(()->showError("Export",e.toString()));}});}
    }
    private void loadRom(byte[] bytes,String name,Uri source,String entry){String error=NativeBridge.loadRom(engine,bytes,name);main.post(()->{if(error!=null&&!error.isEmpty()){showError("Load ROM",error);return;}loaded=true;romName=name;lastError="";prefs.edit().putBoolean("rtc.auto",false).apply();recordRecent(source,name,entry);closeMenus();applyRtc();applyRewind();applySpeed();applyDisplay();dispatchPause();dispatchAudio();});}
    private String documentName(Uri uri){try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){if(c!=null&&c.moveToFirst())return c.getString(0);}catch(Exception ignored){}return "Genesis ROM";}
    private byte[] readLimited(InputStream in,int limit)throws Exception{ByteArrayOutputStream out=new ByteArrayOutputStream();byte[]buffer=new byte[16384];int n,total=0;while((n=in.read(buffer))!=-1){total+=n;if(total>limit)throw new IllegalArgumentException("This document exceeds the 64 MiB safety limit.");out.write(buffer,0,n);}return out.toByteArray();}
    private List<String> zipRomNames(byte[] bytes)throws Exception{List<String>names=new ArrayList<>();try(ZipInputStream zip=new ZipInputStream(new ByteArrayInputStream(bytes))){ZipEntry e;while((e=zip.getNextEntry())!=null){String n=e.getName().toLowerCase(Locale.ROOT);if(!e.isDirectory()&&(n.endsWith(".bin")||n.endsWith(".md")||n.endsWith(".gen")||n.endsWith(".smd")))names.add(e.getName());if(names.size()>100)break;}}return names;}
    private byte[] zipRom(byte[]bytes,String entry)throws Exception{try(ZipInputStream zip=new ZipInputStream(new ByteArrayInputStream(bytes))){ZipEntry e;while((e=zip.getNextEntry())!=null)if(e.getName().equals(entry))return readLimited(zip,MAX_DOCUMENT);}throw new IllegalArgumentException("ROM entry was not found in the ZIP.");}
    private void chooseZip(byte[] archive,List<String> names,Uri source){trackDialog(new MenuPanel.Builder(this).setTitle("Select ROM from ZIP").setItems(names.toArray(new String[0]),(d,index)->io.execute(()->{try{String name=names.get(index);loadRom(zipRom(archive,name),name,source,name);}catch(Throwable e){main.post(()->showError("Load ZIP ROM",e.toString()));}})).setNegativeButton("Cancel",null).create());}
    private void vibrate(){if(!prefs.getBoolean("vibration",true)||vibrator==null||!vibrator.hasVibrator())return;try{vibrator.vibrate(VibrationEffect.createOneShot(12,VibrationEffect.DEFAULT_AMPLITUDE));}catch(Exception ignored){}}
    private void sendButtons(){int mask=touchMask;for(Set<Integer>keys:padKeys.values())for(int key:keys)mask|=keyBit(key);for(int axes:padAxes.values())mask|=axes;if(dialogs>0||editingControls||!resumed)mask=0;if(mask==sentMask)return;sentMask=mask;int buttons=mask;if(engineReady&&!destroyed)io.execute(()->{if(engine!=0&&!destroyed)NativeBridge.setButtons(engine,buttons);});}
    private void sendRewind(){boolean held=touchRewind;for(Set<Integer>keys:rewindKeys.values())held|=!keys.isEmpty();for(boolean value:rewindAxes.values())held|=value;if(dialogs>0||editingControls||!resumed)held=false;if(held==sentRewind)return;sentRewind=held;command("rewind",json("held",held),null);}
    private void sendFastForward(){boolean held=touchFastForward;for(Set<Integer>keys:fastForwardKeys.values())held|=!keys.isEmpty();for(boolean value:fastForwardAxes.values())held|=value;if(dialogs>0||editingControls||!resumed)held=false;if(held==sentFastForward)return;sentFastForward=held;command("fast_forward",json("held",held),null);}
    private void releaseHeldInputs(){controls.release();padKeys.clear();padAxes.clear();rewindKeys.clear();rewindAxes.clear();fastForwardKeys.clear();fastForwardAxes.clear();touchMask=0;touchRewind=false;touchFastForward=false;sendButtons();sendRewind();sendFastForward();}
    private int keyBit(int key){switch(key){case KeyEvent.KEYCODE_DPAD_UP:return ControlsView.UP;case KeyEvent.KEYCODE_DPAD_DOWN:return ControlsView.DOWN;case KeyEvent.KEYCODE_DPAD_LEFT:return ControlsView.LEFT;case KeyEvent.KEYCODE_DPAD_RIGHT:return ControlsView.RIGHT;case KeyEvent.KEYCODE_BUTTON_X:case KeyEvent.KEYCODE_Z:return ControlsView.A;case KeyEvent.KEYCODE_BUTTON_A:case KeyEvent.KEYCODE_X:return ControlsView.B;case KeyEvent.KEYCODE_BUTTON_B:case KeyEvent.KEYCODE_C:return ControlsView.C;case KeyEvent.KEYCODE_BUTTON_Y:case KeyEvent.KEYCODE_A:return ControlsView.X;case KeyEvent.KEYCODE_BUTTON_L1:case KeyEvent.KEYCODE_S:return ControlsView.Y;case KeyEvent.KEYCODE_BUTTON_R1:case KeyEvent.KEYCODE_D:return ControlsView.Z;case KeyEvent.KEYCODE_BUTTON_START:case KeyEvent.KEYCODE_ENTER:return ControlsView.START;case KeyEvent.KEYCODE_BUTTON_SELECT:case KeyEvent.KEYCODE_SHIFT_LEFT:case KeyEvent.KEYCODE_SHIFT_RIGHT:return ControlsView.MODE;default:return 0;}}
    @Override public boolean dispatchKeyEvent(KeyEvent e){
        if(e.getKeyCode()==KeyEvent.KEYCODE_BACK){if(e.getAction()==KeyEvent.ACTION_UP)showMenu();return true;}
        if(dialogs>0||editingControls)return super.dispatchKeyEvent(e);
        if(e.getKeyCode()==KeyEvent.KEYCODE_BUTTON_L2||e.getKeyCode()==KeyEvent.KEYCODE_R){Set<Integer>keys=rewindKeys.computeIfAbsent(e.getDeviceId(),id->new HashSet<>());if(e.getAction()==KeyEvent.ACTION_DOWN)keys.add(e.getKeyCode());else if(e.getAction()==KeyEvent.ACTION_UP)keys.remove(e.getKeyCode());sendRewind();return true;}
        if(e.getKeyCode()==KeyEvent.KEYCODE_BUTTON_R2||e.getKeyCode()==KeyEvent.KEYCODE_F){Set<Integer>keys=fastForwardKeys.computeIfAbsent(e.getDeviceId(),id->new HashSet<>());if(e.getAction()==KeyEvent.ACTION_DOWN)keys.add(e.getKeyCode());else if(e.getAction()==KeyEvent.ACTION_UP)keys.remove(e.getKeyCode());sendFastForward();return true;}
        int bit=keyBit(e.getKeyCode());if(bit!=0){Set<Integer>keys=padKeys.computeIfAbsent(e.getDeviceId(),id->new HashSet<>());if(e.getAction()==KeyEvent.ACTION_DOWN)keys.add(e.getKeyCode());else if(e.getAction()==KeyEvent.ACTION_UP)keys.remove(e.getKeyCode());sendButtons();return true;}
        return super.dispatchKeyEvent(e);
    }
    private float axis(MotionEvent e,int axis){float value=e.getAxisValue(axis);InputDevice d=e.getDevice();InputDevice.MotionRange range=d==null?null:d.getMotionRange(axis,e.getSource());float flat=range==null?.15f:Math.max(.15f,range.getFlat());return Math.abs(value)>flat?value:0;}
    @Override public boolean onGenericMotionEvent(MotionEvent e){
        if((e.getSource()&InputDevice.SOURCE_JOYSTICK)==InputDevice.SOURCE_JOYSTICK&&e.getAction()==MotionEvent.ACTION_MOVE){
            float x=axis(e,MotionEvent.AXIS_X),y=axis(e,MotionEvent.AXIS_Y),hatX=axis(e,MotionEvent.AXIS_HAT_X),hatY=axis(e,MotionEvent.AXIS_HAT_Y);if(hatX!=0)x=hatX;if(hatY!=0)y=hatY;int mask=0;
            if(x<-.35f)mask|=ControlsView.LEFT;else if(x>.35f)mask|=ControlsView.RIGHT;if(y<-.35f)mask|=ControlsView.UP;else if(y>.35f)mask|=ControlsView.DOWN;
            padAxes.put(e.getDeviceId(),mask);rewindAxes.put(e.getDeviceId(),axis(e,MotionEvent.AXIS_LTRIGGER)>.5f);fastForwardAxes.put(e.getDeviceId(),axis(e,MotionEvent.AXIS_RTRIGGER)>.5f);sendButtons();sendRewind();sendFastForward();return true;
        }return super.onGenericMotionEvent(e);
    }
    @Override public void onInputDeviceAdded(int id){}@Override public void onInputDeviceChanged(int id){}@Override public void onInputDeviceRemoved(int id){padKeys.remove(id);padAxes.remove(id);rewindKeys.remove(id);rewindAxes.remove(id);fastForwardKeys.remove(id);fastForwardAxes.remove(id);sendButtons();sendRewind();sendFastForward();}
    private void immersive(){if(Build.VERSION.SDK_INT>=30){WindowInsetsController c=getWindow().getInsetsController();if(c!=null){c.hide(WindowInsets.Type.systemBars());c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);}}else getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE);}
    @Override protected void onResume(){super.onResume();resumed=true;hasAudioFocus=audioManager.requestAudioFocus(focusRequest)==AudioManager.AUDIOFOCUS_REQUEST_GRANTED;dispatchPause();dispatchAudio();immersive();}
    @Override protected void onPause(){resumed=false;releaseHeldInputs();dispatchPause();dispatchAudio();audioManager.abandonAudioFocusRequest(focusRequest);super.onPause();}
    @Override public void onConfigurationChanged(Configuration config){super.onConfigurationChanged(config);controls.reload();immersive();}
    @Override public void onWindowFocusChanged(boolean focus){super.onWindowFocusChanged(focus);if(focus)immersive();else if(controls!=null)releaseHeldInputs();}
    @Override public void onBackPressed(){showMenu();}
    @Override protected void onDestroy(){destroyed=true;main.removeCallbacksAndMessages(null);inputManager.unregisterInputDeviceListener(this);if(Build.VERSION.SDK_INT>=33&&backCallback!=null)getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(backCallback);io.execute(()->{if(engine!=0){NativeBridge.destroy(engine);engine=0;}});io.shutdown();super.onDestroy();}
    private int dp(float value){return (int)(getResources().getDisplayMetrics().density*value+.5f);}
}

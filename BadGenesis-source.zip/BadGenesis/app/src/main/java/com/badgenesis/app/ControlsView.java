package com.badgenesis.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Build;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowInsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/** Native vector controls; Android pointer IDs own their independent held buttons. */
public final class ControlsView extends View {
    public static final int UP=1, DOWN=2, LEFT=4, RIGHT=8, A=16, B=32, C=64,
        X=128, Y=256, Z=512, START=1024, MODE=2048;
    public interface Listener {
        void buttonsChanged(int buttons);
        void rewindHeld(boolean held);
        void fastForwardHeld(boolean held);
        void pressed();
    }
    private static final int REWIND=4096, FAST_FORWARD=8192;
    private static final int GAME_BUTTONS=4095;
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final SharedPreferences prefs;
    private final Listener listener;
    private final Map<Integer,Integer> pointers=new HashMap<>();
    private final Map<Integer,Drag> drags=new HashMap<>();
    private final ArrayList<Button> buttons=new ArrayList<>();
    private final RectF padBounds=new RectF(), ffBounds=new RectF(), rewBounds=new RectF();
    private final Path cross=new Path(), triangle=new Path(), forwardIcon=new Path(), rewindIcon=new Path();
    private LinearGradient padRim, crossFill;
    private RadialGradient padFace, padCenter;
    private int lastMask;
    private float scale, opacity, padOffsetX, padOffsetY, buttonOffsetX, buttonOffsetY, systemOffsetX, systemOffsetY;
    private boolean sixButton, hidden, editing;
    private float padX, padY, padRadius, unit;
    private int safeLeft, safeTop;
    private final float density;
    private static final class Drag { int group; float x,y,ox,oy; }
    private static final class Button {
        int bit;
        boolean pill;
        String label;
        RectF bounds, face;
        Path gloss;
        Shader rim, fill, shine;
    }

    public ControlsView(Context context, Listener listener) {
        super(context);
        this.listener=listener;
        density=getResources().getDisplayMetrics().density;
        prefs=context.getSharedPreferences("native_controls",Context.MODE_PRIVATE);
        paint.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
        setFocusable(false);
        setContentDescription("Genesis multitouch controls, hold fast forward or rewind");
        reload();
    }
    public void reload() {
        scale=clamp(prefs.getFloat("size",1f),.55f,1.8f);
        opacity=clamp(prefs.getFloat("opacity",.65f),0f,1f);
        padOffsetX=prefs.getFloat("padX",0); padOffsetY=prefs.getFloat("padY",0);
        buttonOffsetX=prefs.getFloat("buttonsX",0); buttonOffsetY=prefs.getFloat("buttonsY",0);
        systemOffsetX=prefs.getFloat("systemX",0); systemOffsetY=prefs.getFloat("systemY",0);
        sixButton=prefs.getBoolean("sixButton",true); hidden=prefs.getBoolean("hidden",false);
        release(); layoutControls(); invalidate();
    }
    public void setEditing(boolean enabled) { editing=enabled; release(); invalidate(); }
    public boolean isEditing() { return editing; }
    public void release() { pointers.clear(); drags.clear(); publish(); }
    private float clamp(float value,float min,float max) { return Math.max(min,Math.min(max,value)); }
    @Override protected void onSizeChanged(int w,int h,int oldw,int oldh) { release(); layoutControls(); }
    @Override public WindowInsets onApplyWindowInsets(WindowInsets insets) {
        int left=0, top=0;
        if(Build.VERSION.SDK_INT>=30) {
            android.graphics.Insets safe=insets.getInsets(WindowInsets.Type.displayCutout());
            left=safe.left; top=safe.top;
        } else if(Build.VERSION.SDK_INT>=28&&insets.getDisplayCutout()!=null) {
            left=insets.getDisplayCutout().getSafeInsetLeft(); top=insets.getDisplayCutout().getSafeInsetTop();
        }
        if(left!=safeLeft||top!=safeTop) {
            safeLeft=left; safeTop=top; release(); layoutControls(); invalidate();
        }
        return super.onApplyWindowInsets(insets);
    }
    private void layoutControls() {
        if(getWidth()==0||getHeight()==0) return;
        buttons.clear();
        float width=getWidth(), height=getHeight();
        boolean landscape=width>height;
        unit=Math.min(width,height)*(landscape?.14f:.12f)*scale;
        padRadius=unit*1.25f;
        padX=clamp(width*(landscape?.13f:.18f)+padOffsetX*width,padRadius+3*density,width-padRadius-3*density);
        padY=clamp(height*(landscape?.685f:.82f)+padOffsetY*height,padRadius+3*density,height-padRadius-3*density);
        padBounds.set(padX-padRadius,padY-padRadius,padX+padRadius,padY+padRadius);
        float bx=clamp(width*(landscape?.885f:.79f)+buttonOffsetX*width,unit*1.65f,width-unit*1.65f);
        float by=clamp(height*(landscape?.72f:.855f)+buttonOffsetY*height,unit*(sixButton?1.80f:1.05f),height-unit*1.04f);
        float radius=unit*.49f;
        // A, B and C follow the descending arc of the reference Genesis controller.
        addCircle(A,"A",bx-unit*1.12f,by-unit*.48f,radius,0xff609722,0xffacd95c,0xff29440e);
        addCircle(B,"B",bx,by,radius,0xffa92a2d,0xffdf6462,0xff4b1012);
        addCircle(C,"C",bx+unit*1.12f,by+unit*.48f,radius,0xff7335a5,0xffae6dde,0xff34134e);
        if(sixButton) {
            addCircle(X,"X",bx-unit*1.12f,by-unit*1.40f,radius*.73f,0xff44464b,0xff92959d,0xff17191e);
            addCircle(Y,"Y",bx,by-unit*.92f,radius*.73f,0xff44464b,0xff92959d,0xff17191e);
            addCircle(Z,"Z",bx+unit*1.12f,by-unit*.44f,radius*.73f,0xff44464b,0xff92959d,0xff17191e);
        }
        float systemX=clamp(width*(landscape?.518f:.5f)+systemOffsetX*width,unit*1.15f,width-unit*1.15f);
        float systemY=clamp(height*(landscape?.931f:.945f)+systemOffsetY*height,unit*.3f,height-unit*.28f-3*density);
        addPill(MODE,"Mode",systemX-unit*.56f,systemY);
        addPill(START,"Start",systemX+unit*.56f,systemY);
        makePadArt();
        float toolbar=48*density, margin=8*density;
        ffBounds.set(safeLeft+margin,safeTop+margin,safeLeft+margin+toolbar,safeTop+margin+toolbar);
        rewBounds.set(ffBounds.right+4*density,safeTop+margin,ffBounds.right+4*density+toolbar,safeTop+margin+toolbar);
        makeTransportIcon(forwardIcon,ffBounds,false);
        makeTransportIcon(rewindIcon,rewBounds,true);
    }
    private void addCircle(int bit,String label,float x,float y,float radius,int color,int highlight,int dark) {
        Button button=new Button(); button.bit=bit; button.label=label;
        button.bounds=new RectF(x-radius,y-radius,x+radius,y+radius);
        button.face=new RectF(x-radius*.81f,y-radius*.81f,x+radius*.81f,y+radius*.81f);
        button.rim=new LinearGradient(x,y-radius,x,y+radius,new int[]{0xff7e8081,0xff28292b,0xff111214,0xff77797a},new float[]{0,.36f,.65f,1},Shader.TileMode.CLAMP);
        button.fill=new RadialGradient(x-radius*.30f,y-radius*.42f,radius*1.55f,new int[]{highlight,color,dark},new float[]{0,.48f,1},Shader.TileMode.CLAMP);
        button.shine=new LinearGradient(x,y-radius*.80f,x,y-radius*.18f,0x48ffffff,0x00ffffff,Shader.TileMode.CLAMP);
        button.gloss=new Path();
        button.gloss.moveTo(x-radius*.73f,y-radius*.24f);
        button.gloss.cubicTo(x-radius*.63f,y-radius*.86f,x+radius*.60f,y-radius*.86f,x+radius*.74f,y-radius*.24f);
        button.gloss.cubicTo(x+radius*.40f,y-radius*.42f,x-radius*.40f,y-radius*.42f,x-radius*.73f,y-radius*.24f);
        button.gloss.close(); buttons.add(button);
    }
    private void addPill(int bit,String label,float x,float y) {
        Button button=new Button(); button.bit=bit; button.label=label; button.pill=true;
        button.bounds=new RectF(x-unit*.49f,y-unit*.225f,x+unit*.49f,y+unit*.225f);
        button.face=new RectF(button.bounds); button.face.inset(unit*.047f,unit*.044f);
        button.rim=new LinearGradient(x,button.bounds.top,x,button.bounds.bottom,new int[]{0xffa8acb2,0xff4b4f55,0xff1e2024,0xff94979e},new float[]{0,.28f,.6f,1},Shader.TileMode.CLAMP);
        button.fill=new LinearGradient(x,button.face.top,x,button.face.bottom,new int[]{0xff767b83,0xff50545e,0xff2e3138},null,Shader.TileMode.CLAMP);
        buttons.add(button);
    }
    private void makePadArt() {
        float r=padRadius;
        padRim=new LinearGradient(0,-r,0,r,new int[]{0xff77797a,0xff202123,0xff101113,0xff636567},new float[]{0,.31f,.64f,1},Shader.TileMode.CLAMP);
        padFace=new RadialGradient(-r*.28f,-r*.36f,r*1.48f,new int[]{0xff222426,0xff101113,0xff08090a},null,Shader.TileMode.CLAMP);
        crossFill=new LinearGradient(0,-r,0,r,new int[]{0xff333537,0xff17191b,0xff101214},null,Shader.TileMode.CLAMP);
        padCenter=new RadialGradient(-r*.035f,-r*.025f,r*.22f,0xff08090a,0xff17191b,Shader.TileMode.CLAMP);
        cross.reset();
        cross.moveTo(-r*.13f,-r*.86f);
        cross.cubicTo(-r*.31f,-r*.86f,-r*.23f,-r*.59f,-r*.35f,-r*.43f);
        cross.cubicTo(-r*.46f,-r*.26f,-r*.65f,-r*.24f,-r*.78f,-r*.24f);
        cross.quadTo(-r*.90f,-r*.24f,-r*.90f,-r*.10f);
        cross.lineTo(-r*.90f,r*.10f);
        cross.quadTo(-r*.90f,r*.24f,-r*.78f,r*.24f);
        cross.cubicTo(-r*.65f,r*.24f,-r*.46f,r*.26f,-r*.35f,r*.43f);
        cross.cubicTo(-r*.23f,r*.59f,-r*.31f,r*.86f,-r*.13f,r*.86f);
        cross.quadTo(0,r*.90f,r*.13f,r*.86f);
        cross.cubicTo(r*.31f,r*.86f,r*.23f,r*.59f,r*.35f,r*.43f);
        cross.cubicTo(r*.46f,r*.26f,r*.65f,r*.24f,r*.78f,r*.24f);
        cross.quadTo(r*.90f,r*.24f,r*.90f,r*.10f);
        cross.lineTo(r*.90f,-r*.10f);
        cross.quadTo(r*.90f,-r*.24f,r*.78f,-r*.24f);
        cross.cubicTo(r*.65f,-r*.24f,r*.46f,-r*.26f,r*.35f,-r*.43f);
        cross.cubicTo(r*.23f,-r*.59f,r*.31f,-r*.86f,r*.13f,-r*.86f);
        cross.quadTo(0,-r*.90f,-r*.13f,-r*.86f); cross.close();
        triangle.reset(); triangle.moveTo(0,-r*.73f); triangle.lineTo(r*.095f,-r*.565f); triangle.lineTo(-r*.095f,-r*.565f); triangle.close();
    }
    private void makeTransportIcon(Path path,RectF bounds,boolean backwards) {
        path.reset(); float width=bounds.width()*.30f, height=bounds.height()*.39f;
        float left=bounds.centerX()-width, top=bounds.centerY()-height*.5f;
        for(int i=0;i<2;i++) {
            float x=left+i*width;
            path.moveTo(x+(backwards?width:0),top);
            path.lineTo(x+(backwards?0:width),top+height*.5f);
            path.lineTo(x+(backwards?width:0),top+height); path.close();
        }
    }
    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if(!hidden||editing) {
            drawDpad(canvas);
            for(Button button:buttons) drawButton(canvas,button);
        }
        // Transport controls stay available when a physical controller hides the virtual pad.
        if(!editing) { drawTransport(canvas,forwardIcon,ffBounds,FAST_FORWARD); drawTransport(canvas,rewindIcon,rewBounds,REWIND); }
        else {
            resetPaint(); paint.setColor(Color.WHITE); paint.setTextSize(14*density); paint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("Drag the D-pad, action buttons, or Mode/Start. Tap Done to save.",getWidth()/2f,30*density,paint);
        }
    }
    private void resetPaint() { paint.setShader(null); paint.setStyle(Paint.Style.FILL); paint.setAlpha(255); paint.setStrokeWidth(1); }
    private void drawDpad(Canvas canvas) {
        float r=padRadius;
        int layer=canvas.saveLayerAlpha(padBounds.left-3*density,padBounds.top-3*density,padBounds.right+3*density,padBounds.bottom+3*density,(int)(255*opacity));
        canvas.translate(padX,padY); resetPaint();
        paint.setColor(0xff08090a); canvas.drawCircle(0,1.5f*density,r+1.5f*density,paint);
        paint.setShader(padRim); canvas.drawCircle(0,0,r,paint);
        paint.setShader(padFace); canvas.drawCircle(0,0,r*.946f,paint);
        paint.setShader(null); paint.setColor(0xff08090a); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(r*.06f); canvas.drawPath(cross,paint);
        paint.setColor(0xff444649); paint.setStrokeWidth(r*.027f); canvas.drawPath(cross,paint);
        paint.setStyle(Paint.Style.FILL); paint.setShader(crossFill); canvas.drawPath(cross,paint);
        paint.setShader(padCenter); canvas.drawCircle(0,0,r*.22f,paint); paint.setShader(null);
        drawPadArrow(canvas,0,UP); drawPadArrow(canvas,90,RIGHT); drawPadArrow(canvas,180,DOWN); drawPadArrow(canvas,270,LEFT);
        canvas.restoreToCount(layer);
    }
    private void drawPadArrow(Canvas canvas,int rotation,int bit) {
        int save=canvas.save(); canvas.rotate(rotation);
        paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(padRadius*.018f); paint.setColor(0xff3d4043); canvas.drawPath(triangle,paint);
        paint.setStyle(Paint.Style.FILL); paint.setColor((lastMask&bit)!=0?0xff8d9297:0xff070809); canvas.drawPath(triangle,paint);
        canvas.restoreToCount(save);
    }
    private void drawButton(Canvas canvas,Button button) {
        RectF bounds=button.bounds;
        int layer=canvas.saveLayerAlpha(bounds.left-3*density,bounds.top-3*density,bounds.right+3*density,bounds.bottom+3*density,(int)(255*opacity));
        resetPaint(); paint.setColor(0xff08090a);
        float radius=bounds.height()*.5f;
        if(button.pill) {
            canvas.drawRoundRect(bounds.left,bounds.top+1.5f*density,bounds.right,bounds.bottom+1.5f*density,radius,radius,paint);
            paint.setShader(button.rim); canvas.drawRoundRect(bounds,radius,radius,paint);
            paint.setShader(button.fill); canvas.drawRoundRect(button.face,radius,radius,paint);
        } else {
            canvas.drawCircle(bounds.centerX(),bounds.centerY()+1.4f*density,radius+1.4f*density,paint);
            paint.setShader(button.rim); canvas.drawOval(bounds,paint);
            paint.setShader(null); paint.setColor(0xff101113); canvas.drawCircle(bounds.centerX(),bounds.centerY(),radius*.87f,paint);
            paint.setShader(button.fill); canvas.drawOval(button.face,paint);
            paint.setShader(button.shine); canvas.drawPath(button.gloss,paint);
        }
        paint.setShader(null);
        if((lastMask&button.bit)!=0) {
            paint.setColor(0x35ffffff);
            if(button.pill) canvas.drawRoundRect(button.face,radius,radius,paint); else canvas.drawOval(button.face,paint);
        }
        paint.setColor(button.pill?0xffbfc3cb:0xff1b191d);
        paint.setTextAlign(Paint.Align.CENTER); paint.setTextSize(button.pill?unit*.24f:bounds.height()*.43f);
        float textY=bounds.centerY()-(paint.ascent()+paint.descent())*.5f;
        if((lastMask&button.bit)!=0) textY+=density;
        canvas.drawText(button.label,bounds.centerX(),textY,paint);
        canvas.restoreToCount(layer);
    }
    private void drawTransport(Canvas canvas,Path path,RectF bounds,int bit) {
        resetPaint();
        if((lastMask&bit)!=0) {
            paint.setColor(0x4dffffff); canvas.drawRoundRect(bounds,8*density,8*density,paint);
        }
        paint.setColor((lastMask&bit)!=0?0xffdedede:0xff757575); canvas.drawPath(path,paint);
    }
    private int hit(float x,float y) {
        if(ffBounds.contains(x,y)) return FAST_FORWARD;
        if(rewBounds.contains(x,y)) return REWIND;
        if(hidden&&!editing) return 0;
        float dx=x-padX, dy=y-padY, distance=dx*dx+dy*dy;
        if(distance<=padRadius*padRadius*1.08f) {
            if(distance<padRadius*padRadius*.025f) return 0;
            int mask=0; float ax=Math.abs(dx), ay=Math.abs(dy);
            // Eight sectors provide reliable diagonals without requiring tiny corner targets.
            if(ax>ay*.41421356f) mask|=dx<0?LEFT:RIGHT;
            if(ay>ax*.41421356f) mask|=dy<0?UP:DOWN;
            return mask;
        }
        for(Button button:buttons) {
            RectF bounds=button.bounds;
            float nx=(x-bounds.centerX())/(bounds.width()*.5f), ny=(y-bounds.centerY())/(bounds.height()*.5f);
            if(nx*nx+ny*ny<=1.12f) return button.bit;
        }
        return 0;
    }
    @Override public boolean onTouchEvent(MotionEvent event) {
        int action=event.getActionMasked(),index=event.getActionIndex(),id=event.getPointerId(index);
        if(action==MotionEvent.ACTION_CANCEL) { release(); return true; }
        if(editing) return editTouch(event,action,index,id);
        if(action==MotionEvent.ACTION_DOWN&&hidden&&hit(event.getX(index),event.getY(index))==0) return false;
        if(action==MotionEvent.ACTION_DOWN||action==MotionEvent.ACTION_POINTER_DOWN) pointers.put(id,hit(event.getX(index),event.getY(index)));
        else if(action==MotionEvent.ACTION_MOVE) for(int i=0;i<event.getPointerCount();i++) {
            int pointerId=event.getPointerId(i);
            if(pointers.containsKey(pointerId)) pointers.put(pointerId,hit(event.getX(i),event.getY(i)));
        } else if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_POINTER_UP) pointers.remove(id);
        publish(); if(action==MotionEvent.ACTION_UP) performClick(); return true;
    }
    @Override public boolean performClick() { super.performClick(); return true; }
    private boolean editTouch(MotionEvent event,int action,int index,int id) {
        if(action==MotionEvent.ACTION_DOWN||action==MotionEvent.ACTION_POINTER_DOWN) {
            Drag drag=new Drag(); drag.x=event.getX(index); drag.y=event.getY(index);
            int bit=hit(drag.x,drag.y);
            drag.group=(bit&(START|MODE))!=0?2:((bit&(A|B|C|X|Y|Z))!=0?1:(drag.x<getWidth()*.5f?0:1));
            drag.ox=drag.group==0?padOffsetX:(drag.group==1?buttonOffsetX:systemOffsetX);
            drag.oy=drag.group==0?padOffsetY:(drag.group==1?buttonOffsetY:systemOffsetY);
            drags.put(id,drag);
        } else if(action==MotionEvent.ACTION_MOVE) {
            for(int i=0;i<event.getPointerCount();i++) {
                Drag drag=drags.get(event.getPointerId(i)); if(drag==null) continue;
                float x=clamp(drag.ox+(event.getX(i)-drag.x)/getWidth(),-.5f,.5f);
                float y=clamp(drag.oy+(event.getY(i)-drag.y)/getHeight(),-.8f,.8f);
                if(drag.group==0) { padOffsetX=x; padOffsetY=y; }
                else if(drag.group==1) { buttonOffsetX=x; buttonOffsetY=y; }
                else { systemOffsetX=x; systemOffsetY=y; }
            }
            layoutControls(); invalidate();
        } else if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_POINTER_UP) {
            drags.remove(id);
            prefs.edit().putFloat("padX",padOffsetX).putFloat("padY",padOffsetY)
                .putFloat("buttonsX",buttonOffsetX).putFloat("buttonsY",buttonOffsetY)
                .putFloat("systemX",systemOffsetX).putFloat("systemY",systemOffsetY).apply();
        }
        return true;
    }
    private void publish() {
        int mask=0; for(int value:pointers.values()) mask|=value;
        if(mask==lastMask) return;
        if((mask&~lastMask)!=0) listener.pressed();
        if(((mask^lastMask)&REWIND)!=0) listener.rewindHeld((mask&REWIND)!=0);
        if(((mask^lastMask)&FAST_FORWARD)!=0) listener.fastForwardHeld((mask&FAST_FORWARD)!=0);
        lastMask=mask; listener.buttonsChanged(mask&GAME_BUTTONS); invalidate();
    }
}

package com.badgenesis.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;
import java.util.HashMap;
import java.util.Map;

/** Native touch overlay. Every Android pointer contributes independently. */
public final class ControlsView extends View {
    public static final int UP=1, DOWN=2, LEFT=4, RIGHT=8, A=16, B=32, C=64,
        X=128, Y=256, Z=512, START=1024, MODE=2048;
    public interface Listener { void buttonsChanged(int buttons); void rewindHeld(boolean held); void pressed(); }
    private static final int REWIND=4096;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final SharedPreferences prefs;
    private final Listener listener;
    private final Map<Integer,Integer> pointers = new HashMap<>();
    private final Map<Integer,Drag> drags = new HashMap<>();
    private final Map<Integer,RectF> regions = new HashMap<>();
    private int lastMask;
    private float scale, opacity, padOffsetX, padOffsetY, buttonOffsetX, buttonOffsetY;
    private boolean sixButton, hidden, editing;
    private float padX, padY, unit;
    private static final class Drag { int group; float x,y,ox,oy; }

    public ControlsView(Context context, Listener listener) {
        super(context); this.listener=listener;
        prefs=context.getSharedPreferences("native_controls",Context.MODE_PRIVATE);
        setFocusable(false); setContentDescription("Genesis multitouch controls"); reload();
    }
    public void reload() {
        scale=prefs.getFloat("size",1f); opacity=prefs.getFloat("opacity",.65f);
        padOffsetX=prefs.getFloat("padX",0); padOffsetY=prefs.getFloat("padY",0);
        buttonOffsetX=prefs.getFloat("buttonsX",0); buttonOffsetY=prefs.getFloat("buttonsY",0);
        sixButton=prefs.getBoolean("sixButton",true); hidden=prefs.getBoolean("hidden",false);
        release(); layoutControls(); invalidate();
    }
    public void setEditing(boolean enabled) { editing=enabled; release(); invalidate(); }
    public boolean isEditing() { return editing; }
    public void release() { pointers.clear(); drags.clear(); publish(); }
    private float clamp(float value,float min,float max) { return Math.max(min,Math.min(max,value)); }
    @Override protected void onSizeChanged(int w,int h,int oldw,int oldh) { layoutControls(); }
    private void layoutControls() {
        if (getWidth()==0 || getHeight()==0) return;
        regions.clear(); boolean landscape=getWidth()>getHeight();
        unit=Math.min(getWidth(),getHeight())*(landscape?.105f:.093f)*scale;
        float radius=unit*.45f;
        padX=clamp(getWidth()*(landscape?.14f:.20f)+padOffsetX*getWidth(),unit*1.5f,getWidth()-unit*1.5f);
        padY=clamp(getHeight()*(landscape?.68f:.81f)+padOffsetY*getHeight(),unit*1.5f,getHeight()-unit*1.5f);
        regions.put(UP,new RectF(padX-unit*1.45f,padY-unit*1.45f,padX+unit*1.45f,padY+unit*1.45f));
        float bx=clamp(getWidth()*(landscape?.83f:.80f)+buttonOffsetX*getWidth(),unit*1.4f,getWidth()-unit*1.4f);
        float by=clamp(getHeight()*(landscape?.73f:.84f)+buttonOffsetY*getHeight(),unit*1.3f,getHeight()-unit*.8f);
        put(A,bx-unit,by+unit*.13f,radius); put(B,bx,by-unit*.08f,radius); put(C,bx+unit,by-unit*.29f,radius);
        if (sixButton) { put(X,bx-unit,by-unit*1.0f,radius*.82f); put(Y,bx,by-unit*1.21f,radius*.82f); put(Z,bx+unit,by-unit*1.42f,radius*.82f); }
        float lower=Math.min(getHeight()-unit*.45f,padY+unit*1.2f);
        put(START,getWidth()*.51f,lower,unit*.52f); put(MODE,getWidth()*.40f,lower,unit*.45f);
        put(REWIND,getWidth()*.41f,Math.max(unit*.6f,lower-unit*.95f),unit*.47f);
    }
    private void put(int bit,float x,float y,float r) { regions.put(bit,new RectF(x-r,y-r,x+r,y+r)); }
    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas); if (hidden && !editing) return;
        paint.setAlpha((int)(255*opacity)); paint.setStyle(Paint.Style.FILL);
        float side=unit*.93f;
        drawPad(canvas,padX-side,padY-side*1.5f,padX+side,padY-side*.48f,UP,"↑");
        drawPad(canvas,padX-side,padY+side*.48f,padX+side,padY+side*1.5f,DOWN,"↓");
        drawPad(canvas,padX-side*1.5f,padY-side,padX-side*.48f,padY+side,LEFT,"←");
        drawPad(canvas,padX+side*.48f,padY-side,padX+side*1.5f,padY+side,RIGHT,"→");
        for (Map.Entry<Integer,RectF> entry:regions.entrySet()) {
            if (entry.getKey()==UP) continue;
            int bit=entry.getKey(); RectF rect=entry.getValue();
            paint.setColor((lastMask&bit)!=0?Color.rgb(214,45,48):Color.rgb(32,34,39));
            paint.setAlpha((int)(255*opacity)); canvas.drawOval(rect,paint);
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(2); paint.setColor(Color.rgb(208,211,216)); canvas.drawOval(rect,paint); paint.setStyle(Paint.Style.FILL);
            label(canvas,rect.centerX(),rect.centerY(),name(bit),unit*(bit>=START?.25f:.40f));
        }
        if (editing) {
            paint.setColor(Color.WHITE); paint.setAlpha(255); paint.setTextSize(unit*.35f); paint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("Drag the D-pad or action buttons. Tap Done to save.",getWidth()/2f,unit*1.3f,paint);
        }
    }
    private void drawPad(Canvas c,float l,float t,float r,float b,int bit,String label) {
        paint.setColor((lastMask&bit)!=0?Color.rgb(214,45,48):Color.rgb(32,34,39)); paint.setAlpha((int)(255*opacity));
        c.drawRoundRect(l,t,r,b,unit*.1f,unit*.1f,paint); label(c,(l+r)/2,(t+b)/2,label,unit*.39f);
    }
    private void label(Canvas c,float x,float y,String text,float size) {
        paint.setColor(Color.WHITE); paint.setAlpha((int)(255*opacity)); paint.setTextSize(size); paint.setTextAlign(Paint.Align.CENTER);
        c.drawText(text,x,y-(paint.ascent()+paint.descent())/2,paint);
    }
    private String name(int bit) {
        switch(bit) { case A:return "A"; case B:return "B"; case C:return "C"; case X:return "X"; case Y:return "Y"; case Z:return "Z"; case START:return "START"; case MODE:return "MODE"; default:return "REW"; }
    }
    private int hit(float x,float y) {
        RectF pad=regions.get(UP);
        if (pad!=null&&pad.contains(x,y)) {
            float dx=(x-padX)/unit,dy=(y-padY)/unit; int mask=0;
            if(dx<-.27f) mask|=LEFT; else if(dx>.27f) mask|=RIGHT;
            if(dy<-.27f) mask|=UP; else if(dy>.27f) mask|=DOWN;
            return mask;
        }
        for(Map.Entry<Integer,RectF> e:regions.entrySet()) if(e.getKey()!=UP&&e.getValue().contains(x,y)) return e.getKey();
        return 0;
    }
    @Override public boolean onTouchEvent(MotionEvent event) {
        if(hidden&&!editing) return false;
        int action=event.getActionMasked(),index=event.getActionIndex(),id=event.getPointerId(index);
        if(action==MotionEvent.ACTION_CANCEL) { release(); return true; }
        if(editing) return editTouch(event,action,index,id);
        if(action==MotionEvent.ACTION_DOWN||action==MotionEvent.ACTION_POINTER_DOWN) pointers.put(id,hit(event.getX(index),event.getY(index)));
        else if(action==MotionEvent.ACTION_MOVE) for(int i=0;i<event.getPointerCount();i++) {
            int pointerId=event.getPointerId(i); if(pointers.containsKey(pointerId)) pointers.put(pointerId,hit(event.getX(i),event.getY(i)));
        } else if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_POINTER_UP) pointers.remove(id);
        publish(); if(action==MotionEvent.ACTION_UP) performClick(); return true;
    }
    private boolean editTouch(MotionEvent e,int action,int index,int id) {
        if(action==MotionEvent.ACTION_DOWN||action==MotionEvent.ACTION_POINTER_DOWN) {
            Drag d=new Drag(); d.x=e.getX(index);d.y=e.getY(index);d.group=d.x<getWidth()*.5f?0:1;
            d.ox=d.group==0?padOffsetX:buttonOffsetX; d.oy=d.group==0?padOffsetY:buttonOffsetY; drags.put(id,d);
        } else if(action==MotionEvent.ACTION_MOVE) {
            for(int i=0;i<e.getPointerCount();i++) { Drag d=drags.get(e.getPointerId(i)); if(d==null) continue;
                float x=clamp(d.ox+(e.getX(i)-d.x)/getWidth(),-.4f,.4f), y=clamp(d.oy+(e.getY(i)-d.y)/getHeight(),-.6f,.6f);
                if(d.group==0) { padOffsetX=x;padOffsetY=y; } else { buttonOffsetX=x;buttonOffsetY=y; }
            } layoutControls(); invalidate();
        } else if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_POINTER_UP) {
            drags.remove(id); prefs.edit().putFloat("padX",padOffsetX).putFloat("padY",padOffsetY).putFloat("buttonsX",buttonOffsetX).putFloat("buttonsY",buttonOffsetY).apply();
        }
        return true;
    }
    private void publish() {
        int mask=0; for(int value:pointers.values()) mask|=value;
        if(mask==lastMask) return;
        if((mask&~lastMask)!=0) listener.pressed();
        if(((mask^lastMask)&REWIND)!=0) listener.rewindHeld((mask&REWIND)!=0);
        lastMask=mask; listener.buttonsChanged(mask&4095); invalidate();
    }
}

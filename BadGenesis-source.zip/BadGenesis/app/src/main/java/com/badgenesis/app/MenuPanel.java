package com.badgenesis.app;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Native menus in the activity window: one visible page, real Android system bars. */
final class MenuPanel implements DialogInterface {
    static final int BUTTON_POSITIVE=DialogInterface.BUTTON_POSITIVE;
    static final int BUTTON_NEGATIVE=DialogInterface.BUTTON_NEGATIVE;
    static final int BUTTON_NEUTRAL=DialogInterface.BUTTON_NEUTRAL;
    private final Map<Integer,Button> buttons=new HashMap<>();
    private final List<Button> listRows=new ArrayList<>();
    private final Context context;
    private final FrameLayout overlay;
    private final LinearLayout page,header;
    private final TextView title;
    private final Button back,close;
    private final ViewGroup host;
    private final Builder builder;
    private DialogInterface.OnDismissListener dismissListener;
    private Runnable closeAction;
    private boolean showing,gameBackdrop;
    private int safeLeft,safeTop,safeRight,safeBottom;
    private int lastRowHeight;

    private MenuPanel(Builder builder) {
        this.builder=builder;context=builder.context;
        host=((Activity)context).findViewById(android.R.id.content);
        overlay=new FrameLayout(context);overlay.setClickable(true);overlay.setFocusableInTouchMode(true);
        page=new LinearLayout(context);page.setOrientation(LinearLayout.VERTICAL);
        overlay.addView(page,new FrameLayout.LayoutParams(-1,-1));
        header=new LinearLayout(context);header.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable bar=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,builder.fileBrowser?new int[]{0xFF707070,0xFF242424}:new int[]{0xFF000098,0xFF00002E});
        bar.setStroke(dp(1),builder.fileBrowser?0xFF737373:0xFF292948);header.setBackground(bar);
        back=headerButton(builder.fileBrowser?"⌃":"‹");back.setContentDescription(builder.fileBrowser?"Parent folder":"Back");
        back.setVisibility(builder.showBack?View.VISIBLE:View.INVISIBLE);
        back.setOnClickListener(v->{if(builder.backAction!=null)builder.backAction.run();else dismiss();});
        header.addView(back,new LinearLayout.LayoutParams(dp(42),-1));
        title=new TextView(context);title.setText(builder.title);title.setTextColor(Color.WHITE);title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);title.setGravity(builder.fileBrowser?Gravity.CENTER_VERTICAL|Gravity.START:Gravity.CENTER);
        header.addView(title,new LinearLayout.LayoutParams(0,-1,1));
        close=headerButton(builder.fileBrowser?"×":"▸");close.setContentDescription("Close menu and resume game");
        close.setOnClickListener(v->{if(closeAction!=null)closeAction.run();else dismiss();});
        close.setVisibility(builder.showClose?View.VISIBLE:View.INVISIBLE);
        header.addView(close,new LinearLayout.LayoutParams(dp(42),-1));
        page.addView(header,new LinearLayout.LayoutParams(-1,dp(40)));
        if(builder.items!=null) {
            LinearLayout rows=new LinearLayout(context);rows.setOrientation(LinearLayout.VERTICAL);
            for(int index=0;index<builder.items.length;index++) {
                final int selected=index;
                boolean enabled=builder.enabled==null||builder.enabled[index];
                Button row=row(context,builder.items[index]);row.setEnabled(enabled);
                row.setTextColor(enabled?Color.WHITE:0xFF777777);
                row.setOnClickListener(v->{for(Button item:listRows)item.setSelected(item==row);if(!builder.keepOpen)dismiss();if(builder.itemListener!=null)builder.itemListener.onClick(this,selected);});
                row.setOnFocusChangeListener((v,focused)->{if(focused)for(Button item:listRows)item.setSelected(false);});
                rows.addView(row,new LinearLayout.LayoutParams(-1,dp(48)));addDivider(context,rows);listRows.add(row);
            }
            ScrollView sc=new ScrollView(context);sc.setFillViewport(false);sc.setClipToPadding(false);sc.addView(rows);
            page.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        } else if(builder.view!=null) {
            page.addView(builder.view,new LinearLayout.LayoutParams(-1,0,1));
        } else {
            ScrollView sc=new ScrollView(context);TextView message=new TextView(context);
            message.setText(builder.message);message.setTextSize(18);message.setTextColor(Color.WHITE);
            message.setPadding(dp(8),dp(18),dp(8),dp(18));message.setTextIsSelectable(true);
            sc.addView(message);page.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        }
        LinearLayout actions=new LinearLayout(context);
        for(int which:new int[]{BUTTON_NEUTRAL,BUTTON_NEGATIVE,BUTTON_POSITIVE}) {
            String label=builder.buttonLabels.get(which);if(label==null)continue;
            Button button=row(context,label);buttons.put(which,button);
            button.setOnClickListener(v->{if(!(builder.keepOpen&&which==BUTTON_NEUTRAL))dismiss();DialogInterface.OnClickListener callback=builder.buttonListeners.get(which);if(callback!=null)callback.onClick(this,which);});
            // Navigation belongs in the title bar, rather than consuming another game-sized row.
            boolean navigationOnly=("Back".equals(label)||"Close".equals(label))&&builder.buttonListeners.get(which)==null;
            if(navigationOnly){if("Back".equals(label)){back.setVisibility(View.VISIBLE);back.setOnClickListener(v->button.performClick());}else{close.setVisibility(View.VISIBLE);}}
            else actions.addView(button,new LinearLayout.LayoutParams(0,dp(44),1));
        }
        if(actions.getChildCount()>0){addDivider(context,page);page.addView(actions,new LinearLayout.LayoutParams(-1,dp(44)));}
        overlay.setOnApplyWindowInsetsListener((view,insets)->{
            if(Build.VERSION.SDK_INT>=30){android.graphics.Insets safe=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout()|WindowInsets.Type.ime());safeLeft=safe.left;safeTop=safe.top;safeRight=safe.right;safeBottom=safe.bottom;}
            else {safeLeft=insets.getSystemWindowInsetLeft();safeTop=insets.getSystemWindowInsetTop();safeRight=insets.getSystemWindowInsetRight();safeBottom=insets.getSystemWindowInsetBottom();if(Build.VERSION.SDK_INT>=28&&insets.getDisplayCutout()!=null){android.view.DisplayCutout cut=insets.getDisplayCutout();safeLeft=Math.max(safeLeft,cut.getSafeInsetLeft());safeTop=Math.max(safeTop,cut.getSafeInsetTop());safeRight=Math.max(safeRight,cut.getSafeInsetRight());safeBottom=Math.max(safeBottom,cut.getSafeInsetBottom());}}
            layoutPage();return insets;
        });
        overlay.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or,ob)->{if(r-l!=or-ol||b-t!=ob-ot)layoutPage();});
        setGameBackdrop(false);
    }
    private Button headerButton(String text){Button b=new Button(context);b.setText(text);b.setAllCaps(false);b.setTextColor(0xFFCCCCCC);b.setTextSize(27);b.setPadding(0,0,0,0);b.setMinHeight(0);b.setMinimumHeight(0);b.setMinWidth(0);b.setMinimumWidth(0);b.setBackground(rowBackground());b.setStateListAnimator(null);b.setElevation(0);return b;}
    private void layoutPage(){
        int side=dp(context.getResources().getConfiguration().orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE?20:10);
        page.setPadding(safeLeft+side,safeTop,safeRight+side,safeBottom);
        int available=overlay.getHeight()-safeTop-safeBottom;if(available<=0)return;
        boolean landscape=context.getResources().getConfiguration().orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE;
        int rowPixels=landscape?Math.max(dp(28),Math.min(dp(54),(available-dp(8))/8)):dp(54);
        int headerPixels=landscape?Math.round(rowPixels*.87f):dp(46);
        // The original seven root rows fit between the system bars. Extra RTC pages scroll below them.
        if(landscape&&builder.rootMenu)rowPixels=Math.max(dp(24),(available-headerPixels-7)/7);
        if(lastRowHeight!=rowPixels){lastRowHeight=rowPixels;for(Button row:listRows){LinearLayout.LayoutParams p=(LinearLayout.LayoutParams)row.getLayoutParams();p.height=rowPixels;row.setLayoutParams(p);row.setMinHeight(0);row.setMinimumHeight(0);row.setTextSize(TypedValue.COMPLEX_UNIT_PX,rowPixels*.47f);}}
        LinearLayout.LayoutParams hp=(LinearLayout.LayoutParams)header.getLayoutParams();if(hp.height!=headerPixels){hp.height=headerPixels;header.setLayoutParams(hp);}title.setTextSize(TypedValue.COMPLEX_UNIT_PX,headerPixels*.5f);
    }
    void setGameBackdrop(boolean value){gameBackdrop=value;overlay.setBackgroundColor(value?0xBE000000:Color.BLACK);}
    void setCloseAction(Runnable action){closeAction=action;if(gameBackdrop||builder.showClose)close.setVisibility(View.VISIBLE);}
    void setOnDismissListener(DialogInterface.OnDismissListener listener){dismissListener=listener;}
    void setVisible(boolean value){overlay.setVisibility(value?View.VISIBLE:View.GONE);if(value){overlay.requestApplyInsets();layoutPage();}}
    void show(){if(showing)return;showing=true;host.addView(overlay,new ViewGroup.LayoutParams(-1,-1));overlay.requestApplyInsets();layoutPage();overlay.requestFocus();}
    @Override public void dismiss(){if(!showing)return;showing=false;android.view.inputmethod.InputMethodManager keyboard=(android.view.inputmethod.InputMethodManager)context.getSystemService(Context.INPUT_METHOD_SERVICE);if(keyboard!=null&&overlay.findFocus() instanceof android.widget.EditText)keyboard.hideSoftInputFromWindow(overlay.getWindowToken(),0);host.removeView(overlay);if(dismissListener!=null)dismissListener.onDismiss(this);}
    @Override public void cancel(){dismiss();}
    Button getButton(int which){return buttons.get(which);}
    void setItemText(int index,String value){if(index>=0&&index<listRows.size()){builder.items[index]=value;listRows.get(index).setText(value);}}
    void setItemEnabled(int index,boolean value){if(index>=0&&index<listRows.size()){Button row=listRows.get(index);row.setEnabled(value);row.setTextColor(value?Color.WHITE:0xFF777777);}}
    boolean isRootMenu(){return builder.rootMenu;}
    private int dp(float value){return (int)(context.getResources().getDisplayMetrics().density*value+.5f);}
    private static StateListDrawable rowBackground(){StateListDrawable states=new StateListDrawable();states.addState(new int[]{android.R.attr.state_pressed},new android.graphics.drawable.ColorDrawable(0xFF174C5C));states.addState(new int[]{android.R.attr.state_focused},new android.graphics.drawable.ColorDrawable(0xFF174C5C));states.addState(new int[]{android.R.attr.state_selected},new android.graphics.drawable.ColorDrawable(0xFF174C5C));states.addState(new int[]{},new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));return states;}
    static Button row(Context context,String title) {
        float unit=context.getResources().getDisplayMetrics().density;
        Button button=new Button(context);button.setText(title);button.setAllCaps(false);button.setLetterSpacing(0);button.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));
        button.setTextSize(22);button.setTextColor(Color.WHITE);button.setGravity(Gravity.CENTER_VERTICAL|Gravity.START);button.setSingleLine(true);button.setEllipsize(android.text.TextUtils.TruncateAt.END);
        button.setPadding((int)(5*unit),0,(int)(8*unit),0);button.setMinHeight((int)(48*unit));button.setMinimumHeight((int)(48*unit));
        button.setMinWidth(0);button.setMinimumWidth(0);button.setBackground(rowBackground());button.setStateListAnimator(null);button.setElevation(0);
        return button;
    }
    static void addDivider(Context context,LinearLayout parent){View line=new View(context);line.setBackgroundColor(0xFF333333);parent.addView(line,new LinearLayout.LayoutParams(-1,Math.max(1,(int)(context.getResources().getDisplayMetrics().density*.5f))));}
    static final class Builder {
        final Context context;
        String title="BadGenesis",message="";
        String[] items;boolean[] enabled;boolean keepOpen,rootMenu,fileBrowser,showBack=true,showClose;
        View view;Runnable backAction;
        DialogInterface.OnClickListener itemListener;
        final Map<Integer,String> buttonLabels=new HashMap<>();
        final Map<Integer,DialogInterface.OnClickListener> buttonListeners=new HashMap<>();
        Builder(Context context){this.context=context;}
        Builder setTitle(String value){title=value;return this;}
        Builder setMessage(String value){message=value;return this;}
        Builder setView(View value){view=value;return this;}
        Builder setItems(String[] value,DialogInterface.OnClickListener listener){items=value;itemListener=listener;return this;}
        Builder setEnabledItems(boolean[] value){enabled=value;return this;}
        Builder setKeepOpen(boolean value){keepOpen=value;return this;}
        Builder setRootMenu(boolean value){rootMenu=value;showBack=!value;return this;}
        Builder setFileBrowser(Runnable up){fileBrowser=true;showClose=true;backAction=up;return this;}
        Builder setPositiveButton(String value,DialogInterface.OnClickListener listener){return setButton(BUTTON_POSITIVE,value,listener);}
        Builder setNegativeButton(String value,DialogInterface.OnClickListener listener){return setButton(BUTTON_NEGATIVE,value,listener);}
        Builder setNeutralButton(String value,DialogInterface.OnClickListener listener){return setButton(BUTTON_NEUTRAL,value,listener);}
        private Builder setButton(int which,String value,DialogInterface.OnClickListener listener){buttonLabels.put(which,value);buttonListeners.put(which,listener);return this;}
        MenuPanel create(){return new MenuPanel(this);}
    }
}

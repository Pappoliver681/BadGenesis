package com.badgenesis.app;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.HashMap;
import java.util.Map;

/** Plain full-screen native menus shared by every BadGenesis screen. */
final class MenuPanel extends Dialog {
    static final int BUTTON_POSITIVE=DialogInterface.BUTTON_POSITIVE;
    static final int BUTTON_NEGATIVE=DialogInterface.BUTTON_NEGATIVE;
    static final int BUTTON_NEUTRAL=DialogInterface.BUTTON_NEUTRAL;
    private final Map<Integer,Button> buttons=new HashMap<>();
    private final Context context;

    private MenuPanel(Builder builder) {
        super(builder.context,android.R.style.Theme_Material_NoActionBar);
        context=builder.context;
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout page=new LinearLayout(context);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(Color.BLACK);
        page.setPadding(dp(18),dp(12),dp(18),dp(10));
        TextView title=new TextView(context);
        title.setText(builder.title);title.setTextColor(Color.WHITE);
        title.setTextSize(rowHeight(context)*.5f);title.setGravity(Gravity.CENTER);
        GradientDrawable bar=new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0xFF0000A4,0xFF000025});
        bar.setStroke(dp(1),0xFF292948);title.setBackground(bar);
        page.addView(title,new LinearLayout.LayoutParams(-1,dp(rowHeight(context))));
        if(builder.items!=null) {
            LinearLayout rows=new LinearLayout(context);rows.setOrientation(LinearLayout.VERTICAL);
            for(int index=0;index<builder.items.length;index++) {
                final int selected=index;
                boolean enabled=builder.enabled==null||builder.enabled[index];
                Button row=row(context,builder.items[index]);row.setEnabled(enabled);
                row.setTextColor(enabled?Color.WHITE:0xFF777777);
                row.setOnClickListener(v->{if(!builder.keepOpen)dismiss();if(builder.itemListener!=null)builder.itemListener.onClick(this,selected);});
                rows.addView(row,new LinearLayout.LayoutParams(-1,-2));addDivider(context,rows);
            }
            ScrollView sc=new ScrollView(context);sc.setFillViewport(false);sc.addView(rows);
            page.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        } else if(builder.view!=null) {
            page.addView(builder.view,new LinearLayout.LayoutParams(-1,0,1));
        } else {
            ScrollView sc=new ScrollView(context);TextView message=new TextView(context);
            message.setText(builder.message);message.setTextSize(18);message.setTextColor(Color.WHITE);
            message.setPadding(dp(8),dp(18),dp(8),dp(18));message.setTextIsSelectable(true);
            sc.addView(message);page.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        }
        for(int which:new int[]{BUTTON_NEUTRAL,BUTTON_NEGATIVE,BUTTON_POSITIVE}) {
            String label=builder.buttonLabels.get(which);if(label==null)continue;
            addDivider(context,page);Button button=row(context,label);buttons.put(which,button);
            button.setOnClickListener(v->{dismiss();DialogInterface.OnClickListener callback=builder.buttonListeners.get(which);if(callback!=null)callback.onClick(this,which);});
            page.addView(button,new LinearLayout.LayoutParams(-1,-2));
        }
        setContentView(page);
        Window window=getWindow();if(window!=null){
            window.setBackgroundDrawableResource(android.R.color.black);
            window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
            window.setDimAmount(0);
            if(android.os.Build.VERSION.SDK_INT>=28){WindowManager.LayoutParams p=window.getAttributes();p.layoutInDisplayCutoutMode=WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;window.setAttributes(p);}
        }
        setCanceledOnTouchOutside(false);
    }
    @Override public void show(){super.show();Window w=getWindow();if(w!=null){w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT);w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE);}}
    Button getButton(int which){return buttons.get(which);}
    private int dp(float value){return (int)(context.getResources().getDisplayMetrics().density*value+.5f);}
    static Button row(Context context,String title) {
        float unit=context.getResources().getDisplayMetrics().density;
        Button button=new Button(context);button.setText(title);button.setAllCaps(false);
        float height=rowHeight(context);
        button.setTextSize(height*.49f);button.setTextColor(Color.WHITE);button.setGravity(Gravity.CENTER_VERTICAL|Gravity.START);
        button.setPadding((int)(8*unit),(int)(5*unit),(int)(8*unit),(int)(5*unit));button.setMinHeight((int)(height*unit));button.setMinimumHeight((int)(height*unit));
        button.setMinWidth(0);button.setMinimumWidth(0);button.setBackgroundColor(Color.BLACK);
        button.setStateListAnimator(null);button.setElevation(0);
        return button;
    }
    private static float rowHeight(Context context){int height=context.getResources().getConfiguration().screenHeightDp,width=context.getResources().getConfiguration().screenWidthDp;return height<width?Math.max(30,Math.min(52,(height-24)/8f)):52;}
    static void addDivider(Context context,LinearLayout parent){View line=new View(context);line.setBackgroundColor(0xFF373737);parent.addView(line,new LinearLayout.LayoutParams(-1,Math.max(1,(int)context.getResources().getDisplayMetrics().density)));}
    static final class Builder {
        final Context context;
        String title="BadGenesis",message="";
        String[] items;boolean[] enabled;boolean keepOpen;
        View view;
        DialogInterface.OnClickListener itemListener;
        final Map<Integer,String> buttonLabels=new HashMap<>();
        final Map<Integer,DialogInterface.OnClickListener> buttonListeners=new HashMap<>();
        Builder(Context context){this.context=context;}
        Builder setTitle(String value){title=value;return this;}
        Builder setMessage(String value){message=value;return this;}
        Builder setView(View value){view=value;return this;}
        Builder setItems(String[] value,DialogInterface.OnClickListener listener){items=value;itemListener=listener;return this;}
        Builder setEnabledItems(boolean[] value){enabled=value;return this;}
        Builder setKeepOpen(boolean value){keepOpen=value;return this;}
        Builder setPositiveButton(String value,DialogInterface.OnClickListener listener){return setButton(BUTTON_POSITIVE,value,listener);}
        Builder setNegativeButton(String value,DialogInterface.OnClickListener listener){return setButton(BUTTON_NEGATIVE,value,listener);}
        Builder setNeutralButton(String value,DialogInterface.OnClickListener listener){return setButton(BUTTON_NEUTRAL,value,listener);}
        private Builder setButton(int which,String value,DialogInterface.OnClickListener listener){buttonLabels.put(which,value);buttonListeners.put(which,listener);return this;}
        MenuPanel create(){return new MenuPanel(this);}
    }
}

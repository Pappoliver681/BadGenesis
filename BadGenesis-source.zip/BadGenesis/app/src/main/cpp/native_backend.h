#pragma once
#include "rtc_engine.h"
#include <atomic>
#include <condition_variable>
#include <chrono>
#include <cstdint>
#include <deque>
#include <functional>
#include <future>
#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <stdexcept>
#include <thread>
#include <vector>

#ifdef __ANDROID__
#include <aaudio/AAudio.h>
#include <android/native_window.h>
#else
struct ANativeWindow;
struct AAudioStream;
#endif

namespace badgenesis {
class NativeBackend {
public:
    explicit NativeBackend(std::string filesDirectory);
    ~NativeBackend();
    NativeBackend(const NativeBackend&) = delete;
    NativeBackend& operator=(const NativeBackend&) = delete;
    std::string loadRom(std::vector<uint8_t> bytes, std::string name);
    void attachSurface(ANativeWindow* window);
    void setButtons(uint16_t buttons) { heldButtons_.store(buttons, std::memory_order_relaxed); }
    std::string command(std::string action, std::string json);
    std::string status();
    std::string domains();
    std::vector<uint8_t> exportState();
    std::string importState(std::vector<uint8_t> state);
    std::vector<uint8_t> exportData(std::string kind);
    std::string importData(std::string kind, std::vector<uint8_t> data);
    std::vector<uint8_t> readMemory(std::string domain, uint32_t start, uint32_t length);

    // libretro callbacks are exclusively used by the single native core worker.
    bool environment(unsigned command, void* data);
    void video(const void* pixels, unsigned width, unsigned height, size_t pitch);
    size_t audio(const int16_t* samples, size_t frames);
    int16_t input(unsigned port, unsigned device, unsigned index, unsigned id);
    int audioCallback(void* samples, int32_t frames);
    void audioError(int error);

private:
    struct Snapshot { uint64_t frame = 0; std::vector<uint8_t> bytes; };
    template<class Function> auto onWorker(Function function) -> decltype(function()) {
        using Result = decltype(function());
        if (std::this_thread::get_id() == worker_.get_id()) return function();
        auto task = std::make_shared<std::packaged_task<Result()>>(std::move(function));
        auto result = task->get_future();
        { std::lock_guard<std::mutex> guard(commandMutex_);
          if (stopping_.load()) throw std::runtime_error("The emulator has stopped");
          commands_.emplace_back([task] { (*task)(); }); }
        commandReady_.notify_one();
        if (result.wait_for(std::chrono::seconds(10)) != std::future_status::ready)
            throw std::runtime_error("The native core did not respond. Reopen BadGenesis and restore recovery.");
        return result.get();
    }
    void workerLoop(std::promise<void> ready);
    void presentationLoop();
    void configureDomains();
    void writeDomainByte(const std::string& domain, uint32_t address, uint8_t value);
    std::string commandOnWorker(const std::string& action, const std::string& json);
    std::string statusOnWorker() const;
    std::vector<uint8_t> snapshot();
    std::string restore(const std::vector<uint8_t>& data, bool rewind);
    void captureRewind();
    void clearRewind();
    void persistSram();
    void loadSram();
    void openAudio();
    void closeAudio();
    void flushAudio();
    std::string statePath(unsigned slot) const;
    std::string recoveryPath() const;

    std::string filesDirectory_, romName_, romKey_, error_, message_;
    std::thread worker_, presentation_;
    std::atomic<bool> stopping_{false}, audioMuted_{true}, audioReopen_{false};
    std::mutex commandMutex_;
    std::condition_variable commandReady_;
    std::deque<std::function<void()>> commands_;
    std::atomic<uint16_t> heldButtons_{0};
    bool loaded_ = false, paused_ = false, uiPaused_ = false, rewinding_ = false, audioEnabled_ = true, sixButton_ = true;
    bool clockReset_ = true, harvester_ = false, harvestRunning_ = false;
    uint64_t frame_ = 0, harvestEndFrame_ = 0, renderedFrames_ = 0, lastRecoveryDiskFrame_ = 0;
    uint32_t harvestRunFrames_ = 60, rewindSeconds_ = 30, snapshotInterval_ = 10;
    double fps_ = 59.9227, sampleRate_ = 44100, measuredFps_ = 0, frameMilliseconds_ = 0;
    unsigned pixelFormat_ = 2;
    std::vector<uint8_t> originalRom_, normalizedOriginal_, quickState_, harvesterClean_, lastKeptState_, recoveryState_;
    std::map<uint32_t, uint8_t> romPatches_;
    RtcEngine rtc_;
    std::deque<Snapshot> rewind_;
    size_t rewindBytes_ = 0;
    const size_t rewindByteLimit_ = 96 * 1024 * 1024;

    std::mutex videoMutex_;
    std::condition_variable videoReady_;
    ANativeWindow* window_ = nullptr;
    std::vector<uint32_t> latestPixels_;
    std::vector<uint32_t> videoScratch_;
    unsigned videoWidth_ = 0, videoHeight_ = 0;
    uint64_t videoGeneration_ = 0;
    std::atomic<uint64_t> presentationCount_{0};
    std::atomic<int> renderError_{0};

    static constexpr uint32_t audioCapacity_ = 32768;
    std::vector<int16_t> audioRing_ = std::vector<int16_t>(audioCapacity_ * 2);
    std::atomic<uint64_t> audioWrite_{0}, audioRead_{0}, audioUnderruns_{0}, audioOverruns_{0};
    std::atomic<bool> audioFlush_{false};
    std::atomic<bool> audioPrimed_{false};
    AAudioStream* audioStream_ = nullptr;
    int32_t outputSampleRate_ = 44100;
    double resamplePosition_ = 0;
    int16_t resamplePrevious_[2] = {0, 0};
};
}

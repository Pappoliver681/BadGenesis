/* Native state supplement for the pinned Genesis Plus GX core.
 * The public blip API intentionally hides its state layout. The layout below
 * completes that declaration exactly as core/sound/blip_buf.c at upstream
 * c2838c7dc4236fc2fe94e5dbd08b41486067918e. All supported Android ABIs use the
 * 64-bit fixed_t branch. No chip implementation or timing is replaced here. */
#include "vendor_adapter.h"
#include "libretro.h"
#include "shared.h"

#ifdef BLIP_MONO
#error BadGenesis requires the Genesis Plus GX stereo sound core
#endif

struct blip_buffer_state_t {
    uint64_t offset;
    int integrator[2];
    int buffer[2][16];
};

_Static_assert(sizeof(int) == 4, "Genesis Plus GX requires 32-bit int");
_Static_assert(sizeof(struct blip_buffer_state_t) == 144,
               "Pinned Genesis Plus GX blip state layout changed");

typedef struct {
    uint32_t magic;
    uint32_t version;
    uint32_t present;
    int fm_last[2];
    int16_t cd_last[2];
    struct blip_buffer_state_t blips[4];
} BgSoundState;

size_t bg_sound_size(void) { return sizeof(BgSoundState); }

int bg_sound_save(uint8_t *output, size_t size) {
    BgSoundState saved;
    int i;
    if (!output || size != sizeof(saved)) return 0;
    memset(&saved, 0, sizeof(saved));
    saved.magic = 0x4247534eU;
    saved.version = 1;
    /* This also captures the FM and CD last-amplitude values used when
     * adding the next delta. Upstream's single scratch snapshot is copied
     * immediately into this independent rewind/save-state record. */
    save_sound_buffer();
    memcpy(saved.fm_last, snd.fm_last_save, sizeof(saved.fm_last));
    memcpy(saved.cd_last, snd.cd_last_save, sizeof(saved.cd_last));
    for (i = 0; i < 4; ++i) {
        if (!snd.blips[i]) continue;
        if (!snd.blip_states[i]) {
            snd.blip_states[i] = blip_new_buffer_state();
            if (!snd.blip_states[i]) return 0;
        }
        blip_save_buffer_state(snd.blips[i], snd.blip_states[i]);
        memcpy(&saved.blips[i], snd.blip_states[i], sizeof(saved.blips[i]));
        saved.present |= 1U << i;
    }
    memcpy(output, &saved, sizeof(saved));
    return 1;
}

int bg_sound_load(const uint8_t *input, size_t size) {
    BgSoundState saved;
    uint32_t present = 0;
    int i;
    if (!input || size != sizeof(saved)) return 0;
    memcpy(&saved, input, sizeof(saved));
    for (i = 0; i < 4; ++i)
        if (snd.blips[i]) present |= 1U << i;
    if (saved.magic != 0x4247534eU || saved.version != 1 ||
        saved.present != present) return 0;
    /* Snapshot offsets at frame boundaries contain a fractional phase and
     * at most a few unread samples. Reject a damaged state before offsets
     * could direct future delta writes outside the core's allocated buffer. */
    for (i = 0; i < 4; ++i) {
        if (!(present & (1U << i))) continue;
        if (saved.blips[i].offset >= (UINT64_C(32) << 52)) return 0;
        if (!snd.blip_states[i]) {
            snd.blip_states[i] = blip_new_buffer_state();
            if (!snd.blip_states[i]) return 0;
        }
    }
    memcpy(snd.fm_last_save, saved.fm_last, sizeof(saved.fm_last));
    memcpy(snd.cd_last_save, saved.cd_last, sizeof(saved.cd_last));
    for (i = 0; i < 4; ++i)
        if (present & (1U << i))
            memcpy(snd.blip_states[i], &saved.blips[i], sizeof(saved.blips[i]));
    restore_sound_buffer();
    /* Upstream's helper predates the optional fourth cartridge sound stream. */
    if (present & 8U)
        blip_load_buffer_state(snd.blips[3], snd.blip_states[3]);
    return 1;
}

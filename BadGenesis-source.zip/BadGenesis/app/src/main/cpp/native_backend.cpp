#include "native_backend.h"
#include "mini_json.h"
#include "vendor_adapter.h"
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstdarg>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <stdexcept>
#include <sys/stat.h>
#include <zlib.h>
#ifdef __ANDROID__
#include <aaudio/AAudio.h>
#include <android/log.h>
#include <android/native_window.h>
#include <EGL/egl.h>
#include <GLES2/gl2.h>
#include <sys/resource.h>
#endif

extern "C" {
#include "libretro.h"
#include "shared.h"
}

namespace badgenesis {
namespace {
NativeBackend* callbackBackend = nullptr;
std::mutex singletonMutex;
void logCore(enum retro_log_level, const char* format, ...) {
#ifdef __ANDROID__
    va_list arguments; va_start(arguments, format);
    __android_log_vprint(ANDROID_LOG_INFO, "BadGenesisCore", format, arguments);
    va_end(arguments);
#else
    (void)format;
#endif
}
bool environmentCallback(unsigned command, void* data) { return callbackBackend && callbackBackend->environment(command, data); }
void videoCallback(const void* pixels, unsigned width, unsigned height, size_t pitch) { if (callbackBackend) callbackBackend->video(pixels, width, height, pitch); }
size_t audioBatchCallback(const int16_t* data, size_t frames) { return callbackBackend ? callbackBackend->audio(data, frames) : frames; }
void audioSampleCallback(int16_t left, int16_t right) { const int16_t samples[] = {left, right}; audioBatchCallback(samples, 1); }
void inputPollCallback() {}
int16_t inputCallback(unsigned port, unsigned device, unsigned index, unsigned id) { return callbackBackend ? callbackBackend->input(port, device, index, id) : 0; }
#ifdef __ANDROID__
aaudio_data_callback_result_t dataCallback(AAudioStream*, void* user, void* data, int32_t frames) { static_cast<NativeBackend*>(user)->audioCallback(data, frames); return AAUDIO_CALLBACK_RESULT_CONTINUE; }
void errorCallback(AAudioStream*, void* user, aaudio_result_t error) { static_cast<NativeBackend*>(user)->audioError(error); }
#endif

std::vector<uint8_t> readFile(const std::string& path, size_t limit = 64 * 1024 * 1024) {
    std::ifstream input(path, std::ios::binary | std::ios::ate); if (!input) return {};
    auto length = input.tellg(); if (length <= 0 || static_cast<uint64_t>(length) > limit) return {};
    std::vector<uint8_t> bytes(static_cast<size_t>(length)); input.seekg(0);
    if (!input.read(reinterpret_cast<char*>(bytes.data()), bytes.size())) return {};
    return bytes;
}
void writeFile(const std::string& path, const std::vector<uint8_t>& data) {
    const std::string temporary = path + ".tmp";
    std::ofstream output(temporary, std::ios::binary | std::ios::trunc);
    if (!output || !output.write(reinterpret_cast<const char*>(data.data()), data.size())) throw std::runtime_error("Cannot write private app storage");
    output.close(); if (std::rename(temporary.c_str(), path.c_str())) throw std::runtime_error("Cannot finish saving the file");
}
std::string identity(const std::vector<uint8_t>& bytes) {
    uint64_t hash = 1469598103934665603ull;
    for (auto value : bytes) { hash ^= value; hash *= 1099511628211ull; }
    std::ostringstream out; out << std::hex << std::setfill('0') << std::setw(16) << hash << '-' << bytes.size(); return out.str();
}
void append32(std::vector<uint8_t>& output, uint32_t value) { for (int shift = 24; shift >= 0; shift -= 8) output.push_back(value >> shift); }
void append64(std::vector<uint8_t>& output, uint64_t value) { append32(output, value >> 32); append32(output, value); }
void appendBytes(std::vector<uint8_t>& output, const void* data, size_t size) { if (!size) return; const auto* source = static_cast<const uint8_t*>(data); output.insert(output.end(), source, source + size); }
void appendString(std::vector<uint8_t>& output, const std::string& string) { append32(output, string.size()); appendBytes(output, string.data(), string.size()); }
struct StateReader {
    const std::vector<uint8_t>& data; size_t position = 0;
    void need(size_t count) const { if (count > data.size() - position) throw std::runtime_error("Truncated native state"); }
    uint32_t u32() { need(4); uint32_t value = 0; for (int i = 0; i < 4; ++i) value = (value << 8) | data[position++]; return value; }
    uint64_t u64() { auto high = u32(); auto low = u32(); return (uint64_t(high) << 32) | low; }
    uint8_t byte() { need(1); return data[position++]; }
    std::string string() { auto length = u32(); need(length); std::string value(reinterpret_cast<const char*>(data.data() + position), length); position += length; return value; }
    std::vector<uint8_t> bytes(size_t length) { need(length); std::vector<uint8_t> result(data.begin() + position, data.begin() + position + length); position += length; return result; }
};
std::string successful(const std::string& message = {}) { return "{\"ok\":true,\"message\":" + Json::quote(message) + "}"; }
std::string failed(const std::string& message) { return "{\"ok\":false,\"error\":" + Json::quote(message) + "}"; }
}

NativeBackend::NativeBackend(std::string directory) : filesDirectory_(std::move(directory)) {
    std::lock_guard<std::mutex> singletonGuard(singletonMutex);
    if (callbackBackend) throw std::runtime_error("Only one Genesis core may run at a time");
    mkdir(filesDirectory_.c_str(), 0700);
    callbackBackend = this;
    std::promise<void> ready; auto initialized = ready.get_future();
    try {
        worker_ = std::thread(&NativeBackend::workerLoop, this, std::move(ready));
        initialized.get();
        presentation_ = std::thread(&NativeBackend::presentationLoop, this);
    } catch (...) {
        stopping_.store(true); commandReady_.notify_all(); videoReady_.notify_all();
        if (worker_.joinable()) worker_.join();
        if (presentation_.joinable()) presentation_.join();
        callbackBackend = nullptr; throw;
    }
}

NativeBackend::~NativeBackend() {
    stopping_.store(true); audioMuted_.store(true);
    commandReady_.notify_all(); videoReady_.notify_all();
    if (worker_.joinable()) worker_.join();
    if (presentation_.joinable()) presentation_.join();
#ifdef __ANDROID__
    if (window_) ANativeWindow_release(window_);
#endif
    std::lock_guard<std::mutex> singletonGuard(singletonMutex);
    if (callbackBackend == this) callbackBackend = nullptr;
}

void NativeBackend::workerLoop(std::promise<void> ready) {
    using Clock = std::chrono::steady_clock;
#ifdef __ANDROID__
    setpriority(PRIO_PROCESS, 0, -4);
#endif
    try {
        retro_set_environment(environmentCallback);
        retro_set_video_refresh(videoCallback);
        retro_set_audio_sample(audioSampleCallback);
        retro_set_audio_sample_batch(audioBatchCallback);
        retro_set_input_poll(inputPollCallback);
        retro_set_input_state(inputCallback);
        retro_init();
        ready.set_value();
    } catch (...) { ready.set_exception(std::current_exception()); return; }
    auto deadline = Clock::now(), measuredSince = Clock::now(); uint64_t measuredFrames = 0;
    while (!stopping_.load()) {
        std::deque<std::function<void()>> jobs;
        { std::unique_lock<std::mutex> guard(commandMutex_);
          if ((!loaded_ || (paused_ && !rewinding_)) && commands_.empty()) commandReady_.wait_for(guard, std::chrono::milliseconds(100));
          jobs.swap(commands_); }
        for (auto& job : jobs) job();
        if (stopping_.load()) break;
        if (!loaded_ || (paused_ && !rewinding_)) { clockReset_ = true; audioMuted_.store(true); continue; }
        if (audioReopen_.exchange(false)) { closeAudio(); openAudio(); }
        auto now = Clock::now();
        if (clockReset_) { deadline = now; clockReset_ = false; }
        const double rate = !rewinding_ && fastForwardHeld_ ? fastForwardMultiplier_ : 1.0;
        const auto period = std::chrono::duration_cast<Clock::duration>(std::chrono::duration<double>(1.0 / (fps_ * rate)));
        if (now < deadline) {
            std::unique_lock<std::mutex> guard(commandMutex_);
            commandReady_.wait_until(guard, deadline, [this] { return stopping_.load() || !commands_.empty(); });
            if (!commands_.empty() || stopping_.load()) continue;
        }
        // Never run an uncapped catch-up burst after a pause, menu, stalled
        // renderer or loaded state. Display refresh cannot advance this clock.
        now = Clock::now(); if (now > deadline + period) deadline = now;
        auto started = Clock::now();
        if (rewinding_) {
            rewindTick();
        } else {
            audioMuted_.store(!audioEnabled_ || paused_);
        retro_run(); ++frame_; ++measuredFrames;
            if (rtc_.autoDue(frame_)) {
                recoveryState_ = snapshot(); captureRewind();
                // Every Auto Blast has immediate RAM recovery. Disk snapshots
                // are limited to one per emulated second to avoid I/O jitter.
                if (frame_ - lastRecoveryDiskFrame_ >= static_cast<uint64_t>(std::ceil(fps_))) {
                    writeFile(recoveryPath(), recoveryState_); lastRecoveryDiskFrame_ = frame_;
                }
            }
            auto blast = rtc_.onEmulatedFrame(frame_);
            if (blast.applied) message_ = blast.message;
            if (snapshotInterval_ && frame_ % snapshotInterval_ == 0) captureRewind();
            if (harvestRunning_ && frame_ >= harvestEndFrame_) { harvestRunning_ = false; paused_ = true; audioMuted_.store(true); message_ = "Harvester result is ready. Keep or discard it."; }
            if (frame_ % static_cast<uint64_t>(std::max(1.0, std::round(fps_ * 10))) == 0) persistSram();
        }
        frameMilliseconds_ = std::chrono::duration<double, std::milli>(Clock::now() - started).count();
        now = Clock::now(); double measuredSeconds = std::chrono::duration<double>(now - measuredSince).count();
        if (measuredSeconds >= 1) { measuredFps_ = measuredFrames / measuredSeconds; measuredFrames = 0; measuredSince = now; }
        deadline += period;
    }
    closeAudio();
    if (loaded_) { persistSram(); retro_unload_game(); }
    retro_deinit();
}

std::string NativeBackend::loadRom(std::vector<uint8_t> bytes, std::string name) {
    return onWorker([this, bytes = std::move(bytes), name = std::move(name)]() mutable -> std::string {
        if (bytes.size() < 512 || bytes.size() > MAXROMSIZE) return "The ROM must be between 512 bytes and 32 MiB";
        audioMuted_.store(true); closeAudio();
        if (loaded_) { persistSram(); retro_unload_game(); loaded_ = false; }
        originalRom_ = std::move(bytes); romName_ = std::move(name); romKey_ = identity(originalRom_);
        std::string extension = ".bin";
        auto dot = romName_.find_last_of('.');
        if (dot != std::string::npos) { auto candidate = romName_.substr(dot); if (candidate.size() <= 6 && candidate.find_first_not_of(".abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789") == std::string::npos) extension = candidate; }
        std::string workingPath = filesDirectory_ + "/rom-" + romKey_ + extension;
        writeFile(workingPath, originalRom_);
        retro_game_info info{}; info.path = workingPath.c_str(); info.data = originalRom_.data(); info.size = originalRom_.size();
        if (!retro_load_game(&info)) { error_ = "Genesis Plus GX could not load this ROM"; originalRom_.clear(); return error_; }
        if ((system_hw & SYSTEM_PBC) != SYSTEM_MD) { retro_unload_game(); originalRom_.clear(); error_ = "Load a Genesis / Mega Drive cartridge ROM"; return error_; }
        loaded_ = true; frame_ = 0; paused_ = uiPaused_; rewinding_ = fastForwardHeld_ = false; clockReset_ = true; lastRecoveryDiskFrame_ = 0;
        harvester_ = harvestRunning_ = false; quickState_.clear(); harvesterClean_.clear(); lastKeptState_.clear(); recoveryState_.clear(); clearRewind(); romPatches_.clear();
        { std::lock_guard<std::mutex> guard(videoMutex_); latestPixels_.clear(); videoScratch_.clear(); videoWidth_ = videoHeight_ = 0; ++videoGeneration_; }
        videoReady_.notify_one();
        normalizedOriginal_.assign(cart.rom, cart.rom + ((cart.romsize + 1) & ~1u));
        rtc_.beginSession(); configureDomains(); rtc_.setAutoBlast(false, rtc_.autoBlastInterval());
        retro_set_controller_port_device(0, RETRO_DEVICE_SUBCLASS(RETRO_DEVICE_JOYPAD, sixButton_ ? 1 : 0));
        retro_system_av_info timing{}; retro_get_system_av_info(&timing);
        fps_ = timing.timing.fps; sampleRate_ = timing.timing.sample_rate;
        if (fps_ < 40 || fps_ > 70 || sampleRate_ < 8000 || sampleRate_ > 192000) { error_ = "The core reported invalid hardware timing"; loaded_ = false; retro_unload_game(); return error_; }
        error_.clear(); loadSram(); openAudio(); flushAudio(); audioMuted_.store(!audioEnabled_ || paused_);
        message_ = "ROM loaded with RTC off"; captureRewind();
        return {};
    });
}

void NativeBackend::attachSurface(ANativeWindow* window) {
    std::lock_guard<std::mutex> guard(videoMutex_);
#ifdef __ANDROID__
    if (window_) ANativeWindow_release(window_);
#endif
    window_ = window; ++videoGeneration_; videoReady_.notify_one();
}

bool NativeBackend::environment(unsigned command, void* data) {
    switch (command) {
        case RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY:
        case RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY: *static_cast<const char**>(data) = filesDirectory_.c_str(); return true;
        case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT: {
            auto format = *static_cast<retro_pixel_format*>(data);
            if (format != RETRO_PIXEL_FORMAT_RGB565 && format != RETRO_PIXEL_FORMAT_XRGB8888 && format != RETRO_PIXEL_FORMAT_0RGB1555) return false;
            pixelFormat_ = format; return true;
        }
        case RETRO_ENVIRONMENT_GET_VARIABLE: {
            auto* variable = static_cast<retro_variable*>(data); variable->value = nullptr;
            static const std::map<std::string, const char*> values = {
                {"genesis_plus_gx_region_detect", "auto"}, {"genesis_plus_gx_audio_filter", "disabled"},
                {"genesis_plus_gx_blargg_ntsc_filter", "disabled"}, {"genesis_plus_gx_lcd_filter", "disabled"},
                {"genesis_plus_gx_frameskip", "disabled"}, {"genesis_plus_gx_overscan", "disabled"},
                {"genesis_plus_gx_overclock", "100"}, {"genesis_plus_gx_ym2612", "mame (ym2612)"},
                {"genesis_plus_gx_render", "single field"}, {"genesis_plus_gx_enhanced_vscroll", "disabled"}
            };
            auto found = values.find(variable->key ? variable->key : "");
            if (found == values.end()) return false; variable->value = found->second; return true;
        }
        case RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE: *static_cast<bool*>(data) = false; return true;
        case RETRO_ENVIRONMENT_GET_INPUT_BITMASKS: return true;
        case RETRO_ENVIRONMENT_GET_AUDIO_VIDEO_ENABLE: *static_cast<int*>(data) = 3; return true;
        case RETRO_ENVIRONMENT_GET_LOG_INTERFACE: static_cast<retro_log_callback*>(data)->log = logCore; return true;
        case RETRO_ENVIRONMENT_SET_MESSAGE: message_ = static_cast<retro_message*>(data)->msg; return true;
        case RETRO_ENVIRONMENT_SET_SYSTEM_AV_INFO: {
            auto* info = static_cast<retro_system_av_info*>(data);
            if (info->timing.fps >= 40 && info->timing.fps <= 70) { fps_ = info->timing.fps; clockReset_ = true; }
            return true;
        }
        case RETRO_ENVIRONMENT_SET_GEOMETRY:
        case RETRO_ENVIRONMENT_SET_CONTROLLER_INFO:
        case RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS:
        case RETRO_ENVIRONMENT_SET_VARIABLES:
        case RETRO_ENVIRONMENT_SET_PERFORMANCE_LEVEL:
        case RETRO_ENVIRONMENT_SET_SERIALIZATION_QUIRKS:
        case RETRO_ENVIRONMENT_SET_MEMORY_MAPS:
        case RETRO_ENVIRONMENT_SET_CONTENT_INFO_OVERRIDE:
        case RETRO_ENVIRONMENT_SET_DISK_CONTROL_INTERFACE:
        case RETRO_ENVIRONMENT_SET_MINIMUM_AUDIO_LATENCY: return true;
        default: return false;
    }
}

int16_t NativeBackend::input(unsigned port, unsigned device, unsigned, unsigned id) {
    if (port != 0 || (device & RETRO_DEVICE_MASK) != RETRO_DEVICE_JOYPAD) return 0;
    auto buttons = heldButtons_.load(std::memory_order_relaxed); uint16_t mask = 0;
    static const unsigned mapping[12] = {RETRO_DEVICE_ID_JOYPAD_UP, RETRO_DEVICE_ID_JOYPAD_DOWN, RETRO_DEVICE_ID_JOYPAD_LEFT, RETRO_DEVICE_ID_JOYPAD_RIGHT,
        RETRO_DEVICE_ID_JOYPAD_Y, RETRO_DEVICE_ID_JOYPAD_B, RETRO_DEVICE_ID_JOYPAD_A, RETRO_DEVICE_ID_JOYPAD_L,
        RETRO_DEVICE_ID_JOYPAD_X, RETRO_DEVICE_ID_JOYPAD_R, RETRO_DEVICE_ID_JOYPAD_START, RETRO_DEVICE_ID_JOYPAD_SELECT};
    for (unsigned bit = 0; bit < 12; ++bit) if (buttons & (1u << bit)) mask |= 1u << mapping[bit];
    return id == RETRO_DEVICE_ID_JOYPAD_MASK ? static_cast<int16_t>(mask) : (id < 16 && (mask & (1u << id)) ? 1 : 0);
}

void NativeBackend::video(const void* pixels, unsigned width, unsigned height, size_t pitch) {
    if (benchmarking_) return;
    if (!pixels || !width || !height || width > 1024 || height > 1024) return;
    videoScratch_.resize(width * height);
    for (unsigned y = 0; y < height; ++y) {
        const auto* line = static_cast<const uint8_t*>(pixels) + y * pitch;
        for (unsigned x = 0; x < width; ++x) {
            uint32_t r, g, b;
            if (pixelFormat_ == RETRO_PIXEL_FORMAT_XRGB8888) { auto value = reinterpret_cast<const uint32_t*>(line)[x]; r = (value >> 16) & 255; g = (value >> 8) & 255; b = value & 255; }
            else { auto value = reinterpret_cast<const uint16_t*>(line)[x];
                if (pixelFormat_ == RETRO_PIXEL_FORMAT_RGB565) { r = ((value >> 11) & 31) * 255 / 31; g = ((value >> 5) & 63) * 255 / 63; b = (value & 31) * 255 / 31; }
                else { r = ((value >> 10) & 31) * 255 / 31; g = ((value >> 5) & 31) * 255 / 31; b = (value & 31) * 255 / 31; }
            }
            videoScratch_[y * width + x] = 0xff000000u | (b << 16) | (g << 8) | r;
        }
    }
    { std::lock_guard<std::mutex> guard(videoMutex_); latestPixels_.swap(videoScratch_); videoWidth_ = width; videoHeight_ = height; ++videoGeneration_; }
    videoReady_.notify_one(); ++renderedFrames_;
}

void NativeBackend::presentationLoop() {
    uint64_t presented = 0;
    std::vector<uint32_t> pixels;
#ifdef __ANDROID__
    EGLDisplay display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    EGLContext context = EGL_NO_CONTEXT; EGLSurface surface = EGL_NO_SURFACE; EGLConfig configuration{};
    ANativeWindow* activeWindow = nullptr; GLuint program = 0, texture = 0; unsigned textureWidth = 0, textureHeight = 0;
    GLint positionAttribute = -1, textureAttribute = -1;
    bool initialized = display != EGL_NO_DISPLAY && eglInitialize(display, nullptr, nullptr);
    if (initialized) {
        const EGLint attributes[] = {EGL_SURFACE_TYPE, EGL_WINDOW_BIT, EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,
            EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8, EGL_NONE};
        EGLint count = 0; initialized = eglChooseConfig(display, attributes, &configuration, 1, &count) && count;
        if (initialized) { const EGLint contextAttributes[] = {EGL_CONTEXT_CLIENT_VERSION, 2, EGL_NONE}; context = eglCreateContext(display, configuration, EGL_NO_CONTEXT, contextAttributes); initialized = context != EGL_NO_CONTEXT; }
    }
    if (!initialized) renderError_.store(eglGetError());
    auto compileShader = [](GLenum type, const char* source) -> GLuint {
        auto shader = glCreateShader(type); glShaderSource(shader, 1, &source, nullptr); glCompileShader(shader);
        GLint compiled = 0; glGetShaderiv(shader, GL_COMPILE_STATUS, &compiled);
        if (!compiled) { glDeleteShader(shader); return 0; } return shader;
    };
#endif
    while (!stopping_.load()) {
        unsigned width, height; ANativeWindow* window;
        { std::unique_lock<std::mutex> guard(videoMutex_);
          videoReady_.wait(guard, [this, presented] { return stopping_.load() || videoGeneration_ != presented; });
          if (stopping_.load()) break;
          presented = videoGeneration_; window = window_; width = videoWidth_; height = videoHeight_;
          if (!window) continue;
          if (latestPixels_.empty()) { width = height = 1; pixels.assign(1, 0xff000000u); }
          else pixels = latestPixels_;
#ifdef __ANDROID__
          ANativeWindow_acquire(window);
#endif
        }
#ifdef __ANDROID__
        if (!initialized) { ANativeWindow_release(window); continue; }
        if (window != activeWindow || surface == EGL_NO_SURFACE) {
            eglMakeCurrent(display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
            if (surface != EGL_NO_SURFACE) eglDestroySurface(display, surface);
            if (activeWindow) ANativeWindow_release(activeWindow);
            activeWindow = window; // Takes the reference acquired above.
            EGLint format = 0; eglGetConfigAttrib(display, configuration, EGL_NATIVE_VISUAL_ID, &format);
            ANativeWindow_setBuffersGeometry(activeWindow, 0, 0, format);
            surface = eglCreateWindowSurface(display, configuration, activeWindow, nullptr);
            if (surface == EGL_NO_SURFACE || !eglMakeCurrent(display, surface, surface, context)) { renderError_.store(eglGetError()); continue; }
            eglSwapInterval(display, 1);
            if (!program) {
                // A plain framebuffer copy. There are no display effects or
                // retro shaders; GL_NEAREST preserves the core's exact pixels.
                const char* vertexSource = "attribute vec2 position; attribute vec2 texcoord; varying vec2 uv; void main(){uv=texcoord;gl_Position=vec4(position,0.0,1.0);}";
                const char* fragmentSource = "precision mediump float; varying vec2 uv; uniform sampler2D framebuffer; void main(){gl_FragColor=texture2D(framebuffer,uv);}";
                auto vertex = compileShader(GL_VERTEX_SHADER, vertexSource), fragment = compileShader(GL_FRAGMENT_SHADER, fragmentSource);
                if (!vertex || !fragment) { renderError_.store(-1); if (vertex) glDeleteShader(vertex); if (fragment) glDeleteShader(fragment); continue; }
                program = glCreateProgram(); glAttachShader(program, vertex); glAttachShader(program, fragment); glLinkProgram(program);
                glDeleteShader(vertex); glDeleteShader(fragment); GLint linked = 0; glGetProgramiv(program, GL_LINK_STATUS, &linked);
                if (!linked) { glDeleteProgram(program); program = 0; renderError_.store(-2); continue; }
                positionAttribute = glGetAttribLocation(program, "position"); textureAttribute = glGetAttribLocation(program, "texcoord");
                glGenTextures(1, &texture); glBindTexture(GL_TEXTURE_2D, texture);
                glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
                glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
            }
        } else ANativeWindow_release(window);
        if (!program || surface == EGL_NO_SURFACE) continue;
        EGLint screenWidth = 0, screenHeight = 0;
        eglQuerySurface(display, surface, EGL_WIDTH, &screenWidth); eglQuerySurface(display, surface, EGL_HEIGHT, &screenHeight);
        glViewport(0, 0, screenWidth, screenHeight); glClearColor(0, 0, 0, 1); glClear(GL_COLOR_BUFFER_BIT);
        const float aspect = fourThreeAspect_.load() ? 4.0f / 3.0f : float(width) / height;
        int dw = std::max(1, int(std::min(float(screenWidth), float(screenHeight) * aspect)));
        int dh = std::max(1, int(dw / aspect));
        glViewport((screenWidth - dw) / 2, (screenHeight - dh) / 2, dw, dh);
        glUseProgram(program); glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, texture);
        glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
        if (width != textureWidth || height != textureHeight) {
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, pixels.data()); textureWidth = width; textureHeight = height;
        } else glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, width, height, GL_RGBA, GL_UNSIGNED_BYTE, pixels.data());
        glUniform1i(glGetUniformLocation(program, "framebuffer"), 0);
        static const GLfloat positions[] = {-1,-1, 1,-1, -1,1, 1,1};
        static const GLfloat coordinates[] = {0,1, 1,1, 0,0, 1,0};
        glEnableVertexAttribArray(positionAttribute); glVertexAttribPointer(positionAttribute, 2, GL_FLOAT, GL_FALSE, 0, positions);
        glEnableVertexAttribArray(textureAttribute); glVertexAttribPointer(textureAttribute, 2, GL_FLOAT, GL_FALSE, 0, coordinates);
        glDrawArrays(GL_TRIANGLE_STRIP, 0, 4);
        // This may wait for Android VSYNC. Only presentation waits; the core's
        // hardware-rate clock and audio thread continue independently.
        if (eglSwapBuffers(display, surface)) { presentationCount_.fetch_add(1); renderError_.store(0); }
        else {
            renderError_.store(eglGetError()); eglMakeCurrent(display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
            eglDestroySurface(display, surface); surface = EGL_NO_SURFACE;
        }
#else
        (void)pixels; (void)width; (void)height; (void)window;
#endif
    }
#ifdef __ANDROID__
    if (initialized) {
        if (surface != EGL_NO_SURFACE) { eglMakeCurrent(display, surface, surface, context); if (texture) glDeleteTextures(1, &texture); if (program) glDeleteProgram(program); }
        eglMakeCurrent(display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (surface != EGL_NO_SURFACE) eglDestroySurface(display, surface);
        if (context != EGL_NO_CONTEXT) eglDestroyContext(display, context);
        eglTerminate(display);
    }
    if (activeWindow) ANativeWindow_release(activeWindow);
#endif
}

void NativeBackend::openAudio() {
    outputSampleRate_ = static_cast<int32_t>(sampleRate_);
#ifdef __ANDROID__
    AAudioStreamBuilder* builder = nullptr;
    if (AAudio_createStreamBuilder(&builder) != AAUDIO_OK) { error_ = "Android audio output could not start"; return; }
    AAudioStreamBuilder_setDirection(builder, AAUDIO_DIRECTION_OUTPUT);
    AAudioStreamBuilder_setSharingMode(builder, AAUDIO_SHARING_MODE_SHARED);
    AAudioStreamBuilder_setPerformanceMode(builder, AAUDIO_PERFORMANCE_MODE_LOW_LATENCY);
    AAudioStreamBuilder_setFormat(builder, AAUDIO_FORMAT_PCM_I16);
    AAudioStreamBuilder_setChannelCount(builder, 2);
    AAudioStreamBuilder_setSampleRate(builder, static_cast<int32_t>(sampleRate_));
    AAudioStreamBuilder_setDataCallback(builder, dataCallback, this);
    AAudioStreamBuilder_setErrorCallback(builder, errorCallback, this);
    auto result = AAudioStreamBuilder_openStream(builder, &audioStream_);
    AAudioStreamBuilder_delete(builder);
    if (result != AAUDIO_OK || !audioStream_) { audioStream_ = nullptr; error_ = std::string("Android audio error: ") + AAudio_convertResultToText(result); return; }
    outputSampleRate_ = AAudioStream_getSampleRate(audioStream_);
    if (AAudioStream_getFormat(audioStream_) != AAUDIO_FORMAT_PCM_I16 || AAudioStream_getChannelCount(audioStream_) != 2) { closeAudio(); error_ = "Android did not provide stereo PCM audio"; return; }
    int burst = AAudioStream_getFramesPerBurst(audioStream_);
    AAudioStream_setBufferSizeInFrames(audioStream_, std::max(burst * 3, outputSampleRate_ / 50));
    if (AAudioStream_requestStart(audioStream_) != AAUDIO_OK) { closeAudio(); error_ = "Android could not start the PCM output stream"; }
#endif
}

void NativeBackend::closeAudio() {
    audioMuted_.store(true);
#ifdef __ANDROID__
    if (audioStream_) { AAudioStream_requestStop(audioStream_); AAudioStream_close(audioStream_); audioStream_ = nullptr; }
#endif
    flushAudio();
}
void NativeBackend::flushAudio(bool resetResampler) {
    audioFlush_.store(true); audioPrimed_.store(false);
    if (resetResampler) { resamplePosition_ = 0; resamplePrevious_[0] = resamplePrevious_[1] = 0; }
}
void NativeBackend::audioError(int) { audioMuted_.store(true); audioReopen_.store(true); commandReady_.notify_one(); }

size_t NativeBackend::audio(const int16_t* samples, size_t frames) {
    if (!frames || !samples || benchmarking_ || rewinding_) return frames;
    recordRewindAudio(samples, frames);
    if (!audioEnabled_ || paused_) return frames;
    const double speed = fastForwardHeld_ ? fastForwardMultiplier_ : 1.0;
    if (outputSampleRate_ == int(sampleRate_) && speed == 1) writeAudio(samples, frames);
    else {
        const double step = sampleRate_ * speed / outputSampleRate_;
        audioScratch_.clear();
        while (resamplePosition_ < frames) {
            auto index = static_cast<int64_t>(resamplePosition_); double fraction = resamplePosition_ - index;
            int16_t values[2];
            for (int channel = 0; channel < 2; ++channel) {
                int16_t a = index == 0 ? resamplePrevious_[channel] : samples[(index - 1) * 2 + channel];
                int16_t b = samples[index * 2 + channel]; values[channel] = static_cast<int16_t>(a + (b - a) * fraction);
            }
            audioScratch_.push_back(values[0]); audioScratch_.push_back(values[1]); resamplePosition_ += step;
        }
        resamplePosition_ -= frames;
        resamplePrevious_[0] = samples[(frames - 1) * 2]; resamplePrevious_[1] = samples[(frames - 1) * 2 + 1];
        writeAudio(audioScratch_.data(), audioScratch_.size() / 2);
    }
    return frames;
}

void NativeBackend::writeAudio(const int16_t* samples, size_t frames) {
    auto write = audioWrite_.load(std::memory_order_relaxed);
    const auto read = audioRead_.load(std::memory_order_acquire);
    const auto accepted = std::min<uint64_t>(frames, audioCapacity_ - std::min<uint64_t>(write - read, audioCapacity_));
    for (size_t i = 0; i < accepted; ++i) {
        const auto offset = (write % audioCapacity_) * 2;
        audioRing_[offset] = samples[i * 2]; audioRing_[offset + 1] = samples[i * 2 + 1]; ++write;
    }
    audioOverruns_.fetch_add(frames - accepted);
    audioWrite_.store(write, std::memory_order_release);
}

void NativeBackend::recordRewindAudio(const int16_t* samples, size_t frames) {
    if (!rewindSeconds_) return;
    const uint64_t segmentFrame = frame_ + 1;
    if (rewindPcm_.empty() || rewindPcm_.back().frame != segmentFrame)
        rewindPcm_.push_back(PcmSegment{segmentFrame, pcmTimelineSamples_, {}});
    auto& segment = rewindPcm_.back();
    const auto previousAllocation = segment.samples.capacity() * sizeof(int16_t);
    segment.samples.insert(segment.samples.end(), samples, samples + frames * 2);
    rewindPcmBytes_ += segment.samples.capacity() * sizeof(int16_t) - previousAllocation;
    pcmTimelineSamples_ += frames;
    trimRewind();
}

void NativeBackend::rewindTick() {
    if (rewind_.empty()) { audioMuted_.store(true); return; }
    const double exactFrames = double(outputSampleRate_) / fps_ + rewindOutputCarry_;
    const auto outputFrames = static_cast<size_t>(exactFrames);
    rewindOutputCarry_ = exactFrames - outputFrames;
    rewindPositionFrames_ = std::max(double(rewind_.front().frame), rewindPositionFrames_
        - outputFrames * fps_ * rewindMultiplier_ / outputSampleRate_);

    // Play recorded native YM2612/PSG PCM backwards. Sample interpolation
    // changes timeline speed while preserving each stereo frame's L/R order.
    // No emulator frames are executed to synthesize substitute rewind audio.
    audioScratch_.clear();
    if (!rewindPcm_.empty()) {
        const double firstSample = double(rewindPcm_.front().firstSample);
        size_t segmentIndex = rewindPcm_.size() - 1;
        const double step = sampleRate_ * rewindMultiplier_ / outputSampleRate_;
        auto valueAt = [&](uint64_t sample, unsigned channel) -> int16_t {
            while (segmentIndex && sample < rewindPcm_[segmentIndex].firstSample) --segmentIndex;
            while (segmentIndex + 1 < rewindPcm_.size()
                   && sample >= rewindPcm_[segmentIndex].firstSample + rewindPcm_[segmentIndex].samples.size() / 2) ++segmentIndex;
            const auto& segment = rewindPcm_[segmentIndex];
            if (sample < segment.firstSample || sample >= segment.firstSample + segment.samples.size() / 2) return 0;
            return segment.samples[(sample - segment.firstSample) * 2 + channel];
        };
        for (size_t i = 0; i < outputFrames && rewindPcmCursor_ >= firstSample; ++i) {
            const auto sample = static_cast<uint64_t>(rewindPcmCursor_);
            const double fraction = rewindPcmCursor_ - sample;
            for (unsigned channel = 0; channel < 2; ++channel) {
                const int16_t a = valueAt(sample, channel);
                const int16_t b = fraction ? valueAt(sample + 1, channel) : a;
                audioScratch_.push_back(static_cast<int16_t>(a + (b - a) * fraction));
            }
            rewindPcmCursor_ -= step;
        }
    }
    audioMuted_.store(!audioEnabled_ || !rewindAudio_);
    if (audioEnabled_ && rewindAudio_ && !audioScratch_.empty()) {
        writeAudio(audioScratch_.data(), audioScratch_.size() / 2);
        reverseOutputFrames_ += audioScratch_.size() / 2;
    }

    // Native states are sampled independently of Android frames. Restore the
    // newest state at/before the continuous timeline cursor; the snapshot
    // interval affects visual granularity, never rewind speed.
    const Snapshot* selected = &rewind_.front();
    for (auto state = rewind_.rbegin(); state != rewind_.rend(); ++state)
        if (state->frame <= rewindPositionFrames_) { selected = &*state; break; }
    if (selected->frame < frame_) {
        const auto failure = restore(selected->bytes, true);
        if (!failure.empty()) { error_ = failure; endRewind(); }
    }
}

void NativeBackend::endRewind() {
    if (!rewinding_) return;
    // Release branches from the full state that was actually restored. Future
    // state snapshots and their PCM must not leak into the new play timeline.
    while (!rewind_.empty() && rewind_.back().frame > frame_) { rewindBytes_ -= rewind_.back().bytes.capacity(); rewind_.pop_back(); }
    while (!rewindPcm_.empty() && rewindPcm_.back().frame > frame_) { rewindPcmBytes_ -= rewindPcm_.back().samples.capacity() * sizeof(int16_t); rewindPcm_.pop_back(); }
    pcmTimelineSamples_ = rewindPcm_.empty() ? 0 : rewindPcm_.back().firstSample + rewindPcm_.back().samples.size() / 2;
    rewinding_ = false; reverseAudioOutput_.store(false); flushAudio(false);
    audioMuted_.store(!audioEnabled_ || paused_); clockReset_ = true;
}

int NativeBackend::audioCallback(void* output, int32_t frames) {
    auto* samples = static_cast<int16_t*>(output); std::fill_n(samples, size_t(frames) * 2, 0);
    auto read = audioRead_.load(std::memory_order_relaxed); auto write = audioWrite_.load(std::memory_order_acquire);
    if (audioFlush_.exchange(false) || audioMuted_.load()) { audioRead_.store(write, std::memory_order_release); audioPrimed_.store(false); return 0; }
    // Hold roughly two emulated frames on stream startup/load. Silence here
    // prevents an underrun click; every audible sample comes from the core.
    if (!audioPrimed_.load()) {
        const uint64_t primeFrames = reverseAudioOutput_.load() ? 1 : outputSampleRate_ / 30;
        if (write - read < primeFrames) return 0;
        audioPrimed_.store(true);
    }
    uint32_t count = static_cast<uint32_t>(std::min<uint64_t>(write - read, frames));
    for (uint32_t i = 0; i < count; ++i) { auto offset = ((read + i) % audioCapacity_) * 2; samples[i * 2] = audioRing_[offset]; samples[i * 2 + 1] = audioRing_[offset + 1]; }
    if (count < static_cast<uint32_t>(frames)) audioUnderruns_.fetch_add(1);
    audioRead_.store(read + count, std::memory_order_release); return 0;
}

void NativeBackend::configureDomains() {
    std::vector<MemoryDomain> domains;
    auto add = [&](const std::string& id, const std::string& name, uint8_t* base, uint32_t size, bool bigEndian, bool persistent, bool swapped) {
        MemoryDomain domain; domain.id = id; domain.name = name; domain.base = base; domain.size = size;
        domain.writable = true; domain.persistent = persistent; domain.bigEndian = bigEndian;
        domain.read8 = [base, size, swapped](uint32_t offset) -> uint8_t { return offset < size ? base[offset ^ (swapped ? 1 : 0)] : 0; };
        domain.write8 = [this, id](uint32_t offset, uint8_t value) { writeDomainByte(id, offset, value); };
        domains.push_back(std::move(domain));
    };
    add("wram", "68000 Work RAM", work_ram, sizeof(work_ram), true, false, true);
    add("zram", "Z80 RAM", zram, sizeof(zram), false, false, false);
    add("vram", "VRAM", vram, sizeof(vram), true, false, true);
    add("cram", "CRAM", cram, sizeof(cram), true, false, true);
    domains.back().read8 = [](uint32_t offset) -> uint8_t {
        if (offset >= sizeof(cram)) return 0;
        uint16_t packed; std::memcpy(&packed, cram + (offset & ~1u), 2);
        uint16_t bus = ((packed & 0x1c0) << 3) | ((packed & 0x38) << 2) | ((packed & 7) << 1);
        return offset & 1 ? bus & 255 : bus >> 8;
    };
    // Only the hardware's 40 VSRAM words are exposed, not the core's padding.
    add("vsram", "VSRAM", vsram, 80, true, false, true);
    if (sram.on) add("sram", "Cartridge SRAM / CARTRAM", sram.sram, sizeof(sram.sram), false, true, false);
    add("rom", "ROM working copy (original is preserved)", cart.rom, cart.romsize, true, false, true);
    rtc_.setDomains(std::move(domains));
}

void NativeBackend::writeDomainByte(const std::string& domain, uint32_t offset, uint8_t value) {
    if (domain == "wram") { if (offset < sizeof(work_ram)) work_ram[offset ^ 1] = value; }
    else if (domain == "zram") { if (offset < sizeof(zram)) zram[offset] = value; }
    else if (domain == "vram") {
        if (offset >= sizeof(vram)) return;
        vram[offset ^ 1] = value; unsigned name = offset >> 5;
        if (!bg_name_dirty[name] && bg_list_index < 0x800) bg_name_list[bg_list_index++] = name;
        bg_name_dirty[name] |= 1u << ((offset >> 2) & 7);
        unsigned baseMask = (reg[12] & 1) ? 0xfc00 : 0xfe00;
        unsigned addressMask = (reg[12] & 1) ? 0x3ff : 0x1ff;
        if ((offset & baseMask) == satb) sat[(offset & addressMask) ^ 1] = value;
    } else if (domain == "cram") {
        if (offset >= sizeof(cram)) return;
        unsigned index = offset >> 1; uint16_t old; std::memcpy(&old, cram + (offset & ~1u), 2);
        uint16_t bus = ((old & 0x1c0) << 3) | ((old & 0x38) << 2) | ((old & 7) << 1);
        bus = offset & 1 ? (bus & 0xff00) | value : (bus & 0xff) | (uint16_t(value) << 8);
        uint16_t color = ((bus & 0xe00) >> 3) | ((bus & 0xe0) >> 2) | ((bus & 0xe) >> 1);
        std::memcpy(cram + (offset & ~1u), &color, 2);
        // Matching VDP bus semantics keeps internal packed CRAM <= 511,
        // including after native core state loading rebuilds its palettes.
        if (index & 15) color_update_m5(index, color);
        if (index == (reg[7] & 0x3f)) color_update_m5(0, color);
    } else if (domain == "vsram") { if (offset < 80) vsram[offset ^ 1] = value; }
    else if (domain == "sram") { if (sram.on && offset < sizeof(sram.sram)) sram.sram[offset] = value; }
    else if (domain == "rom") {
        if (offset >= cart.romsize || (offset ^ 1u) >= normalizedOriginal_.size()) return;
        cart.rom[offset ^ 1] = value;
        if (value == normalizedOriginal_[offset ^ 1]) romPatches_.erase(offset); else romPatches_[offset] = value;
    }
}

std::vector<uint8_t> NativeBackend::snapshot() {
    if (!loaded_) return {};
    std::vector<uint8_t> core(retro_serialize_size(), 0);
    if (!retro_serialize(core.data(), core.size())) throw std::runtime_error("The native core could not serialize its state");
    std::vector<uint8_t> raw; raw.reserve(core.size() + 128 * 1024);
    appendString(raw, romKey_); append32(raw, sizeof(void*)); append64(raw, frame_);
    auto checkpoint = rtc_.checkpoint(); append64(raw, checkpoint.session); append64(raw, checkpoint.blastCursor);
    append32(raw, checkpoint.activeBlasts.size()); for (auto blast : checkpoint.activeBlasts) append64(raw, blast);
    append32(raw, core.size()); appendBytes(raw, core.data(), core.size());
    std::vector<uint8_t> sound(bg_sound_size());
    if (!bg_sound_save(sound.data(), sound.size())) throw std::runtime_error("Cannot capture the native audio phase");
    append32(raw, sound.size()); appendBytes(raw, sound.data(), sound.size());
    append32(raw, m68k.pref_addr); append32(raw, m68k.pref_data); append32(raw, m68k.ir); append32(raw, m68k.refresh_cycles);
    append32(raw, m68k.instr_mode); append32(raw, m68k.run_mode);
    std::vector<uint8_t> pads(bg_gamepad_size());
    if (!bg_gamepad_save(pads.data(), pads.size())) throw std::runtime_error("Cannot capture native controller protocol state");
    append32(raw, pads.size()); appendBytes(raw, pads.data(), pads.size()); append32(raw, sixButton_ ? 1 : 0);
    appendBytes(raw, &resamplePosition_, sizeof(resamplePosition_)); appendBytes(raw, resamplePrevious_, sizeof(resamplePrevious_));
    // Upstream Genesis Plus GX's state.c does not include SRAM contents.
    append32(raw, sizeof(sram.sram)); appendBytes(raw, sram.sram, sizeof(sram.sram));
    append32(raw, romPatches_.size()); for (auto patch : romPatches_) { append32(raw, patch.first); raw.push_back(patch.second); }
    { std::lock_guard<std::mutex> guard(videoMutex_);
      append32(raw, videoWidth_); append32(raw, videoHeight_); append32(raw, latestPixels_.size());
      appendBytes(raw, latestPixels_.data(), latestPixels_.size() * sizeof(uint32_t)); }
    uLongf compressedSize = compressBound(raw.size()); std::vector<uint8_t> output(12 + compressedSize);
    std::memcpy(output.data(), "BGNS003Z", 8); output[8] = raw.size() >> 24; output[9] = raw.size() >> 16; output[10] = raw.size() >> 8; output[11] = raw.size();
    if (compress2(output.data() + 12, &compressedSize, raw.data(), raw.size(), 1) != Z_OK) throw std::runtime_error("Cannot compress the native state");
    output.resize(12 + compressedSize);
    // resize() alone retains the uncompressed-sized allocation. Each RAM ring
    // entry must own only its compressed bytes or long histories would exceed
    // the memory budget while the accounting misleadingly stayed small.
    return std::vector<uint8_t>(output.begin(), output.end());
}

std::string NativeBackend::restore(const std::vector<uint8_t>& data, bool fromRewind) {
    if (!loaded_) return "Load a ROM before restoring a state";
    try {
        if (data.size() < 12 || std::memcmp(data.data(), "BGNS003Z", 8)) return "This is not a native BadGenesis state";
        uint32_t size = (uint32_t(data[8]) << 24) | (uint32_t(data[9]) << 16) | (uint32_t(data[10]) << 8) | data[11];
        if (size > 64 * 1024 * 1024 || size < retro_serialize_size()) return "Invalid native state size";
        std::vector<uint8_t> raw(size); uLongf outputSize = size;
        if (uncompress(raw.data(), &outputSize, data.data() + 12, data.size() - 12) != Z_OK || outputSize != size) return "The native state is damaged";
        StateReader reader{raw}; if (reader.string() != romKey_) return "This state belongs to a different original ROM";
        if (reader.u32() != sizeof(void*)) return "This state uses a different native CPU architecture";
        auto restoredFrame = reader.u64(); RtcCheckpoint checkpoint;
        checkpoint.frame = restoredFrame; checkpoint.session = reader.u64(); checkpoint.blastCursor = reader.u64();
        auto count = reader.u32(); if (count > 100000) return "Invalid RTC history checkpoint";
        for (uint32_t i = 0; i < count; ++i) checkpoint.activeBlasts.push_back(reader.u64());
        auto coreSize = reader.u32(); if (coreSize != retro_serialize_size()) return "State uses a different Genesis core version";
        auto core = reader.bytes(coreSize); auto soundSize = reader.u32(); if (soundSize != bg_sound_size()) return "Invalid native audio state";
        auto sound = reader.bytes(soundSize); auto prefAddress = reader.u32(), prefData = reader.u32(), instructionRegister = reader.u32(), refreshCycles = reader.u32();
        auto instructionMode = reader.u32(), runMode = reader.u32();
        auto padSize = reader.u32(); if (padSize != bg_gamepad_size()) return "Invalid controller protocol state";
        auto pads = reader.bytes(padSize); auto savedSixButton = reader.u32(); if (savedSixButton > 1) return "Invalid controller type";
        double savedPosition = 0; int16_t savedPrevious[2];
        auto positionBytes = reader.bytes(sizeof(savedPosition)); std::memcpy(&savedPosition, positionBytes.data(), sizeof(savedPosition));
        auto previousBytes = reader.bytes(sizeof(savedPrevious)); std::memcpy(savedPrevious, previousBytes.data(), sizeof(savedPrevious));
        if (!std::isfinite(savedPosition) || savedPosition < 0 || savedPosition > 24) return "Invalid audio resampler phase";
        auto sramSize = reader.u32(); if (sramSize != sizeof(sram.sram)) return "Invalid cartridge RAM state";
        auto savedSram = reader.bytes(sramSize); auto patchCount = reader.u32();
        if (patchCount > cart.romsize) return "Invalid ROM working-copy patch count";
        std::map<uint32_t, uint8_t> patches;
        for (uint32_t i = 0; i < patchCount; ++i) { auto address = reader.u32(); auto value = reader.byte(); if (address >= cart.romsize) return "ROM patch is outside the cartridge"; patches[address] = value; }
        auto width = reader.u32(), height = reader.u32(), pixelCount = reader.u32();
        if (width > 1024 || height > 1024 || uint64_t(width) * height != pixelCount) return "Invalid framebuffer in native state";
        auto savedPixels = reader.bytes(pixelCount * sizeof(uint32_t)); if (reader.position != raw.size()) return "Unexpected data in native state";
        // Validate the whole container before changing any live memory.
        if (!fromRewind) { endRewind(); fastForwardHeld_ = false; audioMuted_.store(true); }
        sixButton_ = savedSixButton != 0;
        retro_set_controller_port_device(0, RETRO_DEVICE_SUBCLASS(RETRO_DEVICE_JOYPAD, sixButton_ ? 1 : 0));
        if (!retro_unserialize(core.data(), core.size())) return "Genesis Plus GX rejected this state";
        if (!bg_sound_load(sound.data(), sound.size())) return "The native audio state is damaged";
        if (!bg_gamepad_load(pads.data(), pads.size())) return "The native controller state is damaged";
        std::memcpy(sram.sram, savedSram.data(), sizeof(sram.sram));
        for (auto patch : romPatches_) cart.rom[patch.first ^ 1] = normalizedOriginal_[patch.first ^ 1];
        romPatches_ = std::move(patches); for (auto patch : romPatches_) cart.rom[patch.first ^ 1] = patch.second;
        m68k.pref_addr = prefAddress; m68k.pref_data = prefData; m68k.ir = instructionRegister; m68k.refresh_cycles = refreshCycles;
        m68k.instr_mode = instructionMode; m68k.run_mode = runMode;
        frame_ = restoredFrame; rtc_.onRestore(checkpoint);
        { std::lock_guard<std::mutex> guard(videoMutex_); videoWidth_ = width; videoHeight_ = height;
          latestPixels_.resize(pixelCount); if (pixelCount) std::memcpy(latestPixels_.data(), savedPixels.data(), savedPixels.size()); ++videoGeneration_; }
        videoReady_.notify_one(); if (!fromRewind) flushAudio(); resamplePosition_ = savedPosition;
        std::memcpy(resamplePrevious_, savedPrevious, sizeof(resamplePrevious_)); clockReset_ = !fromRewind;
        if (!fromRewind) { clearRewind(); captureRewind(); }
        audioMuted_.store(!audioEnabled_ || (rewinding_ ? !rewindAudio_ : paused_)); return {};
    } catch (const std::exception& error) { return error.what(); }
}

void NativeBackend::clearRewind() {
    rewind_.clear(); rewindBytes_ = 0; rewindPcm_.clear(); rewindPcmBytes_ = 0;
    pcmTimelineSamples_ = 0; rewindPcmCursor_ = -1;
}
void NativeBackend::captureRewind() {
    if (!rewindSeconds_ || !loaded_) return;
    auto bytes = snapshot(); rewindBytes_ += bytes.capacity(); rewind_.push_back(Snapshot{frame_, std::move(bytes)});
    trimRewind();
}
void NativeBackend::trimRewind() {
    const uint64_t span = uint64_t(std::ceil(rewindSeconds_ * fps_));
    while (rewind_.size() > 1 && (rewindBytes_ + rewindPcmBytes_ > rewindByteLimit_
           || (frame_ > rewind_.front().frame && frame_ - rewind_.front().frame > span))) {
        rewindBytes_ -= rewind_.front().bytes.capacity(); rewind_.pop_front();
        while (!rewindPcm_.empty() && rewindPcm_.front().frame <= rewind_.front().frame) {
            rewindPcmBytes_ -= rewindPcm_.front().samples.capacity() * sizeof(int16_t); rewindPcm_.pop_front();
        }
    }
}
std::string NativeBackend::statePath(unsigned slot) const { return filesDirectory_ + "/" + romKey_ + "-slot-" + std::to_string(slot) + ".bgs"; }
std::string NativeBackend::recoveryPath() const { return filesDirectory_ + "/" + romKey_ + "-recovery.bgs"; }
void NativeBackend::persistSram() { if (loaded_ && sram.on) { try { std::vector<uint8_t> bytes(sram.sram, sram.sram + sizeof(sram.sram)); writeFile(filesDirectory_ + "/" + romKey_ + ".srm", bytes); } catch (const std::exception& error) { error_ = error.what(); } } }
void NativeBackend::loadSram() { auto bytes = readFile(filesDirectory_ + "/" + romKey_ + ".srm", sizeof(sram.sram)); if (sram.on && bytes.size() == sizeof(sram.sram)) std::memcpy(sram.sram, bytes.data(), bytes.size()); }

std::string NativeBackend::command(std::string action, std::string json) { return onWorker([this, action = std::move(action), json = std::move(json)] { try { return commandOnWorker(action, json); } catch (const std::exception& error) { return failed(error.what()); } }); }
std::string NativeBackend::commandOnWorker(const std::string& action, const std::string& payload) {
    Json options = Json::parse(payload);
    if (action == "pause") { uiPaused_ = options["paused"].flag(true); paused_ = uiPaused_ || (harvester_ && !harvestRunning_); clockReset_ = true; if (paused_) { endRewind(); fastForwardHeld_ = false; audioMuted_.store(true); flushAudio(); persistSram(); } return successful(); }
    if (action == "audio") { audioEnabled_ = options["enabled"].flag(true); audioMuted_.store(!audioEnabled_ || (rewinding_ ? !rewindAudio_ : paused_)); flushAudio(); return successful(); }
    if (action == "speed_config") {
        const double forward = options.has("fastForwardMultiplier") ? options["fastForwardMultiplier"].number : fastForwardMultiplier_;
        const double reverse = options.has("rewindMultiplier") ? options["rewindMultiplier"].number : rewindMultiplier_;
        if (forward != 2 && forward != 3 && forward != 4 && forward != 8) return failed("Fast forward must be 2, 3, 4 or 8 times speed");
        if (reverse != .5 && reverse != 1 && reverse != 2 && reverse != 4 && reverse != 8 && reverse != 16) return failed("Rewind must be 0.5, 1, 2, 4, 8 or 16 times speed");
        fastForwardMultiplier_ = forward; rewindMultiplier_ = reverse;
        if (options.has("rewindAudio")) rewindAudio_ = options["rewindAudio"].flag(true);
        audioMuted_.store(!audioEnabled_ || (rewinding_ ? !rewindAudio_ : paused_)); flushAudio(); clockReset_ = true;
        return successful();
    }
    if (action == "fast_forward") {
        const bool held = options["held"].flag() && loaded_ && !paused_;
        if (held != fastForwardHeld_) {
            fastForwardHeld_ = held;
            if (!rewinding_) { flushAudio(); clockReset_ = true; }
        }
        return successful();
    }
    if (action == "display_config") {
        const auto aspect = options["aspect"].text("4:3");
        if (aspect != "4:3" && aspect != "pixel") return failed("Choose 4:3 or pixel aspect");
        fourThreeAspect_.store(aspect == "4:3");
        { std::lock_guard<std::mutex> guard(videoMutex_); ++videoGeneration_; } videoReady_.notify_one();
        return successful();
    }
    if (action == "controller") { sixButton_ = options["sixButton"].flag(true); if (loaded_) retro_set_controller_port_device(0, RETRO_DEVICE_SUBCLASS(RETRO_DEVICE_JOYPAD, sixButton_ ? 1 : 0)); return successful(); }
    if (action == "rtc_config") {
        if (options.has("engine") && !rtc_.setEngine(options["engine"].text())) return failed("Unknown corruption engine");
        if (options.has("intensity")) rtc_.setIntensity(std::clamp<int64_t>(options["intensity"].integer(), 1, 100000));
        if (options.has("manualSeed")) {
            uint64_t seed = 0;
            if (options["seed"].type == Json::String && !options["seed"].string.empty()) {
                const auto& text = options["seed"].string; size_t consumed = 0;
                if (text[0] == '-') return failed("An advanced seed must be an unsigned 64-bit integer");
                int base = text.size() > 2 && text[0] == '0' && (text[1] == 'x' || text[1] == 'X') ? 16 : 10;
                seed = std::stoull(text, &consumed, base); if (consumed != text.size()) return failed("Invalid advanced seed");
            } else seed = static_cast<uint64_t>(options["seed"].integer());
            rtc_.setManualSeed(options["manualSeed"].flag(), seed);
        }
        if (options.has("auto") || options.has("interval") || options.has("autoEnabled") || options.has("intervalFrames")) {
            const auto& enabled = options.has("auto") ? options["auto"] : options["autoEnabled"];
            const auto& interval = options.has("interval") ? options["interval"] : options["intervalFrames"];
            rtc_.setAutoBlast(enabled.flag(rtc_.autoBlastEnabled()), std::clamp<int64_t>(interval.integer(rtc_.autoBlastInterval()), 1, 36000));
        }
        for (const auto& domain : options["domains"].array) {
            std::string id = domain["id"].text(); auto config = rtc_.domainConfig(id);
            if (domain.has("enabled")) config.enabled = domain["enabled"].flag();
            if (domain.has("start")) config.start = std::clamp<int64_t>(domain["start"].integer(), 0, UINT32_MAX);
            if (domain.has("end")) { auto end = domain["end"].integer(UINT32_MAX); config.end = end < 0 ? UINT32_MAX : std::min<int64_t>(end, UINT32_MAX); }
            if (domain.has("exclusions")) { config.exclusions.clear(); for (const auto& range : domain["exclusions"].array) {
                auto start = range.type == Json::Array && range.array.size() == 2 ? range.array[0].integer() : range["start"].integer();
                auto end = range.type == Json::Array && range.array.size() == 2 ? range.array[1].integer() : range["end"].integer();
                if (start < 0 || end < start || uint64_t(end) > UINT32_MAX) return failed("Invalid exclusion range");
                config.exclusions.push_back(AddressRange{uint32_t(start), uint32_t(end)});
            } }
            rtc_.setDomainConfig(id, config);
        }
        return "{\"ok\":true,\"config\":" + rtc_.configJson() + "}";
    }
    if (action == "rewind_config") {
        auto seconds = options["seconds"].integer(30); if (seconds != 0 && seconds != 15 && seconds != 30 && seconds != 60 && seconds != 120) return failed("Choose 15, 30, 60 or 120 seconds");
        endRewind(); rewindSeconds_ = seconds; snapshotInterval_ = std::clamp<int64_t>(options["intervalFrames"].integer(10), 1, 600); clearRewind(); if (loaded_) captureRewind(); return successful();
    }
    if (action == "history") return "{\"ok\":true,\"history\":" + rtc_.historyJson(options["includeUnits"].flag()) + "}";
    if (!loaded_) return failed("Load a Genesis / Mega Drive ROM first");
    if (action == "debug") {
        std::ostringstream out; out << "{\"ok\":true,\"m68000\":{\"PC\":" << m68k_get_reg(M68K_REG_PC) << ",\"SR\":" << m68k_get_reg(M68K_REG_SR);
        for (unsigned i = 0; i < 8; ++i) out << ",\"D" << i << "\":" << m68k_get_reg(static_cast<m68k_register_t>(M68K_REG_D0 + i));
        for (unsigned i = 0; i < 8; ++i) out << ",\"A" << i << "\":" << m68k_get_reg(static_cast<m68k_register_t>(M68K_REG_A0 + i));
        out << "},\"z80\":{\"PC\":" << Z80.pc.w.l << ",\"SP\":" << Z80.sp.w.l << ",\"AF\":" << Z80.af.w.l << ",\"BC\":" << Z80.bc.w.l << ",\"DE\":" << Z80.de.w.l << ",\"HL\":" << Z80.hl.w.l << "},\"vdpRegisters\":[";
        for (unsigned i = 0; i < sizeof(reg); ++i) { if (i) out << ','; out << unsigned(reg[i]); }
        out << "],\"dmaLength\":" << dma_length << ",\"status\":" << ::status << '}'; return out.str();
    }
    if (action == "rewind") {
        const bool held = options["held"].flag();
        if (!held) { endRewind(); return successful(); }
        if (!rewindSeconds_) return failed("Enable a rewind history preset first");
        if (!rewinding_) {
            captureRewind(); rewinding_ = true;
            rewindPositionFrames_ = double(frame_); rewindOutputCarry_ = 0;
            rewindPcmCursor_ = rewindPcm_.empty() ? -1 : double(rewindPcm_.back().firstSample + rewindPcm_.back().samples.size() / 2) - 1;
            reverseAudioOutput_.store(true); flushAudio(); clockReset_ = true;
        }
        audioMuted_.store(!audioEnabled_ || !rewindAudio_); return successful();
    }
    if (action == "benchmark") {
        const auto frames = std::clamp<int64_t>(options["frames"].integer(120), 1, 1200);
        const auto clean = snapshot(); benchmarking_ = true; audioMuted_.store(true); flushAudio();
        const auto start = std::chrono::steady_clock::now();
        for (int64_t i = 0; i < frames; ++i) retro_run();
        const double milliseconds = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - start).count();
        benchmarking_ = false;
        const auto failure = restore(clean, true); clockReset_ = true;
        if (!failure.empty()) return failed(failure);
        std::ostringstream result; result << "{\"ok\":true,\"frames\":" << frames << ",\"elapsedMs\":" << milliseconds
            << ",\"frameMs\":" << milliseconds / frames << ",\"fps\":" << frames * 1000.0 / std::max(milliseconds, .001) << '}';
        return result.str();
    }
    if (action == "blast") { recoveryState_ = snapshot(); writeFile(recoveryPath(), recoveryState_); captureRewind(); auto result = rtc_.blast(); message_ = result.message; return result.applied ? successful(message_) : failed(message_); }
    if (action == "undo") { auto result = rtc_.undoLastBlast(); message_ = result.message; return result.applied ? successful(message_) : failed(message_); }
    if (action == "replay") { auto result = rtc_.replay(options["blast"].integer(), options["requirePrevious"].flag()); return result.applied ? successful(result.message) : failed(result.message); }
    if (action == "quick_save") { quickState_ = snapshot(); return successful("Quick state saved separately from rewind"); }
    if (action == "quick_load") { if (quickState_.empty()) return failed("No quick state saved"); auto error = restore(quickState_, false); return error.empty() ? successful("Quick state restored") : failed(error); }
    if (action == "save_slot" || action == "load_slot") {
        auto slot = options["slot"].integer(); if (slot < 1 || slot > 4) return failed("Save slot must be 1 through 4");
        if (action == "save_slot") { writeFile(statePath(slot), snapshot()); return successful("Native save slot stored"); }
        auto state = readFile(statePath(slot)); if (state.empty()) return failed("This save slot is empty");
        auto error = restore(state, false); return error.empty() ? successful("Native save slot restored") : failed(error);
    }
    if (action == "recover") { auto state = recoveryState_.empty() ? readFile(recoveryPath()) : recoveryState_; if (state.empty()) return failed("No recovery state available"); auto error = restore(state, false); rtc_.setAutoBlast(false, rtc_.autoBlastInterval()); return error.empty() ? successful("Recovered the state before corruption") : failed(error); }
    if (action == "reset") { endRewind(); fastForwardHeld_ = false; retro_reset(); frame_ = 0; rtc_.onRestore(0, 0); clearRewind(); flushAudio(); clockReset_ = true; return successful("Core reset"); }
    if (action == "harvester_start") { harvesterClean_ = snapshot(); harvester_ = true; paused_ = true; harvestRunning_ = false; rtc_.setAutoBlast(false, rtc_.autoBlastInterval()); return successful("Clean native state captured. Choose Next to blast it."); }
    if (action == "harvester_next") {
        if (!harvester_ || harvesterClean_.empty()) return failed("Capture a clean harvester state first");
        auto error = restore(harvesterClean_, false); if (!error.empty()) return failed(error);
        harvestRunFrames_ = std::clamp<int64_t>(options["runFrames"].integer(60), 1, 36000);
        recoveryState_ = harvesterClean_; auto blast = rtc_.blast(); if (!blast.applied) return failed(blast.message);
        harvestEndFrame_ = frame_ + harvestRunFrames_; harvestRunning_ = true; paused_ = false; clockReset_ = true; return successful("Running the new corruption");
    }
    if (action == "harvester_keep") {
        if (!harvester_) return failed("Start the harvester first");
        lastKeptState_ = snapshot();
        auto savedAt = std::chrono::system_clock::now().time_since_epoch().count();
        writeFile(filesDirectory_ + "/harvest-" + romKey_ + "-" + std::to_string(rtc_.checkpoint().session) + "-" + std::to_string(savedAt) + "-" + std::to_string(rtc_.checkpoint().blastCursor) + ".bgs", lastKeptState_);
        writeFile(filesDirectory_ + "/last-kept-" + romKey_ + ".bgs", lastKeptState_);
        message_ = "Corruption kept in native app storage. Export Harvest to share it."; return successful(message_);
    }
    if (action == "harvester_discard") { if (!harvester_ || harvesterClean_.empty()) return failed("Start the harvester first"); harvestRunning_ = false; paused_ = true; auto error = restore(harvesterClean_, false); return error.empty() ? successful("Discarded and restored the clean native state") : failed(error); }
    if (action == "harvester_stop") { harvester_ = harvestRunning_ = false; paused_ = uiPaused_; clockReset_ = true; return successful(); }
    return failed("Unknown native command: " + action);
}

std::string NativeBackend::statusOnWorker() const {
    std::ostringstream out; out << std::setprecision(7);
    out << "{\"ok\":true,\"backend\":\"Genesis Plus GX native\",\"loaded\":" << (loaded_ ? "true" : "false")
        << ",\"rom\":" << Json::quote(romName_) << ",\"romName\":" << Json::quote(romName_) << ",\"region\":" << Json::quote(fps_ < 55 ? "PAL" : "NTSC") << ",\"frame\":" << frame_ << ",\"fps\":" << fps_ << ",\"measuredFps\":" << measuredFps_
        << ",\"frameMs\":" << frameMilliseconds_ << ",\"sampleRate\":" << sampleRate_ << ",\"outputSampleRate\":" << outputSampleRate_
        << ",\"paused\":" << (paused_ ? "true" : "false") << ",\"rewinding\":" << (rewinding_ ? "true" : "false")
        << ",\"fastForwardHeld\":" << (fastForwardHeld_ ? "true" : "false") << ",\"fastForwardMultiplier\":" << fastForwardMultiplier_
        << ",\"rewindMultiplier\":" << rewindMultiplier_ << ",\"rewindAudio\":" << (rewindAudio_ ? "true" : "false")
        << ",\"rewindPcmCursor\":" << rewindPcmCursor_ << ",\"reverseOutputFrames\":" << reverseOutputFrames_
        << ",\"displayAspect\":" << Json::quote(fourThreeAspect_.load() ? "4:3" : "pixel")
        << ",\"sixButton\":" << (sixButton_ ? "true" : "false") << ",\"audio\":" << (audioEnabled_ ? "true" : "false")
        << ",\"rewindSeconds\":" << rewindSeconds_ << ",\"rewindInterval\":" << snapshotInterval_ << ",\"rewindSnapshots\":" << rewind_.size()
        << ",\"rewindBytes\":" << rewindBytes_ + rewindPcmBytes_ << ",\"rewindAudioBytes\":" << rewindPcmBytes_
        << ",\"rewindAvailable\":" << (rewind_.empty() ? 0.0 : (frame_ - rewind_.front().frame) / fps_)
        << ",\"harvester\":" << (harvester_ ? "true" : "false") << ",\"harvestRunning\":" << (harvestRunning_ ? "true" : "false")
        << ",\"audioUnderruns\":" << audioUnderruns_.load() << ",\"audioOverruns\":" << audioOverruns_.load()
        << ",\"presentations\":" << presentationCount_.load() << ",\"videoError\":" << renderError_.load() << ",\"error\":" << Json::quote(error_) << ",\"message\":" << Json::quote(message_)
        << ",\"rtc\":" << rtc_.statusJson() << ",\"config\":" << rtc_.configJson() << "}";
    return out.str();
}
std::string NativeBackend::status() { return onWorker([this] { return statusOnWorker(); }); }
std::string NativeBackend::domains() { return onWorker([this] { return rtc_.domainsJson(); }); }
std::vector<uint8_t> NativeBackend::exportState() { return onWorker([this] { return snapshot(); }); }
std::string NativeBackend::importState(std::vector<uint8_t> state) { return onWorker([this, state = std::move(state)] { return restore(state, false); }); }
std::vector<uint8_t> NativeBackend::readMemory(std::string id, uint32_t start, uint32_t length) {
    return onWorker([this, id = std::move(id), start, length] {
        for (const auto& domain : rtc_.domains()) if (domain.id == id) {
            if (start >= domain.size) return std::vector<uint8_t>{};
            auto count = std::min<uint32_t>(std::min<uint32_t>(length, domain.size - start), 65536);
            std::vector<uint8_t> data(count); for (uint32_t i = 0; i < count; ++i) data[i] = domain.read8(start + i); return data;
        }
        return std::vector<uint8_t>{};
    });
}
std::vector<uint8_t> NativeBackend::exportData(std::string kind) {
    return onWorker([this, kind = std::move(kind)] {
        if (!loaded_) return std::vector<uint8_t>{};
        if (kind == "state") return snapshot();
        if (kind == "rewind_audio") {
            std::vector<uint8_t> data; data.reserve(rewindPcmBytes_);
            for (const auto& segment : rewindPcm_) appendBytes(data, segment.samples.data(), segment.samples.size() * sizeof(int16_t));
            return data;
        }
        if (kind == "harvest") return lastKeptState_.empty() ? readFile(filesDirectory_ + "/last-kept-" + romKey_ + ".bgs") : lastKeptState_;
        if (kind == "sram") return sram.on ? std::vector<uint8_t>(sram.sram, sram.sram + sizeof(sram.sram)) : std::vector<uint8_t>{};
        if (kind == "original") return originalRom_;
        if (kind == "rom") { std::vector<uint8_t> bytes(cart.romsize); for (uint32_t i = 0; i < cart.romsize; ++i) bytes[i] = cart.rom[i ^ 1]; return bytes; }
        if (kind == "history") { auto json = rtc_.historyJson(true); return std::vector<uint8_t>(json.begin(), json.end()); }
        return std::vector<uint8_t>{};
    });
}
std::string NativeBackend::importData(std::string kind, std::vector<uint8_t> data) {
    return onWorker([this, kind = std::move(kind), data = std::move(data)] {
        if (kind == "state" || kind == "harvest") return restore(data, false);
        if (kind == "sram") { if (!loaded_ || !sram.on) return std::string("This cartridge has no SRAM"); if (data.empty() || data.size() > sizeof(sram.sram)) return std::string("Invalid SRAM file size"); std::fill_n(sram.sram, sizeof(sram.sram), 0xff); std::memcpy(sram.sram, data.data(), data.size()); persistSram(); return std::string{}; }
        return std::string("Unsupported native import type");
    });
}
}

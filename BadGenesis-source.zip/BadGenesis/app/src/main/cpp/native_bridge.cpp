#include "native_backend.h"
#include <jni.h>
#include <android/native_window_jni.h>
#include <map>
#include <memory>
#include <mutex>

namespace {
std::mutex handlesMutex;
std::map<jlong, std::shared_ptr<badgenesis::NativeBackend>> handles;
jlong nextHandle = 1;
std::shared_ptr<badgenesis::NativeBackend> backend(jlong handle) {
    std::lock_guard<std::mutex> guard(handlesMutex); auto found = handles.find(handle);
    if (found == handles.end()) throw std::runtime_error("BadGenesis native engine is not running");
    return found->second;
}
std::string string(JNIEnv* env, jstring value) {
    if (!value) return {};
    const char* text = env->GetStringUTFChars(value, nullptr); if (!text) throw std::runtime_error("Cannot read Android text");
    std::string result(text); env->ReleaseStringUTFChars(value, text); return result;
}
std::vector<uint8_t> bytes(JNIEnv* env, jbyteArray value) {
    if (!value) return {}; auto count = env->GetArrayLength(value);
    if (count > 64 * 1024 * 1024) throw std::runtime_error("The file is too large");
    std::vector<uint8_t> result(count); env->GetByteArrayRegion(value, 0, count, reinterpret_cast<jbyte*>(result.data())); return result;
}
jbyteArray byteArray(JNIEnv* env, const std::vector<uint8_t>& bytes) {
    auto output = env->NewByteArray(bytes.size());
    if (output && !bytes.empty()) env->SetByteArrayRegion(output, 0, bytes.size(), reinterpret_cast<const jbyte*>(bytes.data())); return output;
}
void exception(JNIEnv* env, const char* message) { auto type = env->FindClass("java/lang/IllegalStateException"); if (type) env->ThrowNew(type, message); }
}

extern "C" JNIEXPORT jlong JNICALL Java_com_badgenesis_app_NativeBridge_create(JNIEnv* env, jclass, jstring directory) {
    try { auto engine = std::make_shared<badgenesis::NativeBackend>(string(env, directory)); std::lock_guard<std::mutex> guard(handlesMutex); jlong handle = nextHandle++; handles.emplace(handle, std::move(engine)); return handle; }
    catch (const std::exception& error) { exception(env, error.what()); return 0; }
}
extern "C" JNIEXPORT void JNICALL Java_com_badgenesis_app_NativeBridge_destroy(JNIEnv*, jclass, jlong handle) {
    std::shared_ptr<badgenesis::NativeBackend> engine;
    { std::lock_guard<std::mutex> guard(handlesMutex); auto found = handles.find(handle); if (found == handles.end()) return; engine = std::move(found->second); handles.erase(found); }
}
extern "C" JNIEXPORT jstring JNICALL Java_com_badgenesis_app_NativeBridge_loadRom(JNIEnv* env, jclass, jlong handle, jbyteArray data, jstring name) {
    try { auto error = backend(handle)->loadRom(bytes(env, data), string(env, name)); return env->NewStringUTF(error.c_str()); }
    catch (const std::exception& error) { return env->NewStringUTF(error.what()); }
}
extern "C" JNIEXPORT void JNICALL Java_com_badgenesis_app_NativeBridge_attachSurface(JNIEnv* env, jclass, jlong handle, jobject surface) {
    try { auto engine = backend(handle); ANativeWindow* window = surface ? ANativeWindow_fromSurface(env, surface) : nullptr; engine->attachSurface(window); }
    catch (const std::exception& error) { exception(env, error.what()); }
}
extern "C" JNIEXPORT void JNICALL Java_com_badgenesis_app_NativeBridge_setButtons(JNIEnv* env, jclass, jlong handle, jint buttons) {
    try { backend(handle)->setButtons(static_cast<uint16_t>(buttons)); } catch (const std::exception& error) { exception(env, error.what()); }
}
extern "C" JNIEXPORT jstring JNICALL Java_com_badgenesis_app_NativeBridge_command(JNIEnv* env, jclass, jlong handle, jstring action, jstring json) {
    try { auto result = backend(handle)->command(string(env, action), string(env, json)); return env->NewStringUTF(result.c_str()); }
    catch (const std::exception& error) { exception(env, error.what()); return nullptr; }
}
extern "C" JNIEXPORT jstring JNICALL Java_com_badgenesis_app_NativeBridge_status(JNIEnv* env, jclass, jlong handle) {
    try { auto result = backend(handle)->status(); return env->NewStringUTF(result.c_str()); } catch (const std::exception& error) { exception(env, error.what()); return nullptr; }
}
extern "C" JNIEXPORT jstring JNICALL Java_com_badgenesis_app_NativeBridge_domains(JNIEnv* env, jclass, jlong handle) {
    try { auto result = backend(handle)->domains(); return env->NewStringUTF(result.c_str()); } catch (const std::exception& error) { exception(env, error.what()); return nullptr; }
}
extern "C" JNIEXPORT jbyteArray JNICALL Java_com_badgenesis_app_NativeBridge_exportState(JNIEnv* env, jclass, jlong handle) {
    try { return byteArray(env, backend(handle)->exportState()); } catch (const std::exception& error) { exception(env, error.what()); return nullptr; }
}
extern "C" JNIEXPORT jstring JNICALL Java_com_badgenesis_app_NativeBridge_importState(JNIEnv* env, jclass, jlong handle, jbyteArray data) {
    try { auto error = backend(handle)->importState(bytes(env, data)); return env->NewStringUTF(error.c_str()); } catch (const std::exception& error) { return env->NewStringUTF(error.what()); }
}
extern "C" JNIEXPORT jbyteArray JNICALL Java_com_badgenesis_app_NativeBridge_readMemory(JNIEnv* env, jclass, jlong handle, jstring domain, jint start, jint count) {
    try { if (start < 0 || count < 0) return env->NewByteArray(0); return byteArray(env, backend(handle)->readMemory(string(env, domain), start, count)); } catch (const std::exception& error) { exception(env, error.what()); return nullptr; }
}
extern "C" JNIEXPORT jbyteArray JNICALL Java_com_badgenesis_app_NativeBridge_exportData(JNIEnv* env, jclass, jlong handle, jstring kind) {
    try { return byteArray(env, backend(handle)->exportData(string(env, kind))); } catch (const std::exception& error) { exception(env, error.what()); return nullptr; }
}
extern "C" JNIEXPORT jstring JNICALL Java_com_badgenesis_app_NativeBridge_importData(JNIEnv* env, jclass, jlong handle, jstring kind, jbyteArray data) {
    try { auto error = backend(handle)->importData(string(env, kind), bytes(env, data)); return env->NewStringUTF(error.c_str()); } catch (const std::exception& error) { return env->NewStringUTF(error.what()); }
}

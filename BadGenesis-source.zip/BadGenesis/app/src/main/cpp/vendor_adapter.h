#ifndef BADGENESIS_VENDOR_ADAPTER_H
#define BADGENESIS_VENDOR_ADAPTER_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Supplement Genesis Plus GX's full CPU/VDP/chip state with audio resampler
 * tails. Each rewind/save snapshot owns its own bytes; no global last snapshot
 * is used. Call only on the emulator thread at an emulated frame boundary. */
size_t bg_sound_size(void);
int bg_sound_save(uint8_t *output, size_t size);
int bg_sound_load(const uint8_t *input, size_t size);

/* Built into a generated copy of the pinned gamepad.c so its private TH
 * handshake and timeout state can be restored by native save/rewind. */
size_t bg_gamepad_size(void);
int bg_gamepad_save(uint8_t *output, size_t size);
int bg_gamepad_load(const uint8_t *input, size_t size);

#ifdef __cplusplus
}
#endif
#endif

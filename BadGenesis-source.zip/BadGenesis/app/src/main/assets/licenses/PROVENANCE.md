# Genesis Plus GX source provenance

Repository: https://github.com/libretro/Genesis-Plus-GX

Pinned commit: `c2838c7dc4236fc2fe94e5dbd08b41486067918e`

The 244 upstream files listed in UPSTREAM.json are byte-for-byte copies, verified using their Git blob SHA-1 hashes. This includes the actual C emulator, its libretro frontend and supporting source. No JavaScript emulator is used by this native core.

The Wii/GameCube frontends, CHD-only dependencies and translated libretro option tables are omitted because they are outside the Android Genesis cartridge build. HAVE_CHD=0 and HAVE_NO_LANGEXTRA are used. The compiled C/H source and all relevant licenses accompany APK distributions in the BadGenesis source archive.

The original Genesis Plus GX license is in LICENSE.txt. Additional dependency notices are in THIRD_PARTY_NOTICES.txt and individual source headers. The core license prohibits selling redistributions or using them in commercial products or activity and requires complete source for modified redistributions.

BadGenesis additions, including native RTC and JNI/frontend code, live outside this directory. vendor_adapter.c supplements native save states with the core's existing sound buffer API and preserves per-snapshot audio resampler state.

# BadGenesis validation

The diagnostic fixture is a newly generated public-domain ROM containing actual Motorola 68000 code, a Z80 sound driver, VDP tile writes, YM2612 FM register programming and SN76489 PSG programming. It contains no commercial game data. Generate it with `node generate-diagnostic.cjs`.

`npm test` executes the retained project scripts, not an imitation emulator. The DOM adapter permits deterministic cloud checks without a graphical session; it does not claim to be a browser or an Android device. The checks include:

- The user's original M68000 source and VDP raster source, allowing only English error text and the real PSG register-write hook, plus eight complete diagnostic frame comparisons against the original emulator.
- All seven RTC domains, all eleven mutation modes, fresh normal/Auto Blast randomness, advanced seeds, exclusions, ranges, undo, pristine ROM preservation, persistent slots, recovery, harvester and rewind across blasts.
- Independent multitouch, diagonals, held buttons, merged keyboard/browser/native gamepad inputs, three/six-button protocol, control settings and vibration bridge calls.
- The original Z80 instruction paths and the independently sourced reference vectors documented in [Z80-PROVENANCE.md](Z80-PROVENANCE.md).
- Real FM/PSG signals independently, PSG divider frequency, Z80 sound-driver execution, native stereo PCM format, absence of artificial sound when the chips are silent, exact future PCM after state restore, flushing and sound after safe blasts, recovery, quick load and rewind.

`npm run test:browser` opens the shipped HTML and its actual script tags in installed Chromium. It exercises the ROM picker, menus, real browser touch events, landscape/portrait control bounds, RTC and captured Android audio bridge traffic, and saves screenshots plus a report under `../test-results`. The cloud execution policy must permit Chromium's process and socket setup.

These tests do not establish commercial-game compatibility or validate speakers, physical Bluetooth/USB controllers, Android document-provider behavior or Android AudioTrack playback on a handset. Browser audio bridge captures check the PCM that would be submitted to AudioTrack. Native build and APK checks are separate. Arbitrary corruption can deliberately silence a sound driver or stop a game; rewind/recovery restore its complete previous state.

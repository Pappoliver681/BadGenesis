/**
 * Original public-domain Genesis diagnostic ROM, generated without game assets.
 * This fixture executes real M68000 instructions, uploads/starts a Z80 driver,
 * renders a sharp checkerboard with the VDP, and programs YM2612 + SN76489.
 * The Z80 writes a signature/counter to RAM. The 68000 records pad reads in RAM.
 */
const fs = require('node:fs');
const path = require('node:path');

function makeDiagnosticROM() {
  const rom = Buffer.alloc(0x10000);
  const w16 = (at, n) => rom.writeUInt16BE(n & 0xffff, at);
  const w32 = (at, n) => rom.writeUInt32BE(n >>> 0, at);
  w32(0, 0x00ffff00);
  w32(4, 0x200);
  for (let i = 8; i < 0x100; i += 4) w32(i, 0x200);
  rom.write('SEGA GENESIS    ', 0x100, 'ascii');
  rom.write('(C)PUBLIC DOMAIN 2026', 0x110, 'ascii');
  rom.write('BADGENESIS OPEN DIAGNOSTIC', 0x120, 'ascii');
  rom.write('BADGENESIS OPEN DIAGNOSTIC', 0x150, 'ascii');
  rom.write('GM 00000000-00', 0x180, 'ascii');
  rom.write('J6', 0x190, 'ascii');
  w32(0x1a0, 0); w32(0x1a4, rom.length - 1);
  w32(0x1a8, 0xff0000); w32(0x1ac, 0xffffff);
  // Both byte lanes, battery-backed SRAM outside the ROM address range.
  rom.write('RA', 0x1b0, 'ascii'); rom[0x1b2] = 0x40;
  w32(0x1b4, 0x200000); w32(0x1b8, 0x200fff);
  rom.write('U', 0x1f0, 'ascii');

  const z = [0xf3, 0x31, 0xff, 0x1f]; // DI; LD SP,$1fff
  const zb = (address, value) => z.push(0x3e, value & 255, 0x32, address & 255, address >> 8);
  const ym = (reg, value) => {
    zb(0x4000, reg); z.push(0, 0, 0, 0);
    zb(0x4001, value); z.push(0, 0, 0, 0);
  };
  // Tone 0, divider $105, volume 4; other channels silent after chip reset.
  zb(0x7f11, 0x85); zb(0x7f11, 0x10); zb(0x7f11, 0x94);
  ym(0x22, 0); ym(0x27, 0); ym(0x2b, 0);
  for (const offset of [0, 4, 8, 12]) {
    ym(0x30 + offset, 0x01); // Detune 0, multiplier 1.
    ym(0x40 + offset, 0x18); // Total level 24.
    ym(0x50 + offset, 0x1f); // Fast attack.
    ym(0x60 + offset, 0x08); // Decay.
    ym(0x70 + offset, 0x04); // Sustain decay.
    ym(0x80 + offset, 0x4f); // Sustain level + release.
  }
  ym(0xb0, 7); ym(0xb4, 0xc0); // Algorithm 7, left and right enabled.
  ym(0xa4, 0x22); ym(0xa0, 0x69); ym(0x28, 0xf0); // All 4 operators key-on.
  zb(0x1ff0, 0x42);
  const zloop = z.length;
  z.push(0x3a, 0xf1, 0x1f, 0x3c, 0x32, 0xf1, 0x1f, 0xc3, zloop & 255, zloop >> 8);

  let p = 0x200;
  const word = n => { w16(p, n); p += 2; };
  const long = n => { w32(p, n); p += 4; };
  const moveB = (v, a) => { word(0x13fc); word(v); long(a); };
  const moveW = (v, a) => { word(0x33fc); word(v); long(a); };
  const control = v => moveW(v, 0xc00004);
  moveW(0x0100, 0xa11100); // Request Z80 bus.
  moveW(0x0000, 0xa11200); // Hold Z80 reset.
  z.forEach((v, i) => moveB(v, 0xa00000 + i));
  moveW(0x0100, 0xa11200); // Release reset.
  moveW(0x0000, 0xa11100); // Release bus request; driver executes.
  moveB(0x40, 0xa10009); // TH output enabled.
  moveB(0x40, 0xa10003); // TH high for up/down/left/right/B/C.
  for (const v of [0x8104, 0x8230, 0x8407, 0x857c, 0x8700, 0x8c81, 0x8f02, 0x8d3e]) control(v);
  control(0xc000); control(0); // CRAM write from address 0.
  for (const v of [0, 0x000e, 0x00e0, 0x0e00]) moveW(v, 0xc00000);
  control(0x4020); control(0); // VRAM tile 1 at byte offset 32.
  for (let row = 0; row < 8; row++) {
    word(0x23fc); long(row & 1 ? 0x22332233 : 0x11221122); long(0xc00000);
  }
  control(0x4000); control(3); // VRAM $c000 plane A name table.
  word(0x323c); word(1023); // MOVE.W #1023,D1.
  const tileLoop = p;
  moveW(1, 0xc00000);
  word(0x51c9); const dbraBase = p; word(tileLoop - dbraBase);
  control(0x8144); // Display enabled.
  const loop = p;
  word(0x1039); long(0xa10003); // MOVE.B pad,D0.
  word(0x13c0); long(0xff0000); // MOVE.B D0,work RAM.
  word(0x5279); long(0xff0002); // ADDQ.W #1,work RAM counter.
  word(0x6000); const braBase = p; word(loop - braBase);
  let checksum = 0;
  for (let i = 0x200; i + 1 < rom.length; i += 2) checksum = (checksum + rom.readUInt16BE(i)) & 65535;
  w16(0x18e, checksum);
  return { rom, z80Bytes: z.length, codeEnd: p, loop };
}

if (require.main === module) {
  const { rom, ...metadata } = makeDiagnosticROM();
  const output = path.join(__dirname, 'diagnostic.bin');
  fs.writeFileSync(output, rom);
  fs.writeFileSync(path.join(__dirname, 'diagnostic.json'), JSON.stringify(metadata, null, 2) + '\n');
  console.log(JSON.stringify({ output, ...metadata }));
}
module.exports = { makeDiagnosticROM };

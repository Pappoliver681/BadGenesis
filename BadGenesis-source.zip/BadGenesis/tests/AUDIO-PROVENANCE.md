# BadGenesis audio

The original BadGenesis 68000 CPU, VDP, ROM loader and gameplay implementation
remain the emulator base. The original HTML contained YM2612 register storage
and a last-PSG-write byte, with no synthesis and no executing Z80 sound CPU.

`app/src/main/assets/ym2612.js` adds the actual six-channel, four-operator FM
synthesizer from Alex Rosario's `apollolux/ym2612-js`, upstream commit
`e3e1d69aec8daac7958e5235e2642dcfdfa67714`. The upstream README declares MIT
and identifies its Genesis Plus GX C-core ancestry. The declaration, standard
MIT text and upstream credit are included in `assets/licenses/YM2612-MIT.txt`.
BadGenesis adds full serialization/restoration of operator phases, envelopes,
feedback, algorithms, panning, LFO, timers, DAC and 3-slot/CSM state; restores
constructor methods; fixes initialization, LFO timing, 3-slot key codes and
per-instance DAC masking.

`z80.js` provenance and MIT copyright are recorded in `Z80-PROVENANCE.md`
and `assets/licenses/Z80-MIT.txt`. The CPU executes the ROM's real Z80 driver
against the same Z80 RAM that RTC mutates. The 9-bit serial bank register maps
the Z80's upper 32 KiB to the retained 68000 bus, including ROM/DAC driver reads.
The 68000's high-byte BUSREQ/RESET registers, YM's two address/data banks, busy
status, timer status, VBlank interrupt pulse and PSG ports are connected.

`audio.js` implements the Sega SN76489 PSG's three programmable tone dividers,
four logarithmic attenuation controls and 16-bit periodic/white-noise LFSR.
It clocks Z80 at master/15, YM2612 at master/7 with native sample periods of
144 clocks, and PSG at master/15 with its internal divide-by-16. Native chip
output is resampled to 44,100 Hz, mixed and clamped to signed stereo PCM16.
Android PCM crosses `AndroidAudio.writePCM` to the existing native AudioTrack
worker. Ordinary browsers use Web Audio buffers. Muting affects delivery while
the actual emulated chips keep running.

All chip state, bank state, interrupt timing and clock/resampler accumulators
are part of `machine.state().audio`, separate from the user's mute preference.
Loading states and rewinding flush previously queued device/browser sound.
No recorded songs, oscillators unrelated to emulated chip registers, or fake
sound placeholders are used.

The original public-domain `diagnostic.bin` fixture uploads a genuine Z80
driver, plays FM and PSG, writes a Z80 RAM signature and renders VDP tiles.
Headless execution confirmed nonzero chip-generated PCM and bit-exact next
frame PCM after a full machine save/load. Real Android speaker performance
must also be checked on the installed APK.

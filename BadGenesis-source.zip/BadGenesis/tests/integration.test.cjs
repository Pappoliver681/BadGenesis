'use strict';
const assert = require('node:assert/strict');
const test = require('node:test');
const fs = require('node:fs');
const path = require('node:path');
const { loadProject } = require('./dom-harness.cjs');
const { makeDiagnosticROM } = require('./generate-diagnostic.cjs');

function project(options = {}) {
  const p = loadProject({ stripRetiredVideoHook: true, ...options });
  p.context.testROM = new Uint8Array(makeDiagnosticROM().rom);
  p.run("machine.loadROM(testROM, 'diagnostic.bin'); machine.power(true)");
  p.json = code => JSON.parse(p.run(`JSON.stringify(${code})`));
  p.set = (id, value) => { p.document.getElementById(id).value = String(value); };
  p.domains = (...keys) => p.elements.filter(e => e.dataset.rtcDomain).forEach(e => { e.checked = keys.includes(e.dataset.rtcDomain); });
  return p;
}

// The sole allowed VDP source addition routes real PSG register writes. Raster
// methods and all M68000 instructions must remain the user's original code.
const canonicalCore = source => source.replaceAll('EA address invalido', 'Invalid EA address').replaceAll('EA control invalido', 'Invalid EA control').replaceAll('non implementato', 'not implemented').replace('case 0x10:case 0x14:this.m.bus.psgLast=v&255;if(this.m.audio)this.m.audio.psg.write(v&255);break', 'case 0x10:this.m.bus.psgLast=v&255;break');
const executionSnapshot = `({cpu:{D:[...machine.cpu.D],A:[...machine.cpu.A],PC:machine.cpu.PC,SR:machine.cpu.SR,total:machine.cpu.total,pendingIRQ:machine.cpu.pendingIRQ},ram:[...machine.bus.ram],vram:[...machine.vdp.vram],cram:[...machine.vdp.cram],vsram:[...machine.vdp.vsram],reg:[...machine.vdp.reg],pixels:[...machine.vdp.pixels],frames:machine.frames})`;

test('preserved original M68000 / VDP source and diagnostic execution match', () => {
  const original = project({ baseline: true }), current = project({ mobile: false });
  for (const name of ['M68K', 'VDP']) assert.equal(canonicalCore(current.run(`${name}.toString()`)), canonicalCore(original.run(`${name}.toString()`)), `${name} execution source changed`);
  for (let frame = 0; frame < 8; frame++) {
    original.run('machine.runFrame()'); current.run('machine.runFrame()');
    assert.deepEqual(current.json(executionSnapshot), original.json(executionSnapshot), `frame ${frame}`);
  }
  const colors = current.json('[...new Set(Array.from({length: machine.vdp.pixels.length / 4}, (_,i) => [...machine.vdp.pixels.slice(i*4,i*4+4)].join(",")))]');
  assert.ok(colors.length > 1, 'diagnostic must actually render visible colored tiles');
  assert.equal(current.run('machine.running'), true);
});

test('normal blasts default to fresh seeds and independent address/value patterns', () => {
  const p = project(); p.set('rtcMode', 'random'); p.set('rtcIntensity', 32); p.set('rtcStart', '8000'); p.set('rtcEnd', 'BFFF');
  assert.equal(p.run('rtcValue("rtcSeedMode")'), 'random');
  assert.equal(p.document.getElementById('rtcSeed').disabled, true);
  const patterns = [];
  for (let i = 0; i < 32; i++) { p.run('rtcBlast();'); patterns.push(p.json('RTC.undo.undo.map(c => [c.index, machine.bus.ram[c.index]])')); }
  const history = p.json('RTC.history');
  assert.equal(history.length, 32); assert.equal(new Set(history.map(h => h.seed)).size, 32);
  assert.ok(history.every(h => h.random && h.seedText === null && h.operations === 32));
  assert.equal(new Set(patterns.map(x => JSON.stringify(x))).size, 32);
  assert.ok(new Set(patterns.flat().map(x => x[1])).size > 100, 'random mutation values must vary');
});

test('Auto Blast uses emulated frame counts, no paused blasts, and fresh random seeds', () => {
  const p = project(); p.domains('ram'); p.set('rtcMode', 'random'); p.set('rtcStart', '8000'); p.set('rtcEnd', 'BFFF'); p.set('rtcAutoFrames', 2); p.set('rtcIntensity', 8);
  p.run('RTC.auto=true; for(let i=0;i<8;i++)machine.runFrame()');
  assert.deepEqual(p.json('RTC.history.map(h=>h.frame)'), [2,4,6,8]);
  assert.equal(new Set(p.json('RTC.history.map(h=>h.seed)')).size, 4);
  p.run('machine.paused=true;for(let i=0;i<20;i++)machine.runFrame()');
  assert.equal(p.run('RTC.frame'), 8); assert.equal(p.run('RTC.blast'), 4);
});

test('all seven domains mutate only legal ranges/exclusions and undo precisely', () => {
  const p = project();
  assert.deepEqual(p.json('Object.keys(rtcDomains())'), ['ram','zram','vram','cram','vsram','sram','rom']);
  p.set('rtcIntensity', 100); p.set('rtcMode', 'random'); p.set('rtcStart', '2'); p.set('rtcEnd', '3F'); p.set('rtcExclusions', '10-1F,22,34-35');
  for (const key of ['ram','zram','vram','cram','vsram','sram','rom']) {
    p.domains(key);
    const before = p.json(`Array.from({length:rtcDomains().${key}.size},(_,i)=>rtcDomains().${key}.get(i))`);
    p.run('rtcBlast()');
    const changes = p.json('RTC.undo.undo');
    assert.ok(changes.length > 0, key);
    assert.ok(changes.every(c => c.domain === key && c.index >= 2 && c.index <= 63 && !(c.index >= 16 && c.index <= 31) && c.index !== 34 && c.index !== 52 && c.index !== 53), key);
    p.run('rtcUndo()');
    assert.deepEqual(p.json(`Array.from({length:rtcDomains().${key}.size},(_,i)=>rtcDomains().${key}.get(i))`), before, key);
  }
  assert.deepEqual(p.json('[...testROM]'), [...makeDiagnosticROM().rom], 'input ROM must never be overwritten');
  assert.deepEqual(p.json('[...RTC.originalRom]'), [...makeDiagnosticROM().rom], 'pristine source ROM must remain pristine');
});

test('byte mutation modes and big endian 16/32-bit/NOP mutations are real memory writes', () => {
  const p = project();
  const mutate = (mode, old, values, picks = [0]) => {
    p.context.mutationData = new Uint8Array(old); p.context.randomValues = values; p.context.picks = picks;
    return p.json(`(()=>{const d=rtcByteDomain('ram','RAM',mutationData),undo=new Map();let r=0,q=0;rtcApplyMutation(d,()=>randomValues[r++]??0,${JSON.stringify(mode)},undo,()=>picks[q++]??0);return {bytes:[...mutationData],undo:[...undo.values()]}})()`);
  };
  assert.deepEqual(mutate('bitflip',[0x80],[7]).bytes,[0]);
  assert.deepEqual(mutate('random',[0],[0x1234]).bytes,[0x34]);
  assert.deepEqual(mutate('add',[0xff],[0]).bytes,[0]);
  assert.deepEqual(mutate('sub',[0],[0]).bytes,[0xff]);
  assert.deepEqual(mutate('tilt',[100],[3,1]).bytes,[104]);
  assert.deepEqual(mutate('tilt',[100],[2,0]).bytes,[97]);
  assert.deepEqual(mutate('zero',[0xff],[]).bytes,[0]);
  assert.deepEqual(mutate('ff',[0],[]).bytes,[0xff]);
  assert.deepEqual(mutate('swap',[0x12,0x34],[],[0,1]).bytes,[0x34,0x12]);
  assert.deepEqual(mutate('word16',[0,0],[0x1234]).bytes,[0x12,0x34]);
  assert.deepEqual(mutate('word32',[0,0,0,0],[0x89abcdef]).bytes,[0x89,0xab,0xcd,0xef]);
  assert.deepEqual(mutate('nop',[0,0],[]).bytes,[0x4e,0x71]);
  assert.deepEqual(p.json("(()=>{const d=rtcByteDomain('ram','RAM',new Uint8Array(64)),rand=rtcRng(1),pick=rtcLegalPicker(d,rand,4,1,62,[[8,11],[20,21]]);return Array.from({length:200},pick)})()" ).filter(i => i % 4 || i < 1 || i + 3 > 62 || (i <= 11 && i + 3 >= 8) || (i <= 21 && i + 3 >= 20)), []);
});

test('advanced NOP is restricted to aligned executable 68000 domains', () => {
  const p = project(); p.domains('zram','cram'); p.set('rtcMode','nop'); p.run('rtcBlast()'); assert.equal(p.run('RTC.blast'),0);
  assert.match(p.document.getElementById('rtcStatus').textContent,/68000 Work RAM/);
  p.domains('ram','rom','zram'); p.set('rtcStart','2000'); p.set('rtcEnd','202F'); p.set('rtcIntensity',6); p.run('rtcBlast()');
  const changes=p.json('RTC.undo.undo'); assert.ok(changes.length); assert.ok(changes.every(c=>['ram','rom'].includes(c.domain)));
  for(const c of changes.filter(c=>c.index%2===0)) assert.deepEqual(p.json(`[rtcDomains().${c.domain}.get(${c.index}),rtcDomains().${c.domain}.get(${c.index+1})]`),[0x4e,0x71]);
});

test('optional manual seed reproduces a blast and domain overrides stay independent', () => {
  const p = project(); p.set('rtcSeedMode','manual'); p.set('rtcSeed','0x12345678'); p.set('rtcMode','random'); p.set('rtcIntensity',24); p.set('rtcStart','8000'); p.set('rtcEnd','BFFF');
  p.run('rtcBlast()'); const first=p.json('RTC.undo.undo.map(c=>[c.index,machine.bus.ram[c.index]])'); p.run('rtcUndo();rtcBlast()');
  assert.deepEqual(p.json('RTC.undo.undo.map(c=>[c.index,machine.bus.ram[c.index]])'),first);
  p.set('rtcDomainRanges','ram: 0100-013F !0110-011F\nzram: 0030-003F !0038'); p.domains('ram','zram');p.run('rtcBlast()');
  assert.ok(p.json('RTC.undo.undo').every(c=>c.domain==='ram'?(c.index>=0x100&&c.index<=0x13f&&!(c.index>=0x110&&c.index<=0x11f)):(c.index>=0x30&&c.index<=0x3f&&c.index!==0x38)));
});

test('full save/load restores ROM patches, memory, IRQ/DMA/raster latch, controller and framebuffer', () => {
  const p=project(); p.run('for(let i=0;i<3;i++)machine.runFrame();rtcRomWrite(machine,0x7000,0xab);machine.cpu.pendingIRQ=4;machine.vdp.latch=0x1234;machine.vdp.dmaFillPending=true;machine.vdp.dmaFillLen=5;machine.pad.set("a",true);machine.bus.z80BusReq=0;machine.bus.ym[47]=0x88;machine.bus.ymAddr[1]=47;globalThis.saved=machine.state()');
  const expected=p.json(executionSnapshot);
  p.run('rtcRomWrite(machine,0x7000,0xcd);machine.bus.ram.fill(0);machine.vdp.vram.fill(0);machine.vdp.pixels.fill(0);machine.cpu.pendingIRQ=0;machine.vdp.latch=null;machine.vdp.dmaFillPending=false;machine.bus.ym.fill(0);machine.pad.releaseAll();machine.loadState(saved)');
  assert.deepEqual(p.json(executionSnapshot),expected);
  assert.deepEqual(p.json('({rom:machine.rom[0x7000],latch:machine.vdp.latch,dma:machine.vdp.dmaFillPending,len:machine.vdp.dmaFillLen,a:machine.pad.keys.a,bus:machine.bus.z80BusReq,ym:machine.bus.ym[47],address:machine.bus.ymAddr[1]})'),{rom:0xab,latch:0x1234,dma:true,len:5,a:true,bus:0,ym:0x88,address:47});
  assert.equal(p.run('machine.paused'),true);
  p.run('saved.rtcState.romIdentity="wrong"'); assert.throws(()=>p.run('machine.loadState(saved)'),/different original ROM/);
});

test('quick states, persistent slots and recovery remain separate from rewind', () => {
  const p=project(); p.run('machine.bus.ram[0x8000]=11;rtcCapture()'); p.document.getElementById('rtcQuickSave').click();
  p.run('machine.bus.ram[0x8000]=22'); p.set('rtcSlot',1); p.run('rtcSaveSlot()');
  p.run('machine.bus.ram[0x8000]=33'); p.set('rtcSlot',2); p.run('rtcSaveSlot()');
  p.document.getElementById('rtcQuickLoad').click(); assert.equal(p.run('machine.bus.ram[0x8000]'),11);
  p.set('rtcSlot',1);p.run('rtcLoadSlot()');assert.equal(p.run('machine.bus.ram[0x8000]'),22);
  p.set('rtcSlot',2);p.run('rtcLoadSlot()');assert.equal(p.run('machine.bus.ram[0x8000]'),33);
  p.set('rtcStart','8000');p.set('rtcEnd','8000');p.set('rtcMode','ff');p.run('rtcBlast();RTC.recovery=null;rtcRecover()');assert.equal(p.run('machine.bus.ram[0x8000]'),33);
  assert.equal(p.run('RTC.quick.state.bus.ram[0x8000]'),11);
  assert.equal(p.run('RTC.rewind.length'),0);
  assert.ok([...p.local.keys()].filter(k=>k.includes('slot:')).length===2);
});

test('hold-to-rewind continuously restores states across RTC blasts and resumes on release', () => {
  const p=project(); p.set('rtcStart','8000');p.set('rtcEnd','8000');p.set('rtcMode','ff');
  p.run('machine.bus.ram[0x8000]=10;RTC.frame=10;rtcCapture();rtcBlast();RTC.frame=20;rtcCapture();machine.bus.ram[0x8000]=77;RTC.frame=30;rtcCapture()');
  const rewind=p.document.getElementById('mobileRewind');rewind.dispatchEvent({type:'pointerdown',pointerId:201});
  assert.equal(p.run('RTC.rewinding'),true); assert.equal(p.run('RTC.frame'),30);
  const timer=p.intervals.get(p.run('RTC.rewTimer'));assert.equal(typeof timer,'function');timer();assert.equal(p.run('machine.bus.ram[0x8000]'),255);assert.equal(p.run('RTC.frame'),20);timer();
  assert.equal(p.run('machine.bus.ram[0x8000]'),10);assert.equal(p.run('RTC.frame'),10);assert.equal(p.run('RTC.history[0].active'),false);
  rewind.dispatchEvent({type:'pointerup',pointerId:201});assert.equal(p.run('RTC.rewinding'),false);assert.equal(p.run('machine.paused'),false);assert.equal(p.run('RTC.rewindBytes'),0);
  p.document.getElementById('rtcQuickSave').click();p.run('machine.runFrame()');assert.equal(p.run('RTC.quick.frame'),10);
});

test('harvester clean -> next -> run -> keep/discard restores full candidate states', () => {
  const p=project();p.set('rtcStart','8000');p.set('rtcEnd','801F');p.set('rtcMode','random');p.set('rtcIntensity',12);
  p.run('machine.bus.ram[0x8000]=21;rtcSetClean();rtcNext();machine.runFrame();rtcKeep()');const kept=p.json(executionSnapshot);const seed=p.run('RTC.kept[0].seed');
  p.run('rtcDiscard()');assert.equal(p.run('machine.bus.ram[0x8000]'),21);assert.equal(p.run('RTC.frame'),0);
  p.run('rtcNext()');assert.notEqual(p.run('RTC.undo.seed'),seed);p.run('rtcLoadKept()');assert.deepEqual(p.json(executionSnapshot),kept);assert.equal(p.run('machine.paused'),false);
});

test('touch fingers, diagonals, held actions, keyboard and native pad sources merge correctly', () => {
  const p=project({native:true});const dpad=p.document.getElementById('mobileDpad');const a=p.elements.find(e=>e.dataset.key==='a'&&e.closest('#mobileFace'));const b=p.elements.find(e=>e.dataset.key==='b'&&e.closest('#mobileFace'));
  dpad.dispatchEvent({type:'pointerdown',pointerId:1,clientX:175,clientY:5});a.dispatchEvent({type:'pointerdown',pointerId:2});b.dispatchEvent({type:'pointerdown',pointerId:3});a.dispatchEvent({type:'pointerdown',pointerId:4});
  assert.deepEqual(p.json('[machine.pad.keys.up,machine.pad.keys.right,machine.pad.keys.a,machine.pad.keys.b]'),[true,true,true,true]);
  a.dispatchEvent({type:'pointerup',pointerId:2});assert.equal(p.run('machine.pad.keys.a'),true);a.dispatchEvent({type:'pointercancel',pointerId:4});assert.equal(p.run('machine.pad.keys.a'),false);
  p.context.BadGenesisNativePad('b',true);b.dispatchEvent({type:'pointerup',pointerId:3});assert.equal(p.run('machine.pad.keys.b'),true);p.context.BadGenesisNativePad('b',false);assert.equal(p.run('machine.pad.keys.b'),false);
  dpad.dispatchEvent({type:'pointermove',pointerId:1,clientX:5,clientY:155});assert.deepEqual(p.json('[machine.pad.keys.up,machine.pad.keys.right,machine.pad.keys.down,machine.pad.keys.left]'),[false,false,true,true]);
  p.context.dispatchEvent({type:'keydown',code:'KeyZ',target:dpad});p.context.dispatchEvent({type:'keydown',code:'KeyJ',target:dpad});p.context.dispatchEvent({type:'keyup',code:'KeyZ',target:dpad});assert.equal(p.run('machine.pad.keys.a'),true);p.context.dispatchEvent({type:'keyup',code:'KeyJ',target:dpad});assert.equal(p.run('machine.pad.keys.a'),false);
  p.context.BadGenesisNativePad('x',true);p.context.BadGenesisNativePad('y',true);p.context.BadGenesisNativePad('z',true);p.context.BadGenesisNativePad('mode',true);assert.deepEqual(p.json('[machine.pad.keys.x,machine.pad.keys.y,machine.pad.keys.z,machine.pad.keys.mode]'),[true,true,true,true]);
  p.context.BadGenesisLifecycle(true);assert.ok(p.json('Object.values(machine.pad.keys)').every(v=>!v));assert.equal(p.run('machine.paused'),true);p.context.BadGenesisLifecycle(false);assert.equal(p.run('machine.paused'),false);
});

test('browser gamepad supports diagonal plus all six buttons/start/mode', () => {
  const p=project();p.context.navigator.getGamepads=()=>[{id:'Synthetic standard gamepad',axes:[-1,1],buttons:Array.from({length:16},(_,i)=>({pressed:[0,1,2,3,4,5,8,9].includes(i)}))}];p.run('pollGamepad()');
  assert.deepEqual(p.json('[machine.pad.keys.left,machine.pad.keys.down,machine.pad.keys.a,machine.pad.keys.b,machine.pad.keys.c,machine.pad.keys.x,machine.pad.keys.y,machine.pad.keys.z,machine.pad.keys.start,machine.pad.keys.mode]'),Array(10).fill(true));
  p.context.navigator.getGamepads=()=>[];p.run('pollGamepad()');assert.ok(p.json('Object.values(machine.pad.keys)').every(v=>!v));
});

test('phone control preferences persist size, opacity, mode, positions and visibility', () => {
  const p=project({native:true});p.set('controlSize',135);p.document.getElementById('controlSize').dispatchEvent({type:'input'});p.set('controlOpacity',40);p.document.getElementById('controlOpacity').dispatchEvent({type:'input'});
  p.set('controlButtons',3);p.document.getElementById('controlButtons').dispatchEvent({type:'input'});p.set('controlX',34);p.document.getElementById('controlX').dispatchEvent({type:'input'});p.document.getElementById('controlVisibility').click();
  const prefs=JSON.parse(p.local.get('badgenesis:controls:v1'));assert.equal(prefs.size,135);assert.equal(prefs.opacity,40);assert.equal(prefs.buttons,'3');assert.equal(prefs.positions.landscape.dpad.x,34);assert.equal(prefs.visible,false);
  assert.equal(p.document.documentElement.style['--control-scale'],'1.35');assert.ok(p.document.body.classList.contains('three-buttons'));assert.ok(p.document.body.classList.contains('controls-hidden'));
});

test('vibration preference calls native integration and three/six button protocols differ correctly', () => {
  const p=project({native:true});const a=p.elements.find(e=>e.dataset.key==='a'&&e.closest('#mobileFace'));
  a.dispatchEvent({type:'pointerdown',pointerId:1});assert.equal(p.nativeCalls.filter(c=>c[0]==='vibrate').length,0);a.dispatchEvent({type:'pointerup',pointerId:1});
  p.set('controlVibration','on');p.document.getElementById('controlVibration').dispatchEvent({type:'change'});a.dispatchEvent({type:'pointerdown',pointerId:2});assert.ok(p.nativeCalls.some(c=>c[0]==='setVibrationEnabled'&&c[1]===true));assert.ok(p.nativeCalls.filter(c=>c[0]==='vibrate').length>=2);assert.equal(JSON.parse(p.local.get('badgenesis:controls:v1')).vibration,true);
  p.set('controlVibration','off');p.document.getElementById('controlVibration').dispatchEvent({type:'change'});assert.equal(JSON.parse(p.local.get('badgenesis:controls:v1')).vibration,false);
  p.set('controlButtons','3');p.document.getElementById('controlButtons').dispatchEvent({type:'input'});p.run('machine.pad.data=0;machine.pad.ctrl=0x40;machine.pad.phase=5;machine.pad.lastToggleCycles=machine.cpu.total');assert.equal(p.run('machine.pad.read() & 15'),3);
  p.set('controlButtons','6');p.document.getElementById('controlButtons').dispatchEvent({type:'input'});p.run('machine.pad.data=0;machine.pad.ctrl=0x40;machine.pad.phase=5;machine.pad.lastToggleCycles=machine.cpu.total');assert.equal(p.run('machine.pad.read() & 15'),0);
});

test('15/30/60/120 second rewind profiles fit measured full states within the RAM budget', () => {
  const p=project();p.set('rtcRewindEvery','2');p.run('rtcCapture()');
  for(const seconds of [15,30,60,120]) {
    p.set('rtcRewindSeconds',seconds);const profile=p.json('rtcRewindProfile()');const snapshot=p.json('rtcSnapshot().bytes');
    assert.equal(profile.seconds,seconds);assert.ok(profile.max*snapshot<=p.run('RTC.rewindLimit'));assert.ok(profile.max*profile.every>=seconds*60-2);
  }
  p.run('RTC.rewindLimit=1200000');p.set('rtcRewindSeconds',120);p.run('for(let i=0;i<10;i++){RTC.frame=i*60;rtcCapture()}');assert.ok(p.run('RTC.rewindBytes<=RTC.rewindLimit'));assert.ok(p.run('RTC.rewind.length>=1'));
});

test('direct imported state loads discard stale future rewind and unrelated Undo history', () => {
  const p=project();p.set('rtcStart','8000');p.set('rtcEnd','8000');p.set('rtcMode','ff');p.run('rtcBlast();globalThis.exportedState=machine.state();RTC.frame=20;rtcCapture();machine.bus.ram[0x8000]=23;RTC.frame=40;rtcCapture()');assert.equal(p.run('RTC.rewind.length'),2);
  p.run('machine.loadState(exportedState)');assert.equal(p.run('RTC.rewind.length'),0);assert.equal(p.run('RTC.undo.n'),1);
  p.run('exportedState.rtcState.historySession="another-session";machine.loadState(exportedState)');assert.equal(p.run('RTC.undo==null'),true);const before=p.run('machine.bus.ram[0x8000]');p.run('rtcUndo()');assert.equal(p.run('machine.bus.ram[0x8000]'),before);
});

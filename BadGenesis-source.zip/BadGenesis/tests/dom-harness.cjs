// Minimal deterministic DOM/canvas adapter for executing the *actual* emulator
// scripts under Node when the cloud sandbox cannot launch a browser process.
// It is not a browser renderer; browser/device checks are reported separately.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const { webcrypto } = require('node:crypto');

function makeDOM(html) {
  const elements = [], byId = new Map(), globalEvents = new Map();
  function eventTarget(e) {
    const listeners = new Map();
    e.addEventListener = (kind, fn, capture = false) => {
      if (!listeners.has(kind)) listeners.set(kind, []);
      listeners.get(kind).push({ fn, capture: !!capture });
    };
    e.dispatchEvent = event => {
      event.target ||= e; event.preventDefault ||= () => {}; event.stopImmediatePropagation ||= () => { event.stopped = true; };
      for (const {fn} of (listeners.get(event.type) || []).filter(x => x.capture)) { fn(event); if (event.stopped) return true; }
      e['on' + event.type]?.(event);
      for (const {fn} of (listeners.get(event.type) || []).filter(x => !x.capture)) { fn(event); if (event.stopped) break; }
      return true;
    };
    return e;
  }
  function create(tag, attrs = {}) {
    const classes = new Set((attrs.class || '').split(/\s+/).filter(Boolean));
    const e = eventTarget({ tagName: tag.toUpperCase(), attrs, id: attrs.id || '', dataset: {},
      style: { setProperty(k, v) { this[k] = String(v); } }, value: attrs.value || '', checked: 'checked' in attrs,
      textContent: '', innerHTML: '', disabled: 'disabled' in attrs, hidden: 'hidden' in attrs, children: [],
      width: +attrs.width || 320, height: +attrs.height || 224, offsetWidth: 180, offsetHeight: 160,
      scrollHeight: 1000, scrollTop: 0, parentElement: null,
      classList: { add(...x) { x.forEach(y => classes.add(y)); }, remove(...x) { x.forEach(y => classes.delete(y)); }, contains(x) { return classes.has(x); }, toggle(x, on) { on ??= !classes.has(x); on ? classes.add(x) : classes.delete(x); return on; } },
      append(...x) { x.forEach(child => { child.parentElement = e; e.children.push(child); }); },
      appendChild(x) { e.append(x); return x; }, replaceChildren(...x) { e.children = []; e.append(...x); },
      insertAdjacentHTML() {}, remove() {}, setPointerCapture() {}, releasePointerCapture() {},
      getBoundingClientRect() { return { left: 0, top: 0, width: e.offsetWidth, height: e.offsetHeight }; },
      matches(selector) { return match(e, selector); },
      closest(selector) { let n = e; while (n) { if (match(n, selector)) return n; n = n.parentElement; } return null; },
      click() { if (!e.disabled) e.dispatchEvent({ type: 'click', target: e }); },
      requestFullscreen() { return Promise.resolve(); },
      getContext() { return canvasContext; }, toBlob(fn) { fn(new Blob([])); }
    });
    Object.defineProperty(e, 'className', { get: () => [...classes].join(' '), set: v => { classes.clear(); String(v).split(/\s+/).filter(Boolean).forEach(x => classes.add(x)); } });
    for (const [k, v] of Object.entries(attrs)) if (k.startsWith('data-')) e.dataset[k.slice(5).replace(/-([a-z])/g, (_, x) => x.toUpperCase())] = v;
    elements.push(e); if (e.id) byId.set(e.id, e); return e;
  }
  const canvasContext = {
    fillStyle: '#000', lastImage: null, imageSmoothingEnabled: false,
    fillRect() {}, createImageData(w, h) { return { width: w, height: h, data: new Uint8ClampedArray(w * h * 4) }; },
    putImageData(image) { this.lastImage = image; }
  };
  function match(e, selector) {
    if (selector.includes(' ')) {
      const parts = selector.split(/\s+/); const last = parts.pop();
      return match(e, last) && !!e.parentElement?.closest(parts.join(' '));
    }
    const id = selector.match(/^#([\w-]+)/); if (id && e.id !== id[1]) return false;
    for (const m of selector.matchAll(/\.([\w-]+)/g)) if (!e.classList.contains(m[1])) return false;
    for (const m of selector.matchAll(/\[([^=\]]+)(?:=["']?([^"'\]]+)["']?)?\]/g)) {
      if (!(m[1] in e.attrs)) return false; if (m[2] !== undefined && e.attrs[m[1]] !== m[2]) return false;
    }
    if (selector.includes(':checked') && !e.checked) return false;
    const tag = selector.match(/^[a-z]+/i); if (tag && e.tagName !== tag[0].toUpperCase()) return false;
    return true;
  }
  const stack = [];
  for (const m of html.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, '').matchAll(/<\/?([a-z][\w-]*)([^>]*)>/gi)) {
    const tag = m[1].toLowerCase();
    if (m[0][1] === '/') { const at = stack.findLastIndex(x => x.tagName === tag.toUpperCase()); if (at >= 0) stack.splice(at); continue; }
    const attrs = {}; for (const a of m[2].matchAll(/([\w-]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+)))?/g)) attrs[a[1]] = a[2] ?? a[3] ?? a[4] ?? '';
    const e = create(tag, attrs); if (stack.length) stack.at(-1).append(e);
    if (tag === 'option') { const select = e.closest('select'); if (select && (!select.value || 'selected' in attrs)) select.value = e.value; }
    if (!['input','img','meta','link','br','hr'].includes(tag) && !m[0].endsWith('/>')) stack.push(e);
  }
  const doc = eventTarget({
    querySelector: s => elements.find(x => match(x, s)) || null,
    querySelectorAll: s => elements.filter(x => match(x, s)), getElementById: id => byId.get(id) || null,
    createElement: tag => create(tag), documentElement: byId.get('__html') || elements.find(x => x.tagName === 'HTML') || create('html'),
    body: elements.find(x => x.tagName === 'BODY') || create('body'), readyState: 'complete', hidden: false,
    elementFromPoint() { return null; }, exitFullscreen() { return Promise.resolve(); }
  });
  return { document: doc, elements, byId, canvasContext, eventTarget, globalEvents };
}

function loadProject({ baseline = false, native = false, audio = false, mobile = true, stripRetiredVideoHook = false } = {}) {
  const root = path.resolve(__dirname, '..'), assets = path.join(root, 'reference-webview/assets');
  const html = fs.readFileSync(baseline ? path.join(root, 'original.html') : path.join(assets, 'BadGenesis.html'), 'utf8');
  const dom = makeDOM(html), local = new Map(), calls = [], intervals = new Map();
  let timer = 0;
  const context = {
    console, document: dom.document, performance, Uint8Array, Uint8ClampedArray, Uint16Array, Uint32Array, Int16Array, Int32Array,
    Float32Array, Float64Array, ArrayBuffer, DataView, Map, Set, URL, Blob, TextDecoder, TextEncoder, Response, Event,
    btoa, atob, structuredClone, crypto: webcrypto, Math, Date, JSON, Promise,
    navigator: { getGamepads: () => [], clipboard: { writeText: async () => {} } }, location: { hash: '', href: 'file://' + assets + '/BadGenesis.html' },
    innerWidth: 1280, innerHeight: 720,
    localStorage: { getItem: k => local.get(k) ?? null, setItem: (k, v) => local.set(k, String(v)), removeItem: k => local.delete(k), key: i => [...local.keys()][i] ?? null, get length() { return local.size; } },
    requestAnimationFrame: () => 0, cancelAnimationFrame() {},
    setTimeout: () => ++timer, clearTimeout() {}, setInterval: fn => { const id = ++timer; intervals.set(id, fn); return id; }, clearInterval: id => intervals.delete(id),
    fetch: async url => { const file = path.join(assets, String(url).split('/').pop()); return new Response(fs.readFileSync(file)); }
  };
  context.window = context; context.globalThis = context; dom.eventTarget(context);
  if (native) context.AndroidApp = Object.fromEntries(['setOrientation','enterGameplay','exitGameplay','copyText','exportFile','writePCM','flush','setEnabled','setVibrationEnabled','vibrate'].map(k => [k, (...a) => calls.push([k, ...a])]));
  if (native) context.AndroidAudio = Object.fromEntries(['writePCM','flush','setEnabled'].map(k => [k, (...a) => calls.push(['audio:' + k, ...a])]));
  const ctx = vm.createContext(context);
  const run = (src, filename) => vm.runInContext(src, ctx, {filename, timeout:120000});
  if (baseline) {
    const first = html.match(/<script\b[^>]*>([\s\S]*?)<\/script>/i);
    run(first[1], 'original.html');
  } else {
    for (const name of ['core.js', ...(audio ? ['z80.js','ym2612.js','audio.js'] : []), 'rtc.js', ...(mobile ? ['mobile.js'] : [])]) {
      let source = fs.readFileSync(path.join(assets, name), 'utf8');
      if (name === 'core.js' && stripRetiredVideoHook) source = source.replace(/\$\('#videoMode'\)\.onchange=e=>\{\$\('#screenShell'\)\.className='screen-shell '\+\(e\.target\.value==='pixel'\?'':e\.target\.value\)\};?/, '');
      run(source, name);
    }
  }
  return { ...dom, context, run: code => run(code, 'integration-test'), nativeCalls: calls, local, intervals };
}
module.exports = { loadProject, makeDOM };

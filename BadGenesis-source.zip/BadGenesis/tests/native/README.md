# Native emulator validation

These tests execute the pinned upstream Genesis Plus GX C emulator directly.
They do not run WebView, JavaScript emulation, a commercial game ROM, or a mock
emulator. The public-domain diagnostic ROM contains original Motorola 68000
instructions, a real Z80 sound driver, a VDP checkerboard, and controller reads.

`generate-native-diagnostic.cjs` derives the native fixture from the preserved
prototype fixture. It releases Z80 RESET while BUSREQ remains asserted before
uploading the driver. This grants the Motorola 68000 real hardware access to
Z80 RAM; the prototype fixture wrote during RESET, which the native core
correctly rejected. No commercial game or third-party assets are included.

`core-validation.c` verifies:

- Hardware NTSC 59.922743404 Hz and PAL 49.701459186 Hz, independent of Android
  display refresh rate.
- Exactly 600 native emulated frames and the corresponding real stereo 44,100
  Hz PCM sample counts.
- Executing 68000 and Z80 programs, controller input including a diagonal and
  attack held together, and a sharp 320 by 224 RGB565 framebuffer.
- Independent YM2612 FM output and SN76489 PSG output by muting one chip in the
  ROM's actual Z80 driver. The PSG divider test checks pitch against hardware.
- Full core state replay with byte-identical future PCM, video and Work RAM.
- Two independent sound snapshots, so older rewind records keep their own
  resampler phase and tail instead of using one global scratch state.

The BadGenesis native state container supplements the upstream serialization
with audio buffer state, SRAM, ROM working-copy patches, RTC history position,
controller handshake state and the 68000 prefetch/refresh phase. The pristine
upstream sources and Git blob checksums remain in `vendor/genesis-plus-gx`.
The controller extension is appended to a generated build copy of `gamepad.c`.

`backend-validation.cpp` runs the production `NativeBackend` worker, commands,
live memory domains, audio consumer and native state container. It retains the
original clock, simultaneous input, real PCM, domain mutation, complete future
replay, visible palette/tile corruption, automatic randomness and rewind checks.
Compressed snapshots must own storage close to their compressed byte size;
retaining the full uncompressed allocation would defeat the rewind RAM budget.
Playback checks additionally verify:

- Held 4x fast-forward on NTSC and PAL advances emulated frames at four times
  the core's hardware rate, and releasing it restores normal speed.
- Auto Blast still occurs at exact emulated-frame intervals while fast-forward
  is held, with an independent seed on every blast.
- 1x and 4x rewind track emulated time with snapshot intervals of 2 and 15
  frames. Snapshot cadence changes state capture cost, not playback speed.
- Audible rewind returns varied nonzero PCM from the actual emulator, then
  resumes real forward audio. Disabling rewind audio mutes playback while full
  native state restoration continues.
- At 1x, a reverse output packet exactly matches at least 128 captured native
  stereo frames in reverse order. The diagnostic's real Z80 driver is modified
  only to pan FM left while PSG plays on both channels, so this also checks that
  left/right channels are preserved. No artificial test tones are injected.
- Benchmarking runs 120 actual native frames and reports measured performance
  while preserving the complete native state, RTC history, rewind snapshots
  and retained PCM. Benchmark audio is suppressed.

The smooth rewind regression adds a VBlank-paced palette animation to the
original diagnostic's real 68000 program. It first proves that ordinary native
gameplay produces at least 40 different captured framebuffers per second. It
then checks the actual displayed pixel bytes during held rewind at 1x, 2x and
4x, with full keyframe intervals of both 6 and 15 frames. Each run must still
produce at least 40 different native framebuffers per second, avoid any pixel
freeze lasting 110 ms, restore the complete native core on each playback tick,
and output varied reverse PCM. A frame counter or repeated presentation of one
saved image cannot satisfy these checks. The original public-domain fixture is
preserved; no game assets or synthetic emulator output are used.

The RAM-only tape records reverse deltas of the complete native state on every
emulated frame. Periodic compressed full keyframes, the reusable complete raw
state images, reverse deltas and real PCM all count toward the 96 MiB limit.
Manual state files continue using the native compressed container. The tests
verify exact future execution after releasing rewind across RTC blasts and
then saving/restoring that full state, including CPU, VDP, FM/PSG, controller,
SRAM, working ROM and framebuffer bytes.

A 120-second history test retains at least 110 seconds of actual diagnostic
states and PCM, scrubs backward more than one minute, then repeats the pixel
cadence and audio checks at 2x. This exercises the retained reverse audio cursor
far inside a long tape, rather than testing only its newest few segments. The
reported capture and restore costs are host measurements, not phone performance
claims. Quick gameplay Blast is also tested without pausing: every tap mutates
the selected live domain and range, records its own fresh seed and exact previous
and new bytes, remains undoable, and leaves gameplay and the original ROM intact.

The raw `rewind_audio` export is the retained core PCM trace in chronological
PCM16 little-endian stereo order. It is a sound debugging trace, not a separate
sound generator. The tests compare that genuine trace with the production audio
consumer output. Host clock checks allow a small frame-boundary tolerance. The
older interval tests remain alongside the stronger actual-pixel cadence tests;
passing frame-counter timing alone is insufficient. They do not promise phone
frame rates.

Run `tools/test-native.sh` in the cloud. Its separate RTC and frontend tests
follow the emulator baseline checks. Passing host tests proves these native
core behaviors; it does not claim Sonic was tested or replace a phone check
of real gameplay, Android audio output, touch controls and device performance.

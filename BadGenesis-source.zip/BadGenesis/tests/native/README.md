# Native emulator validation

These tests execute the pinned upstream Genesis Plus GX C emulator directly.
They do not run WebView, JavaScript emulation, a commercial game ROM, or a mock
emulator. The public-domain diagnostic ROM contains original Motorola 68000
instructions, a real Z80 sound driver, a VDP checkerboard, and controller reads.

`generate-native-diagnostic.cjs` derives the native fixture from the preserved
prototype fixture. It releases Z80 RESET while BUSREQ remains asserted before
uploading the driver. This grants the Motorola 68000 real hardware access to
Z80 RAM; the prototype fixture wrote during RESET, which the native core
correctly rejected. No commercial game or third-party assets are included.

`core-validation.c` verifies:

- Hardware NTSC 59.922743404 Hz and PAL 49.701459186 Hz, independent of Android
  display refresh rate.
- Exactly 600 native emulated frames and the corresponding real stereo 44,100
  Hz PCM sample counts.
- Executing 68000 and Z80 programs, controller input including a diagonal and
  attack held together, and a sharp 320 by 224 RGB565 framebuffer.
- Independent YM2612 FM output and SN76489 PSG output by muting one chip in the
  ROM's actual Z80 driver. The PSG divider test checks pitch against hardware.
- Full core state replay with byte-identical future PCM, video and Work RAM.
- Two independent sound snapshots, so older rewind records keep their own
  resampler phase and tail instead of using one global scratch state.

The BadGenesis native state container supplements the upstream serialization
with audio buffer state, SRAM, ROM working-copy patches, RTC history position,
controller handshake state and the 68000 prefetch/refresh phase. The pristine
upstream sources and Git blob checksums remain in `vendor/genesis-plus-gx`.
The controller extension is appended to a generated build copy of `gamepad.c`.

Run `tools/test-native.sh` in the cloud. Its separate RTC and frontend tests
follow the emulator baseline checks. Passing host tests proves these native
core behaviors; it does not claim Sonic was tested or replace a phone check
of real gameplay, Android audio output, touch controls and device performance.

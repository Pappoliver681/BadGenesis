/* Validation of the production native worker and RTC bridge, using the
 * public-domain diagnostic ROM. Host timings are clock checks, not Android
 * performance promises. No WebView, JavaScript engine, or mocked core runs. */
#include "native_backend.h"
#include "mini_json.h"
#include "libretro.h"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <set>
#include <stdexcept>
#include <thread>
#include <vector>
#include <zlib.h>

using badgenesis::Json;
using badgenesis::NativeBackend;
using Clock = std::chrono::steady_clock;
using namespace std::chrono_literals;

extern "C" {
extern uint8_t bg_name_dirty[0x800], sat[0x400], reg[0x20];
extern uint16_t bg_name_list[0x800], bg_list_index, satb;
}

static void require(bool ok, const std::string& message) {
    if (!ok) throw std::runtime_error(message);
}
static Json status(NativeBackend& backend) { return Json::parse(backend.status()); }
static uint64_t frame(NativeBackend& backend) { return status(backend)["frame"].integer(); }
static Json command(NativeBackend& backend, const std::string& action, const std::string& body = "{}") {
    auto value = Json::parse(backend.command(action, body));
    require(value["ok"].flag(), action + ": " + value["error"].text());
    return value;
}
static void pause(NativeBackend& backend, bool paused = true) {
    command(backend, "pause", paused ? "{\"paused\":true}" : "{\"paused\":false}");
}
static void waitPaused(NativeBackend& backend) {
    const auto deadline = Clock::now() + 5s;
    while (Clock::now() < deadline) {
        if (status(backend)["paused"].flag()) return;
        std::this_thread::sleep_for(10ms);
    }
    throw std::runtime_error("Native harvester did not pause at its emulated frame limit");
}
static void configure(NativeBackend& backend, const std::string& selected,
                      uint32_t start, uint32_t end, const std::string& engine,
                      unsigned intensity = 1, bool automatic = false, unsigned interval = 3) {
    const auto domains = Json::parse(backend.domains());
    std::string json = "{\"engine\":" + Json::quote(engine) + ",\"intensity\":" + std::to_string(intensity)
        + ",\"manualSeed\":false,\"auto\":" + (automatic ? "true" : "false")
        + ",\"interval\":" + std::to_string(interval) + ",\"domains\":[";
    bool comma = false;
    for (const auto& domain : domains.array) {
        if (comma) json += ',';
        comma = true;
        const auto id = domain["id"].text();
        json += "{\"id\":" + Json::quote(id) + ",\"enabled\":" + (id == selected ? "true" : "false")
            + ",\"start\":" + std::to_string(start) + ",\"end\":" + std::to_string(end) + ",\"exclusions\":[]}";
    }
    command(backend, "rtc_config", json + "]}");
}
static std::vector<uint8_t> readFile(const std::string& path) {
    std::ifstream file(path, std::ios::binary | std::ios::ate);
    require(bool(file), "Cannot read diagnostic fixture");
    const auto size = file.tellg(); require(size > 512, "Diagnostic ROM is too small");
    std::vector<uint8_t> bytes(static_cast<size_t>(size)); file.seekg(0);
    require(bool(file.read(reinterpret_cast<char*>(bytes.data()), bytes.size())), "Incomplete diagnostic ROM");
    return bytes;
}
static std::vector<uint8_t> rawState(const std::vector<uint8_t>& state) {
    require(state.size() > 12 && std::string(state.begin(), state.begin() + 8) == "BGNS003Z", "Unexpected native state header");
    const uint32_t size = (uint32_t(state[8]) << 24) | (uint32_t(state[9]) << 16) | (uint32_t(state[10]) << 8) | state[11];
    require(size < 64 * 1024 * 1024, "Native state allocation exceeds its limit");
    std::vector<uint8_t> raw(size); uLongf actual = size;
    require(uncompress(raw.data(), &actual, state.data() + 12, state.size() - 12) == Z_OK && actual == size, "Native state cannot decompress");
    return raw;
}
static uint32_t take32(const std::vector<uint8_t>& bytes, size_t& at) {
    require(at + 4 <= bytes.size(), "Truncated native state prefix");
    uint32_t value = 0; for (unsigned i = 0; i < 4; ++i) value = (value << 8) | bytes[at++];
    return value;
}
// The native container prefixes its execution data with ROM identity, ABI,
// emulated frame and RTC history ownership. A repeated harvester candidate has
// a new history number; its entire execution payload must still be identical.
static std::vector<uint8_t> executionPayload(const std::vector<uint8_t>& state) {
    auto raw = rawState(state); size_t at = 0;
    const auto identitySize = take32(raw, at); require(identitySize < 256, "Invalid ROM identity");
    at += identitySize; require(take32(raw, at) == sizeof(void*), "Native ABI field differs");
    at += 8 * 3; const auto activeBlasts = take32(raw, at);
    require(activeBlasts < 100000 && at + activeBlasts * 8ULL <= raw.size(), "Invalid active blast list");
    at += activeBlasts * 8ULL;
    return {raw.begin() + at, raw.end()};
}
static std::vector<uint8_t> framebuffer(const std::vector<uint8_t>& state) {
    // This fixture always produces the Genesis 320x224 framebuffer. These are
    // the actual native presentation pixels at the end of the full container.
    auto raw = rawState(state); constexpr size_t pixelBytes = 320 * 224 * 4;
    require(raw.size() > pixelBytes + 12, "Native framebuffer is missing");
    size_t at = raw.size() - pixelBytes - 12;
    require(take32(raw, at) == 320 && take32(raw, at) == 224 && take32(raw, at) == 320 * 224,
            "Native diagnostic framebuffer dimensions differ");
    return {raw.begin() + at, raw.end()};
}
static std::vector<uint8_t> palROM(std::vector<uint8_t> rom) {
    std::fill(rom.begin() + 0x1f0, rom.begin() + 0x200, ' '); rom[0x1f0] = 'E'; return rom;
}
static void checkClock(NativeBackend& backend, const std::vector<uint8_t>& rom, bool pal) {
    require(backend.loadRom(rom, pal ? "native-diagnostic-PAL.bin" : "native-diagnostic-NTSC.bin").empty(), "Native ROM loading failed");
    std::this_thread::sleep_for(80ms); pause(backend);
    auto initial = status(backend); const double fps = initial["fps"].number;
    require(std::abs(fps - (pal ? 49.701459 : 59.922743)) < 0.001, "Incorrect native Genesis hardware frame rate");
    require(initial["backend"].text() == "Genesis Plus GX native", "Wrong execution backend");
    require(initial["error"].text().empty(), "Native core reported an error: " + initial["error"].text());
    const auto startFrame = frame(backend); const auto begin = Clock::now(); pause(backend, false);
    std::this_thread::sleep_for(1300ms); pause(backend);
    const auto advanced = frame(backend) - startFrame;
    const double seconds = std::chrono::duration<double>(Clock::now() - begin).count();
    require(std::abs(double(advanced) - fps * seconds) <= 3.5, "Worker advances faster/slower than hardware emulated time");
    const auto heldFrame = frame(backend); std::this_thread::sleep_for(300ms);
    require(frame(backend) == heldFrame, "Paused worker advanced emulated frames");
    pause(backend, false); std::this_thread::sleep_for(80ms); pause(backend);
    const auto resumed = frame(backend) - heldFrame;
    require(resumed >= 2 && resumed <= uint64_t(std::ceil(fps * .08)) + 2, "Worker ran an uncapped catch-up burst after pause");
    require(backend.readMemory("zram", 0x1ff0, 1) == std::vector<uint8_t>{0x42}, "Real Z80 diagnostic did not execute");
    std::cout << "{\"check\":\"native_worker_" << (pal ? "pal" : "ntsc")
        << "_clock_pause_resume\",\"frames\":" << advanced << ",\"wall_seconds\":" << seconds
        << ",\"hardware_fps\":" << fps << ",\"resumed_frames\":" << resumed << "}\n";
}
static void checkAudioAndInput(NativeBackend& backend) {
    pause(backend, false);
    // NativeBridge uses Genesis button order: U,D,L,R,A,B,C,X,Y,Z,START,MODE.
    const uint16_t pressed = (1U << 0) | (1U << 3) | (1U << 5);
    backend.setButtons(pressed); std::this_thread::sleep_for(70ms);
    require((backend.readMemory("wram", 0, 1).at(0) & 0x19) == 0, "Native simultaneous diagonal + action input did not reach the game");
    backend.setButtons(0);
    size_t nonzero = 0; int peak = 0; std::set<int16_t> values;
    std::vector<int16_t> samples(441 * 2);
    for (unsigned batch = 0; batch < 60; ++batch) {
        backend.audioCallback(samples.data(), 441);
        for (auto value : samples) { nonzero += value != 0; peak = std::max(peak, std::abs(int(value))); values.insert(value); }
        std::this_thread::sleep_for(10ms);
    }
    require(nonzero > 5000 && peak > 1000 && values.size() > 100, "Native PCM ring is silent or lacks real diagnostic FM/PSG synthesis");
    pause(backend); backend.audioCallback(samples.data(), 441);
    require(std::all_of(samples.begin(), samples.end(), [](auto value) { return value == 0; }), "Pause did not flush/mute native PCM output");
    std::cout << "{\"check\":\"native_worker_real_pcm_and_simultaneous_input\",\"nonzero_samples\":" << nonzero
        << ",\"distinct_samples\":" << values.size() << ",\"peak\":" << peak << "}\n";
}
static void checkLiveDomainsAndState(NativeBackend& backend, const std::vector<uint8_t>& rom) {
    const auto domainMetadata = Json::parse(backend.domains()); std::set<std::string> names;
    for (const auto& value : domainMetadata.array) names.insert(value["id"].text());
    require(names == std::set<std::string>{"wram", "zram", "vram", "cram", "vsram", "sram", "rom"}, "Seven live Genesis RTC domains are not exposed");
    const auto clean = backend.exportState();
    configure(backend, "wram", 0x8000, 0x8001, "nop"); command(backend, "blast");
    require(backend.readMemory("wram", 0x8000, 2) == std::vector<uint8_t>({0x4e, 0x71}), "68000 NOP bytes have the wrong logical byte order");
    command(backend, "undo"); require(backend.importState(clean).empty(), "Native clean state load failed");
    const std::vector<std::pair<std::string, uint32_t>> locations = {
        {"zram", 0x1800}, {"vram", 0x2000}, {"vsram", 2}, {"sram", 8}, {"rom", 0x7000}
    };
    for (const auto& [domain, address] : locations) {
        const auto before = backend.readMemory(domain, address, 1);
        configure(backend, domain, address, address, "ff"); command(backend, "blast");
        require(backend.readMemory(domain, address, 1) == std::vector<uint8_t>{255}, "Live " + domain + " corruption did not reach the core");
        command(backend, "undo"); require(backend.readMemory(domain, address, 1) == before, "Undo failed for live " + domain);
    }
    configure(backend, "cram", 26, 27, "ff", 256); command(backend, "blast");
    require(backend.readMemory("cram", 26, 2) == std::vector<uint8_t>({0x0e, 0xee}), "CRAM logical bytes do not match packed Genesis color storage");
    const auto colored = backend.exportState(); require(backend.importState(colored).empty(), "Normalized CRAM state failed palette reconstruction");
    command(backend, "undo"); require(backend.importState(clean).empty(), "Full native clean restore failed");
    configure(backend, "rom", 0x7000, 0x7000, "ff"); command(backend, "blast");
    configure(backend, "sram", 8, 8, "zero"); command(backend, "blast");
    const auto patchedROM = backend.exportData("rom"), patchedSRAM = backend.exportData("sram");
    const auto patched = backend.exportState(); command(backend, "quick_save"); command(backend, "save_slot", "{\"slot\":1}");
    require(backend.exportData("original") == rom, "RTC overwrote the original ROM");
    require(backend.importState(clean).empty(), "Could not restore clean ROM/SRAM state");
    require(backend.exportData("rom")[0x7000] == rom[0x7000] && backend.exportData("sram")[8] != patchedSRAM[8], "Full clean state did not restore SRAM and ROM patches");
    command(backend, "quick_load");
    require(backend.exportData("rom") == patchedROM && backend.exportData("sram") == patchedSRAM, "Quick load did not restore owned SRAM/ROM mutations");
    require(backend.importState(clean).empty(), "Could not return to clean native state"); command(backend, "load_slot", "{\"slot\":1}");
    require(backend.exportData("rom") == patchedROM && backend.exportData("sram") == patchedSRAM, "Persistent slot did not restore owned SRAM/ROM mutations");
    auto damaged = patched; damaged[damaged.size() / 2] ^= 0xff;
    const auto beforeRejectedLoad = backend.exportState();
    require(!backend.importState(damaged).empty(), "Damaged compressed state was accepted");
    require(backend.exportState() == beforeRejectedLoad, "Rejected damaged state changed the running emulator");
    require(backend.importState(clean).empty(), "Could not restore native baseline");
    std::cout << "{\"check\":\"native_live_seven_domains_endian_cram_undo_sram_rom_states\",\"original_rom_immutable\":true,\"full_state_bytes\":" << patched.size() << "}\n";
}
static void checkFutureReplay(NativeBackend& backend) {
    configure(backend, "wram", 0xf000, 0xf000, "zero");
    command(backend, "harvester_start"); command(backend, "harvester_next", "{\"runFrames\":20}"); waitPaused(backend);
    const auto first = executionPayload(backend.exportState()); const auto firstDebug = backend.command("debug", "{}");
    const auto firstFrame = frame(backend);
    command(backend, "harvester_discard"); command(backend, "harvester_next", "{\"runFrames\":20}"); waitPaused(backend);
    require(frame(backend) == firstFrame, "Repeated candidate ran a different number of emulated frames");
    require(backend.command("debug", "{}") == firstDebug, "Full state restore changed future CPU/Z80/VDP registers");
    require(executionPayload(backend.exportState()) == first, "Full native state did not reproduce future CPU/VDP/audio tails/pad/SRAM/ROM/framebuffer payload");
    command(backend, "harvester_keep"); command(backend, "harvester_discard");
    const auto discardedFrame = frame(backend); require(discardedFrame + 20 == firstFrame, "Harvester discard did not return to its clean native frame");
    command(backend, "harvester_stop"); pause(backend);
    std::cout << "{\"check\":\"native_owned_full_future_payload_and_harvester\",\"future_frames\":20,\"future_execution_bytes\":" << first.size() << "}\n";
}
static void checkVisibleVideoCorruption(NativeBackend& backend) {
    // A one-byte RTC tile mutation must invalidate the real decoded pattern
    // cache and produce changed pixels, without touching the presentation UI.
    configure(backend, "wram", 0xf000, 0xf000, "zero");
    command(backend, "harvester_start"); command(backend, "harvester_next", "{\"runFrames\":2}"); waitPaused(backend);
    const auto baseline = framebuffer(backend.exportState()); std::set<uint32_t> colors;
    for (size_t at = 0; at < baseline.size(); at += 4)
        colors.insert(uint32_t(baseline[at]) | uint32_t(baseline[at + 1]) << 8
            | uint32_t(baseline[at + 2]) << 16 | uint32_t(baseline[at + 3]) << 24);
    require(colors.size() >= 3, "Native diagnostic does not render its actual colored tiles");
    command(backend, "harvester_discard");
    configure(backend, "vram", 32, 32, "ff"); command(backend, "blast");
    require((bg_name_dirty[1] & 1) && std::find(bg_name_list, bg_name_list + bg_list_index, 1) != bg_name_list + bg_list_index,
            "RTC VRAM write did not dirty the actual decoded tile cache");
    command(backend, "undo");
    // SAT has a separate hardware cache; both the live VRAM and that cache
    // must receive the same logical byte before the sprite parser sees it.
    const auto spriteOffset = uint32_t(satb); const auto spriteBefore = backend.readMemory("vram", spriteOffset, 1);
    configure(backend, "vram", spriteOffset, spriteOffset, "ff"); command(backend, "blast");
    const unsigned addressMask = reg[12] & 1 ? 0x3ff : 0x1ff;
    require(sat[(spriteOffset & addressMask) ^ 1] == 255, "RTC SAT mutation did not update the real sprite attribute cache");
    command(backend, "undo"); require(backend.readMemory("vram", spriteOffset, 1) == spriteBefore, "Undo did not restore the SAT byte");
    command(backend, "harvester_discard");
    configure(backend, "vram", 32, 32, "ff"); command(backend, "harvester_next", "{\"runFrames\":2}"); waitPaused(backend);
    const auto tilePixels = framebuffer(backend.exportState());
    require(tilePixels != baseline, "Live VRAM blast did not change the Genesis framebuffer");
    command(backend, "harvester_discard");
    require(framebuffer(backend.exportState()) == baseline, "Full state restore did not recover the clean Genesis framebuffer");
    // Color 1 is red in the fixture. A logical low-byte FF write turns its
    // R/G components on after the core's 9-bit CRAM packing, changing pixels.
    configure(backend, "cram", 3, 3, "ff"); command(backend, "harvester_next", "{\"runFrames\":2}"); waitPaused(backend);
    const auto palettePixels = framebuffer(backend.exportState());
    require(palettePixels != baseline && palettePixels != tilePixels, "Live CRAM corruption did not update the displayed palette");
    command(backend, "harvester_discard");
    require(framebuffer(backend.exportState()) == baseline, "Rewind/load did not recover the full pre-blast palette frame");
    command(backend, "harvester_stop"); pause(backend);
    std::cout << "{\"check\":\"native_visible_tile_palette_and_sprite_cache_corruption\",\"framebuffer_bytes\":"
        << baseline.size() << ",\"baseline_colors\":" << colors.size() << ",\"vram_pixels_changed\":true,\"cram_pixels_changed\":true}\n";
}
static void checkAutoAndRewind(NativeBackend& backend) {
    command(backend, "rewind_config", "{\"seconds\":15,\"intervalFrames\":2}");
    configure(backend, "wram", 0x9000, 0x903f, "random", 16, true, 3);
    pause(backend, false); std::this_thread::sleep_for(550ms); pause(backend);
    const auto forward = frame(backend);
    const auto historyBefore = command(backend, "history", "{\"includeUnits\":true}")["history"];
    std::set<std::string> seeds; size_t activeBefore = 0;
    for (const auto& record : historyBefore.array) { if (record["active"].flag()) ++activeBefore; seeds.insert(record["seed"].text()); }
    require(historyBefore.array.size() >= 5 && seeds.size() == historyBefore.array.size(), "Native Auto Blast did not use fresh independent random seeds");
    configure(backend, "wram", 0x9000, 0x903f, "random", 16, false, 3);
    const auto cursorBefore = status(backend)["rtc"]["blastCursor"].integer();
    command(backend, "rewind", "{\"held\":true}"); std::this_thread::sleep_for(140ms);
    const auto rewindFrame = frame(backend); std::this_thread::sleep_for(110ms);
    const auto laterRewindFrame = frame(backend);
    require(laterRewindFrame < rewindFrame && rewindFrame < forward, "Held native rewind did not continuously restore previous full states");
    command(backend, "rewind", "{\"held\":false}");
    const auto historyAfter = command(backend, "history")["history"]; size_t activeAfter = 0;
    for (const auto& record : historyAfter.array) activeAfter += record["active"].flag();
    require(activeAfter < activeBefore, "Rewind across RTC blasts left future corruption history active");
    require(status(backend)["rtc"]["blastCursor"].integer() <= cursorBefore, "Rewind increased the history cursor");
    if (activeAfter) command(backend, "undo");
    pause(backend, false); const auto resumed = frame(backend); std::this_thread::sleep_for(100ms); pause(backend);
    require(frame(backend) > resumed && frame(backend) - resumed <= 9, "Release rewind did not resume from restored emulated time");
    const auto state = status(backend); require(state["rewindBytes"].integer() <= 96 * 1024 * 1024, "Native rewind ring exceeded its RAM budget");
    std::cout << "{\"check\":\"native_random_auto_blast_continuous_rewind_history_resume\",\"auto_blasts\":" << historyBefore.array.size()
        << ",\"forward_frame\":" << forward << ",\"restored_frame\":" << laterRewindFrame << ",\"inactive_after_rewind\":" << activeBefore - activeAfter << "}\n";
}
int main(int argc, char** argv) {
    try {
        require(argc == 2, "Usage: backend-validation diagnostic.bin");
        const auto rom = readFile(argv[1]);
        const std::string directory = "/tmp/badgenesis-native-backend-" + std::to_string(Clock::now().time_since_epoch().count());
        std::filesystem::create_directories(directory);
        {
            NativeBackend backend(directory);
            checkClock(backend, rom, false); checkAudioAndInput(backend);
            checkLiveDomainsAndState(backend, rom); checkFutureReplay(backend); checkVisibleVideoCorruption(backend); checkAutoAndRewind(backend);
            checkClock(backend, palROM(rom), true); checkAudioAndInput(backend);
        }
        std::filesystem::remove_all(directory);
        std::cout << "{\"check\":\"production_native_worker_validation_complete\",\"passed\":true,\"phone_performance_tested\":false}\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "Native backend validation failed: " << error.what() << '\n'; return 1;
    }
}

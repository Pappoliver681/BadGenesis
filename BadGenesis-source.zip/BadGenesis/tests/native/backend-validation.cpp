/* Validation of the production native worker and RTC bridge, using the
 * public-domain diagnostic ROM. Host timings are clock checks, not Android
 * performance promises. No WebView, JavaScript engine, or mocked core runs. */
#include "native_backend.h"
#include "mini_json.h"
#include "libretro.h"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <set>
#include <stdexcept>
#include <thread>
#include <vector>
#include <zlib.h>

using badgenesis::Json;
using badgenesis::NativeBackend;
using Clock = std::chrono::steady_clock;
using namespace std::chrono_literals;

extern "C" {
extern uint8_t bg_name_dirty[0x800], sat[0x400], reg[0x20];
extern uint16_t bg_name_list[0x800], bg_list_index, satb;
}

static void require(bool ok, const std::string& message) {
    if (!ok) throw std::runtime_error(message);
}
static Json status(NativeBackend& backend) { return Json::parse(backend.status()); }
static uint64_t frame(NativeBackend& backend) { return status(backend)["frame"].integer(); }
static Json command(NativeBackend& backend, const std::string& action, const std::string& body = "{}") {
    auto value = Json::parse(backend.command(action, body));
    require(value["ok"].flag(), action + ": " + value["error"].text());
    return value;
}
static void pause(NativeBackend& backend, bool paused = true) {
    command(backend, "pause", paused ? "{\"paused\":true}" : "{\"paused\":false}");
}
static void waitPaused(NativeBackend& backend) {
    const auto deadline = Clock::now() + 5s;
    while (Clock::now() < deadline) {
        if (status(backend)["paused"].flag()) return;
        std::this_thread::sleep_for(10ms);
    }
    throw std::runtime_error("Native harvester did not pause at its emulated frame limit");
}
static void configure(NativeBackend& backend, const std::string& selected,
                      uint32_t start, uint32_t end, const std::string& engine,
                      unsigned intensity = 1, bool automatic = false, unsigned interval = 3) {
    const auto domains = Json::parse(backend.domains());
    std::string json = "{\"engine\":" + Json::quote(engine) + ",\"intensity\":" + std::to_string(intensity)
        + ",\"manualSeed\":false,\"auto\":" + (automatic ? "true" : "false")
        + ",\"interval\":" + std::to_string(interval) + ",\"domains\":[";
    bool comma = false;
    for (const auto& domain : domains.array) {
        if (comma) json += ',';
        comma = true;
        const auto id = domain["id"].text();
        json += "{\"id\":" + Json::quote(id) + ",\"enabled\":" + (id == selected ? "true" : "false")
            + ",\"start\":" + std::to_string(start) + ",\"end\":" + std::to_string(end) + ",\"exclusions\":[]}";
    }
    command(backend, "rtc_config", json + "]}");
}
static std::vector<uint8_t> readFile(const std::string& path) {
    std::ifstream file(path, std::ios::binary | std::ios::ate);
    require(bool(file), "Cannot read diagnostic fixture");
    const auto size = file.tellg(); require(size > 512, "Diagnostic ROM is too small");
    std::vector<uint8_t> bytes(static_cast<size_t>(size)); file.seekg(0);
    require(bool(file.read(reinterpret_cast<char*>(bytes.data()), bytes.size())), "Incomplete diagnostic ROM");
    return bytes;
}
static std::vector<uint8_t> rawState(const std::vector<uint8_t>& state) {
    require(state.size() > 12 && std::string(state.begin(), state.begin() + 8) == "BGNS003Z", "Unexpected native state header");
    const uint32_t size = (uint32_t(state[8]) << 24) | (uint32_t(state[9]) << 16) | (uint32_t(state[10]) << 8) | state[11];
    require(size < 64 * 1024 * 1024, "Native state allocation exceeds its limit");
    std::vector<uint8_t> raw(size); uLongf actual = size;
    require(uncompress(raw.data(), &actual, state.data() + 12, state.size() - 12) == Z_OK && actual == size, "Native state cannot decompress");
    return raw;
}
static uint32_t take32(const std::vector<uint8_t>& bytes, size_t& at) {
    require(at + 4 <= bytes.size(), "Truncated native state prefix");
    uint32_t value = 0; for (unsigned i = 0; i < 4; ++i) value = (value << 8) | bytes[at++];
    return value;
}
// The native container prefixes its execution data with ROM identity, ABI,
// emulated frame and RTC history ownership. A repeated harvester candidate has
// a new history number; its entire execution payload must still be identical.
static std::vector<uint8_t> executionPayload(const std::vector<uint8_t>& state) {
    auto raw = rawState(state); size_t at = 0;
    const auto identitySize = take32(raw, at); require(identitySize < 256, "Invalid ROM identity");
    at += identitySize; require(take32(raw, at) == sizeof(void*), "Native ABI field differs");
    at += 8 * 3; const auto activeBlasts = take32(raw, at);
    require(activeBlasts < 100000 && at + activeBlasts * 8ULL <= raw.size(), "Invalid active blast list");
    at += activeBlasts * 8ULL;
    return {raw.begin() + at, raw.end()};
}
static std::vector<uint8_t> framebuffer(const std::vector<uint8_t>& state) {
    // This fixture always produces the Genesis 320x224 framebuffer. These are
    // the actual native presentation pixels at the end of the full container.
    auto raw = rawState(state); constexpr size_t pixelBytes = 320 * 224 * 4;
    require(raw.size() > pixelBytes + 12, "Native framebuffer is missing");
    size_t at = raw.size() - pixelBytes - 12;
    require(take32(raw, at) == 320 && take32(raw, at) == 224 && take32(raw, at) == 320 * 224,
            "Native diagnostic framebuffer dimensions differ");
    return {raw.begin() + at, raw.end()};
}
static std::vector<uint8_t> palROM(std::vector<uint8_t> rom) {
    std::fill(rom.begin() + 0x1f0, rom.begin() + 0x200, ' '); rom[0x1f0] = 'E'; return rom;
}
static std::vector<uint8_t> animatedROM(std::vector<uint8_t> rom) {
    // Replace only the original fixture's tight controller loop with original
    // 68000 code paced by actual VDP VBlank. Color 1 changes on every native
    // emulated frame, so a frozen framebuffer cannot pass a counter-only test.
    const std::vector<uint8_t> oldLoop = {0x10, 0x39, 0, 0xa1, 0, 3,
        0x13, 0xc0, 0, 0xff, 0, 0, 0x52, 0x79, 0, 0xff, 0, 2, 0x60, 0};
    const auto found = std::search(rom.begin() + 0x200, rom.end(), oldLoop.begin(), oldLoop.end());
    require(found != rom.end(), "Original diagnostic 68000 controller loop was not found");
    size_t at = found - rom.begin();
    const auto word = [&rom, &at](uint16_t value) { rom.at(at++) = uint8_t(value >> 8); rom.at(at++) = uint8_t(value); };
    const auto longword = [&word](uint32_t value) { word(uint16_t(value >> 16)); word(uint16_t(value)); };
    const auto branch = [&word, &at](uint16_t operation, size_t target) {
        word(operation); const auto base = at; word(uint16_t(int16_t(target - base)));
    };
    // Enable the Genesis full-color palette. In the VDP's legacy palette mode
    // only one bit of each component is visible: a genuine alternating color
    // can appear static when 2x playback legitimately skips every other frame.
    word(0x33fc); word(0x8004); longword(0xc00004); const auto loop = at;
    word(0x1039); longword(0xa10003); word(0x13c0); longword(0xff0000);
    const auto clear = at; word(0x3239); longword(0xc00004); word(0x0801); word(3); branch(0x6600, clear);
    const auto set = at; word(0x3239); longword(0xc00004); word(0x0801); word(3); branch(0x6700, set);
    word(0x0679); word(0x22); longword(0xff0100); // ADDI.W #$22, genuine Work RAM counter.
    word(0x3039); longword(0xff0100); word(0x0240); word(0x0eee);
    word(0x23fc); longword(0xc0020000); longword(0xc00004); word(0x33c0); longword(0xc00000);
    branch(0x6000, loop);
    uint16_t checksum = 0;
    for (size_t i = 0x200; i + 1 < rom.size(); i += 2) checksum += (uint16_t(rom[i]) << 8) | rom[i + 1];
    rom[0x18e] = uint8_t(checksum >> 8); rom[0x18f] = uint8_t(checksum);
    return rom;
}
static void checkClock(NativeBackend& backend, const std::vector<uint8_t>& rom, bool pal) {
    require(backend.loadRom(rom, pal ? "native-diagnostic-PAL.bin" : "native-diagnostic-NTSC.bin").empty(), "Native ROM loading failed");
    std::this_thread::sleep_for(80ms); pause(backend);
    auto initial = status(backend); const double fps = initial["fps"].number;
    require(std::abs(fps - (pal ? 49.701459 : 59.922743)) < 0.001, "Incorrect native Genesis hardware frame rate");
    require(initial["backend"].text() == "Genesis Plus GX native", "Wrong execution backend");
    require(initial["error"].text().empty(), "Native core reported an error: " + initial["error"].text());
    const auto startFrame = frame(backend); const auto begin = Clock::now(); pause(backend, false);
    std::this_thread::sleep_for(1300ms); pause(backend);
    const auto advanced = frame(backend) - startFrame;
    const double seconds = std::chrono::duration<double>(Clock::now() - begin).count();
    require(std::abs(double(advanced) - fps * seconds) <= 3.5, "Worker advances faster/slower than hardware emulated time");
    const auto heldFrame = frame(backend); std::this_thread::sleep_for(300ms);
    require(frame(backend) == heldFrame, "Paused worker advanced emulated frames");
    pause(backend, false); std::this_thread::sleep_for(80ms); pause(backend);
    const auto resumed = frame(backend) - heldFrame;
    require(resumed >= 2 && resumed <= uint64_t(std::ceil(fps * .08)) + 2, "Worker ran an uncapped catch-up burst after pause");
    require(backend.readMemory("zram", 0x1ff0, 1) == std::vector<uint8_t>{0x42}, "Real Z80 diagnostic did not execute");
    std::cout << "{\"check\":\"native_worker_" << (pal ? "pal" : "ntsc")
        << "_clock_pause_resume\",\"frames\":" << advanced << ",\"wall_seconds\":" << seconds
        << ",\"hardware_fps\":" << fps << ",\"resumed_frames\":" << resumed << "}\n";
}
static void checkAudioAndInput(NativeBackend& backend) {
    pause(backend, false);
    // NativeBridge uses Genesis button order: U,D,L,R,A,B,C,X,Y,Z,START,MODE.
    const uint16_t pressed = (1U << 0) | (1U << 3) | (1U << 5);
    backend.setButtons(pressed); std::this_thread::sleep_for(70ms);
    require((backend.readMemory("wram", 0, 1).at(0) & 0x19) == 0, "Native simultaneous diagonal + action input did not reach the game");
    backend.setButtons(0);
    size_t nonzero = 0; int peak = 0; std::set<int16_t> values;
    std::vector<int16_t> samples(441 * 2);
    for (unsigned batch = 0; batch < 60; ++batch) {
        backend.audioCallback(samples.data(), 441);
        for (auto value : samples) { nonzero += value != 0; peak = std::max(peak, std::abs(int(value))); values.insert(value); }
        std::this_thread::sleep_for(10ms);
    }
    require(nonzero > 5000 && peak > 1000 && values.size() > 100, "Native PCM ring is silent or lacks real diagnostic FM/PSG synthesis");
    pause(backend); backend.audioCallback(samples.data(), 441);
    require(std::all_of(samples.begin(), samples.end(), [](auto value) { return value == 0; }), "Pause did not flush/mute native PCM output");
    std::cout << "{\"check\":\"native_worker_real_pcm_and_simultaneous_input\",\"nonzero_samples\":" << nonzero
        << ",\"distinct_samples\":" << values.size() << ",\"peak\":" << peak << "}\n";
}
static void checkLiveDomainsAndState(NativeBackend& backend, const std::vector<uint8_t>& rom) {
    const auto domainMetadata = Json::parse(backend.domains()); std::set<std::string> names;
    for (const auto& value : domainMetadata.array) names.insert(value["id"].text());
    require(names == std::set<std::string>{"wram", "zram", "vram", "cram", "vsram", "sram", "rom"}, "Seven live Genesis RTC domains are not exposed");
    const auto clean = backend.exportState();
    // The compressed state must own only compressed storage. Keeping the
    // compressBound(rawState) capacity silently inflated each ~8 KiB snapshot
    // to ~1.4 MiB while the rewind ring counted only its logical byte size.
    require(clean.capacity() <= clean.size() + 512,
            "Compressed native snapshot retains its uncompressed allocation capacity");
    configure(backend, "wram", 0x8000, 0x8001, "nop"); command(backend, "blast");
    require(backend.readMemory("wram", 0x8000, 2) == std::vector<uint8_t>({0x4e, 0x71}), "68000 NOP bytes have the wrong logical byte order");
    command(backend, "undo"); require(backend.importState(clean).empty(), "Native clean state load failed");
    const std::vector<std::pair<std::string, uint32_t>> locations = {
        {"zram", 0x1800}, {"vram", 0x2000}, {"vsram", 2}, {"sram", 8}, {"rom", 0x7000}
    };
    for (const auto& [domain, address] : locations) {
        const auto before = backend.readMemory(domain, address, 1);
        configure(backend, domain, address, address, "ff"); command(backend, "blast");
        require(backend.readMemory(domain, address, 1) == std::vector<uint8_t>{255}, "Live " + domain + " corruption did not reach the core");
        command(backend, "undo"); require(backend.readMemory(domain, address, 1) == before, "Undo failed for live " + domain);
    }
    configure(backend, "cram", 26, 27, "ff", 256); command(backend, "blast");
    require(backend.readMemory("cram", 26, 2) == std::vector<uint8_t>({0x0e, 0xee}), "CRAM logical bytes do not match packed Genesis color storage");
    const auto colored = backend.exportState(); require(backend.importState(colored).empty(), "Normalized CRAM state failed palette reconstruction");
    command(backend, "undo"); require(backend.importState(clean).empty(), "Full native clean restore failed");
    configure(backend, "rom", 0x7000, 0x7000, "ff"); command(backend, "blast");
    configure(backend, "sram", 8, 8, "zero"); command(backend, "blast");
    const auto patchedROM = backend.exportData("rom"), patchedSRAM = backend.exportData("sram");
    const auto patched = backend.exportState(); command(backend, "quick_save"); command(backend, "save_slot", "{\"slot\":1}");
    require(backend.exportData("original") == rom, "RTC overwrote the original ROM");
    require(backend.importState(clean).empty(), "Could not restore clean ROM/SRAM state");
    require(backend.exportData("rom")[0x7000] == rom[0x7000] && backend.exportData("sram")[8] != patchedSRAM[8], "Full clean state did not restore SRAM and ROM patches");
    command(backend, "quick_load");
    require(backend.exportData("rom") == patchedROM && backend.exportData("sram") == patchedSRAM, "Quick load did not restore owned SRAM/ROM mutations");
    require(backend.importState(clean).empty(), "Could not return to clean native state"); command(backend, "load_slot", "{\"slot\":1}");
    require(backend.exportData("rom") == patchedROM && backend.exportData("sram") == patchedSRAM, "Persistent slot did not restore owned SRAM/ROM mutations");
    auto damaged = patched; damaged[damaged.size() / 2] ^= 0xff;
    const auto beforeRejectedLoad = backend.exportState();
    require(!backend.importState(damaged).empty(), "Damaged compressed state was accepted");
    require(backend.exportState() == beforeRejectedLoad, "Rejected damaged state changed the running emulator");
    require(backend.importState(clean).empty(), "Could not restore native baseline");
    std::cout << "{\"check\":\"native_live_seven_domains_endian_cram_undo_sram_rom_states\",\"original_rom_immutable\":true,\"full_state_bytes\":" << patched.size()
        << ",\"compressed_state_size_bytes\":" << clean.size() << ",\"compressed_state_capacity_bytes\":" << clean.capacity() << "}\n";
}
static void checkFutureReplay(NativeBackend& backend) {
    configure(backend, "wram", 0xf000, 0xf000, "zero");
    command(backend, "harvester_start"); command(backend, "harvester_next", "{\"runFrames\":20}"); waitPaused(backend);
    const auto first = executionPayload(backend.exportState()); const auto firstDebug = backend.command("debug", "{}");
    const auto firstFrame = frame(backend);
    command(backend, "harvester_discard"); command(backend, "harvester_next", "{\"runFrames\":20}"); waitPaused(backend);
    require(frame(backend) == firstFrame, "Repeated candidate ran a different number of emulated frames");
    require(backend.command("debug", "{}") == firstDebug, "Full state restore changed future CPU/Z80/VDP registers");
    require(executionPayload(backend.exportState()) == first, "Full native state did not reproduce future CPU/VDP/audio tails/pad/SRAM/ROM/framebuffer payload");
    command(backend, "harvester_keep"); command(backend, "harvester_discard");
    const auto discardedFrame = frame(backend); require(discardedFrame + 20 == firstFrame, "Harvester discard did not return to its clean native frame");
    command(backend, "harvester_stop"); pause(backend);
    std::cout << "{\"check\":\"native_owned_full_future_payload_and_harvester\",\"future_frames\":20,\"future_execution_bytes\":" << first.size() << "}\n";
}
static void checkVisibleVideoCorruption(NativeBackend& backend) {
    // A one-byte RTC tile mutation must invalidate the real decoded pattern
    // cache and produce changed pixels, without touching the presentation UI.
    configure(backend, "wram", 0xf000, 0xf000, "zero");
    command(backend, "harvester_start"); command(backend, "harvester_next", "{\"runFrames\":2}"); waitPaused(backend);
    const auto baseline = framebuffer(backend.exportState()); std::set<uint32_t> colors;
    for (size_t at = 0; at < baseline.size(); at += 4)
        colors.insert(uint32_t(baseline[at]) | uint32_t(baseline[at + 1]) << 8
            | uint32_t(baseline[at + 2]) << 16 | uint32_t(baseline[at + 3]) << 24);
    require(colors.size() >= 3, "Native diagnostic does not render its actual colored tiles");
    command(backend, "harvester_discard");
    configure(backend, "vram", 32, 32, "ff"); command(backend, "blast");
    require((bg_name_dirty[1] & 1) && std::find(bg_name_list, bg_name_list + bg_list_index, 1) != bg_name_list + bg_list_index,
            "RTC VRAM write did not dirty the actual decoded tile cache");
    command(backend, "undo");
    // SAT has a separate hardware cache; both the live VRAM and that cache
    // must receive the same logical byte before the sprite parser sees it.
    const auto spriteOffset = uint32_t(satb); const auto spriteBefore = backend.readMemory("vram", spriteOffset, 1);
    configure(backend, "vram", spriteOffset, spriteOffset, "ff"); command(backend, "blast");
    const unsigned addressMask = reg[12] & 1 ? 0x3ff : 0x1ff;
    require(sat[(spriteOffset & addressMask) ^ 1] == 255, "RTC SAT mutation did not update the real sprite attribute cache");
    command(backend, "undo"); require(backend.readMemory("vram", spriteOffset, 1) == spriteBefore, "Undo did not restore the SAT byte");
    command(backend, "harvester_discard");
    configure(backend, "vram", 32, 32, "ff"); command(backend, "harvester_next", "{\"runFrames\":2}"); waitPaused(backend);
    const auto tilePixels = framebuffer(backend.exportState());
    require(tilePixels != baseline, "Live VRAM blast did not change the Genesis framebuffer");
    command(backend, "harvester_discard");
    require(framebuffer(backend.exportState()) == baseline, "Full state restore did not recover the clean Genesis framebuffer");
    // Color 1 is red in the fixture. A logical low-byte FF write turns its
    // R/G components on after the core's 9-bit CRAM packing, changing pixels.
    configure(backend, "cram", 3, 3, "ff"); command(backend, "harvester_next", "{\"runFrames\":2}"); waitPaused(backend);
    const auto palettePixels = framebuffer(backend.exportState());
    require(palettePixels != baseline && palettePixels != tilePixels, "Live CRAM corruption did not update the displayed palette");
    command(backend, "harvester_discard");
    require(framebuffer(backend.exportState()) == baseline, "Rewind/load did not recover the full pre-blast palette frame");
    command(backend, "harvester_stop"); pause(backend);
    std::cout << "{\"check\":\"native_visible_tile_palette_and_sprite_cache_corruption\",\"framebuffer_bytes\":"
        << baseline.size() << ",\"baseline_colors\":" << colors.size() << ",\"vram_pixels_changed\":true,\"cram_pixels_changed\":true}\n";
}
static void checkAutoAndRewind(NativeBackend& backend) {
    command(backend, "rewind_config", "{\"seconds\":15,\"intervalFrames\":2}");
    configure(backend, "wram", 0x9000, 0x903f, "random", 16, true, 3);
    pause(backend, false); std::this_thread::sleep_for(550ms); pause(backend);
    const auto forward = frame(backend);
    const auto historyBefore = command(backend, "history", "{\"includeUnits\":true}")["history"];
    std::set<std::string> seeds; size_t activeBefore = 0;
    for (const auto& record : historyBefore.array) { if (record["active"].flag()) ++activeBefore; seeds.insert(record["seed"].text()); }
    require(historyBefore.array.size() >= 5 && seeds.size() == historyBefore.array.size(), "Native Auto Blast did not use fresh independent random seeds");
    configure(backend, "wram", 0x9000, 0x903f, "random", 16, false, 3);
    const auto cursorBefore = status(backend)["rtc"]["blastCursor"].integer();
    command(backend, "rewind", "{\"held\":true}"); std::this_thread::sleep_for(140ms);
    const auto rewindFrame = frame(backend); std::this_thread::sleep_for(110ms);
    const auto laterRewindFrame = frame(backend);
    require(laterRewindFrame < rewindFrame && rewindFrame < forward, "Held native rewind did not continuously restore previous full states");
    command(backend, "rewind", "{\"held\":false}");
    const auto historyAfter = command(backend, "history")["history"]; size_t activeAfter = 0;
    for (const auto& record : historyAfter.array) activeAfter += record["active"].flag();
    require(activeAfter < activeBefore, "Rewind across RTC blasts left future corruption history active");
    require(status(backend)["rtc"]["blastCursor"].integer() <= cursorBefore, "Rewind increased the history cursor");
    if (activeAfter) command(backend, "undo");
    pause(backend, false); const auto resumed = frame(backend); std::this_thread::sleep_for(100ms); pause(backend);
    require(frame(backend) > resumed && frame(backend) - resumed <= 9, "Release rewind did not resume from restored emulated time");
    const auto state = status(backend); require(state["rewindBytes"].integer() <= 96 * 1024 * 1024, "Native rewind ring exceeded its RAM budget");
    std::cout << "{\"check\":\"native_random_auto_blast_continuous_rewind_history_resume\",\"auto_blasts\":" << historyBefore.array.size()
        << ",\"forward_frame\":" << forward << ",\"restored_frame\":" << laterRewindFrame << ",\"inactive_after_rewind\":" << activeBefore - activeAfter << "}\n";
}

static void speed(NativeBackend& backend, double fastForward, double rewind, bool rewindAudio = true) {
    command(backend, "speed_config", "{\"fastForwardMultiplier\":" + std::to_string(fastForward)
        + ",\"rewindMultiplier\":" + std::to_string(rewind)
        + ",\"rewindAudio\":" + (rewindAudio ? "true" : "false") + "}");
}
static void fastForward(NativeBackend& backend, bool held) {
    command(backend, "fast_forward", held ? "{\"held\":true}" : "{\"held\":false}");
}
static void checkFastForwardClock(NativeBackend& backend, bool pal) {
    pause(backend); configure(backend, "wram", 0xf000, 0xf000, "zero");
    command(backend, "rewind_config", "{\"seconds\":0,\"intervalFrames\":10}");
    speed(backend, 4, 1);
    const double fps = status(backend)["fps"].number;
    const auto firstFrame = frame(backend); auto started = Clock::now(); pause(backend, false); fastForward(backend, true);
    std::this_thread::sleep_for(650ms); pause(backend);
    const double fastSeconds = std::chrono::duration<double>(Clock::now() - started).count();
    const auto fastFrames = frame(backend) - firstFrame;
    require(std::abs(double(fastFrames) - fps * 4 * fastSeconds) <= 7,
            "Held fast-forward does not advance at the selected emulated hardware speed");
    require(std::abs(status(backend)["fps"].number - fps) < 0.00001,
            "Fast-forward changed the core's hardware FPS instead of its worker pace");
    fastForward(backend, false);
    const auto normalStart = frame(backend); started = Clock::now(); pause(backend, false);
    std::this_thread::sleep_for(500ms); pause(backend);
    const double normalSeconds = std::chrono::duration<double>(Clock::now() - started).count();
    const auto normalFrames = frame(backend) - normalStart;
    require(std::abs(double(normalFrames) - fps * normalSeconds) <= 3,
            "Fast-forward release did not restore normal Genesis hardware speed");
    std::cout << "{\"check\":\"native_" << (pal ? "pal" : "ntsc")
        << "_fast_forward_hold_release_clock\",\"hardware_fps\":" << fps
        << ",\"multiplier\":4,\"held_frames\":" << fastFrames << ",\"held_seconds\":" << fastSeconds
        << ",\"released_frames\":" << normalFrames << ",\"released_seconds\":" << normalSeconds << "}\n";
}
static void checkFastForwardAutoFrames(NativeBackend& backend, bool pal) {
    pause(backend); speed(backend, 4, 1);
    const auto oldHistory = command(backend, "history")["history"];
    std::set<int64_t> oldNumbers;
    for (const auto& record : oldHistory.array) oldNumbers.insert(record["number"].integer());
    constexpr unsigned interval = 7;
    configure(backend, "wram", 0xa000, 0xa03f, "random", 4, true, interval);
    const auto firstFrame = frame(backend); pause(backend, false); fastForward(backend, true);
    std::this_thread::sleep_for(650ms); pause(backend);
    const auto lastFrame = frame(backend);
    configure(backend, "wram", 0xa000, 0xa03f, "random", 4, false, interval);
    fastForward(backend, false);
    const auto history = command(backend, "history")["history"];
    std::set<std::string> seeds; std::vector<uint64_t> blastFrames;
    for (const auto& record : history.array) {
        if (oldNumbers.count(record["number"].integer())) continue;
        seeds.insert(record["seed"].text()); blastFrames.push_back(record["frame"].integer());
    }
    require(blastFrames.size() == (lastFrame - firstFrame) / interval,
            "Fast-forward Auto Blast counts wall/display frames instead of emulated frames");
    require(seeds.size() == blastFrames.size(), "Fast-forward Auto Blast reused a random seed");
    for (size_t i = 0; i < blastFrames.size(); ++i)
        require(blastFrames[i] == firstFrame + interval * (i + 1),
                "Auto Blast does not occur at its exact selected emulated-frame interval");
    std::cout << "{\"check\":\"native_" << (pal ? "pal" : "ntsc")
        << "_fast_forward_auto_blast_emulated_frames\",\"interval_frames\":" << interval
        << ",\"emulated_frames\":" << lastFrame - firstFrame << ",\"blasts\":" << blastFrames.size()
        << ",\"fresh_seeds\":" << seeds.size() << "}\n";
}
struct PcmEvidence { size_t nonzero = 0; int peak = 0; std::set<int16_t> values; };
static PcmEvidence consumeAudioFor(NativeBackend& backend, std::chrono::milliseconds duration) {
    PcmEvidence result; std::vector<int16_t> samples(441 * 2);
    const auto end = Clock::now() + duration;
    while (Clock::now() < end) {
        backend.audioCallback(samples.data(), 441);
        for (const auto value : samples) {
            result.nonzero += value != 0; result.peak = std::max(result.peak, std::abs(int(value))); result.values.insert(value);
        }
        std::this_thread::sleep_for(10ms);
    }
    return result;
}
static void fillRewind(NativeBackend& backend, unsigned interval, double multiplier, bool audible) {
    pause(backend); configure(backend, "wram", 0xf000, 0xf000, "zero");
    command(backend, "rewind_config", "{\"seconds\":15,\"intervalFrames\":" + std::to_string(interval) + "}");
    speed(backend, 8, multiplier, audible);
    pause(backend, false); fastForward(backend, true); std::this_thread::sleep_for(800ms); pause(backend); fastForward(backend, false);
    require(status(backend)["rewindAvailable"].number >= 3,
            "Not enough native rewind history was captured for playback validation");
}
static void checkRewindPlayback(NativeBackend& backend, unsigned interval, double multiplier) {
    fillRewind(backend, interval, multiplier, true);
    const auto forwardFrame = frame(backend); const double fps = status(backend)["fps"].number;
    const auto started = Clock::now(); command(backend, "rewind", "{\"held\":true}");
    const auto audio = consumeAudioFor(backend, 400ms);
    command(backend, "rewind", "{\"held\":false}");
    const double seconds = std::chrono::duration<double>(Clock::now() - started).count();
    const auto restoredFrame = frame(backend);
    require(restoredFrame < forwardFrame, "Native rewind did not move backwards");
    const auto rewoundFrames = forwardFrame - restoredFrame;
    require(std::abs(double(rewoundFrames) - fps * multiplier * seconds) <= interval + 5,
            "Rewind speed depends on snapshot frequency instead of the selected emulated-time multiplier");
    require(audio.nonzero > 3000 && audio.peak > 500 && audio.values.size() > 100,
            "Audible rewind does not output actual varied native Genesis PCM");
    require(status(backend)["rewindBytes"].integer() <= 96 * 1024 * 1024,
            "Audible rewind exceeded the native ring's RAM budget");
    backend.audioCallback(std::vector<int16_t>(882).data(), 441);
    const auto beforeResume = frame(backend); pause(backend, false);
    const auto forwardAudio = consumeAudioFor(backend, 220ms); pause(backend);
    require(frame(backend) > beforeResume && frame(backend) - beforeResume <= uint64_t(std::ceil(fps * .23)) + 2,
            "Rewind release changed normal forward emulation speed");
    require(forwardAudio.nonzero > 2000, "Audio did not resume after audible rewind release");
    std::cout << "{\"check\":\"native_audible_rewind_interval_" << interval << "_speed_" << int(multiplier)
        << "\",\"snapshot_interval_frames\":" << interval << ",\"multiplier\":" << multiplier
        << ",\"rewound_frames\":" << rewoundFrames << ",\"wall_seconds\":" << seconds
        << ",\"nonzero_reverse_samples\":" << audio.nonzero << ",\"distinct_reverse_samples\":" << audio.values.size()
        << ",\"reverse_peak\":" << audio.peak << ",\"forward_audio_resumed\":true}\n";
}
static void checkRewindAudioToggle(NativeBackend& backend) {
    fillRewind(backend, 10, 2, false);
    const auto firstFrame = frame(backend); command(backend, "rewind", "{\"held\":true}");
    const auto muted = consumeAudioFor(backend, 250ms);
    command(backend, "rewind", "{\"held\":false}");
    require(frame(backend) < firstFrame, "Muted rewind stopped full native state restoration");
    require(muted.nonzero == 0, "Disabling rewind audio still outputs PCM");
    speed(backend, 4, 1, true);
    std::cout << "{\"check\":\"native_rewind_audio_toggle\",\"muted_samples_nonzero\":" << muted.nonzero
        << ",\"native_state_still_rewound\":true}\n";
}
static void checkReverseStereoOrder(NativeBackend& backend, std::vector<uint8_t> rom) {
    // Change only the original diagnostic driver's YM2612 channel-0 panning
    // register. Actual FM now plays on the left; actual PSG still plays on both.
    // This gives independent channels without synthesizing any test audio.
    bool found = false;
    for (size_t i = 0; i + 14 < 610; ++i) {
        const auto byte = [&rom](size_t z80Address) { return rom.at(0x210 + z80Address * 8 + 3); };
        if (byte(i) == 0x3e && byte(i + 1) == 0xb4 && byte(i + 9) == 0x3e && byte(i + 10) == 0xc0) {
            rom[0x210 + (i + 10) * 8 + 3] = 0x80; found = true; break;
        }
    }
    require(found, "Actual diagnostic Z80 driver's FM panning register was not found");
    uint16_t checksum = 0;
    for (size_t at = 0x200; at + 1 < rom.size(); at += 2) checksum += (uint16_t(rom[at]) << 8) | rom[at + 1];
    rom[0x18e] = uint8_t(checksum >> 8); rom[0x18f] = uint8_t(checksum);
    pause(backend); require(backend.loadRom(rom, "native-stereo-rewind-diagnostic.bin").empty(), "Stereo diagnostic ROM load failed");
    fillRewind(backend, 10, 1, true);
    const auto pcmBytes = backend.exportData("rewind_audio");
    require(pcmBytes.size() > 44100 * 4 && pcmBytes.size() % 4 == 0, "Real core rewind PCM trace is missing");
    std::vector<int16_t> reversed(pcmBytes.size() / 2); size_t asymmetricFrames = 0;
    const auto sample = [&pcmBytes](size_t at) { return int16_t(uint16_t(pcmBytes[at]) | uint16_t(pcmBytes[at + 1]) << 8); };
    for (size_t i = 0; i < pcmBytes.size() / 4; ++i) {
        const auto source = pcmBytes.size() - (i + 1) * 4;
        reversed[i * 2] = sample(source); reversed[i * 2 + 1] = sample(source + 2);
        asymmetricFrames += reversed[i * 2] != reversed[i * 2 + 1];
    }
    require(asymmetricFrames > 1000, "Diagnostic did not generate independent real left/right audio");
    command(backend, "rewind", "{\"held\":true}");
    bool matched = false; size_t verifiedStereoFrames = 0; std::vector<int16_t> packet(441 * 2);
    for (unsigned batch = 0; batch < 45 && !matched; ++batch) {
        backend.audioCallback(packet.data(), 441);
        // A packet may start/end with silence while the consumer primes or the
        // state restore finishes. Compare a complete nonzero stereo segment.
        for (size_t at : {size_t(0), size_t(220), size_t(440)}) {
            const auto first = packet.begin() + at, last = first + 256;
            if (std::count_if(first, last, [](int16_t value) { return value != 0; }) < 240) continue;
            size_t independentFrames = 0;
            for (size_t i = at; i < at + 256; i += 2) independentFrames += packet[i] != packet[i + 1];
            if (independentFrames < 100) continue;
            const auto match = std::search(reversed.begin(), reversed.end(), first, last);
            if (match != reversed.end() && (match - reversed.begin()) % 2 == 0) {
                matched = true; verifiedStereoFrames = 128; break;
            }
        }
        std::this_thread::sleep_for(10ms);
    }
    command(backend, "rewind", "{\"held\":false}");
    require(matched, "Reverse output is not the captured real core PCM in backwards stereo-frame order");
    std::cout << "{\"check\":\"native_rewind_real_pcm_reverse_stereo_order\",\"captured_core_stereo_frames\":" << pcmBytes.size() / 4
        << ",\"asymmetric_core_frames\":" << asymmetricFrames << ",\"exact_reverse_stereo_frames_verified\":" << verifiedStereoFrames
        << ",\"fake_audio_used\":false}\n";
}
static void checkBenchmarkPreservesSession(NativeBackend& backend) {
    pause(backend); const auto clean = backend.exportState();
    const auto history = backend.command("history", "{\"includeUnits\":true}");
    const auto rewindPcm = backend.exportData("rewind_audio"); const auto before = status(backend);
    const auto result = command(backend, "benchmark", "{\"frames\":120}");
    require(result["frames"].integer() == 120 && result["elapsedMs"].number > 0 && result["fps"].number > 0,
            "Benchmark did not report measured performance of actual native emulated frames");
    require(backend.exportState() == clean, "Benchmark changed the complete live native emulator state");
    require(backend.command("history", "{\"includeUnits\":true}") == history,
            "Benchmark changed RTC history");
    const auto after = status(backend);
    for (const auto& field : {"frame", "rewindSnapshots", "rewindBytes", "rewindAudioBytes", "rewindPcmCursor"})
        require(after[field].integer() == before[field].integer(), std::string("Benchmark changed ") + field);
    require(backend.exportData("rewind_audio") == rewindPcm, "Benchmark changed the retained real rewind PCM");
    std::vector<int16_t> samples(882); backend.audioCallback(samples.data(), 441);
    require(std::all_of(samples.begin(), samples.end(), [](auto value) { return value == 0; }),
            "Paused benchmark leaked its PCM into normal playback");
    std::cout << "{\"check\":\"native_benchmark_preserves_state_history_rewind_audio\",\"frames\":120"
        << ",\"measured_seconds\":" << result["elapsedMs"].number / 1000 << ",\"measured_fps\":" << result["fps"].number
        << ",\"full_native_state_preserved\":true,\"benchmark_pcm_suppressed\":true}\n";
}
struct PlaybackEvidence {
    size_t pixelChanges = 0, polls = 0;
    double seconds = 0, longestPixelGapMs = 0, captureP95Ms = 0;
    PcmEvidence pcm;
};
static PlaybackEvidence observeNativePlayback(NativeBackend& backend, std::chrono::milliseconds duration) {
    PlaybackEvidence result;
    const auto start = Clock::now(), finish = start + duration;
    auto lastChange = start, nextAudio = start;
    auto pixels = backend.exportData("framebuffer");
    require(pixels.size() == 320 * 224 * 4, "Read-only native framebuffer capture does not contain the genuine diagnostic pixels");
    auto previous = pixels;
    std::vector<double> captureCosts; std::vector<int16_t> audio(882);
    while (Clock::now() < finish) {
        const auto captureStart = Clock::now(); pixels = backend.exportData("framebuffer");
        captureCosts.push_back(std::chrono::duration<double, std::milli>(Clock::now() - captureStart).count());
        require(pixels.size() == 320 * 224 * 4, "Rewind lost the full native framebuffer");
        ++result.polls;
        const auto now = Clock::now();
        if (pixels != previous) {
            ++result.pixelChanges;
            result.longestPixelGapMs = std::max(result.longestPixelGapMs,
                std::chrono::duration<double, std::milli>(now - lastChange).count());
            lastChange = now; previous = pixels;
        }
        if (now >= nextAudio) {
            backend.audioCallback(audio.data(), 441);
            for (const auto sample : audio) {
                result.pcm.nonzero += sample != 0;
                result.pcm.peak = std::max(result.pcm.peak, std::abs(int(sample)));
                result.pcm.values.insert(sample);
            }
            nextAudio += 10ms;
        }
        std::this_thread::sleep_until(now + 2ms);
    }
    result.seconds = std::chrono::duration<double>(Clock::now() - start).count();
    result.longestPixelGapMs = std::max(result.longestPixelGapMs,
        std::chrono::duration<double, std::milli>(Clock::now() - lastChange).count());
    std::sort(captureCosts.begin(), captureCosts.end());
    require(!captureCosts.empty(), "No native frame was captured during playback");
    result.captureP95Ms = captureCosts[captureCosts.size() * 95 / 100];
    return result;
}
static void requireSmoothNativeFrames(const PlaybackEvidence& evidence, const std::string& context) {
    require(evidence.pixelChanges / evidence.seconds >= 40,
        context + " publishes fewer than 40 different genuine framebuffers per second despite its frame counter advancing (changes="
        + std::to_string(evidence.pixelChanges) + ", seconds=" + std::to_string(evidence.seconds)
        + ", longest pixel gap ms=" + std::to_string(evidence.longestPixelGapMs) + ")");
    require(evidence.longestPixelGapMs < 110,
        context + " freezes the actual native framebuffer for over 110 ms");
    require(evidence.pcm.nonzero > 6000 && evidence.pcm.peak > 500 && evidence.pcm.values.size() > 100,
        context + " does not continuously output actual varied Genesis PCM");
}
static void checkSmoothRewindFrames(NativeBackend& backend, const std::vector<uint8_t>& rom) {
    pause(backend); require(backend.loadRom(animatedROM(rom), "native-vblank-animation.bin").empty(), "Animated diagnostic load failed");
    pause(backend, false); std::this_thread::sleep_for(150ms);
    const auto normal = observeNativePlayback(backend, 1000ms); pause(backend);
    requireSmoothNativeFrames(normal, "Uncorrupted animated diagnostic forward gameplay");
    std::cout << "{\"check\":\"native_actual_vblank_framebuffer_animation\",\"different_pixel_frames\":" << normal.pixelChanges
        << ",\"wall_seconds\":" << normal.seconds << ",\"max_pixel_gap_ms\":" << normal.longestPixelGapMs << "}\n";
    for (unsigned interval : {6U, 15U}) for (double multiplier : {1.0, 2.0, 4.0}) {
        const auto colorBefore = backend.readMemory("wram", 0x100, 2); const auto fillFirst = frame(backend);
        fillRewind(backend, interval, multiplier, true);
        const auto before = status(backend); const auto firstFrame = frame(backend);
        const auto colorAfter = backend.readMemory("wram", 0x100, 2);
        command(backend, "rewind", "{\"held\":true}");
        const auto evidence = observeNativePlayback(backend, 1000ms);
        command(backend, "rewind", "{\"held\":false}");
        const auto after = status(backend); const auto rewound = firstFrame - frame(backend);
        requireSmoothNativeFrames(evidence, "Rewind interval " + std::to_string(interval) + " speed " + std::to_string(multiplier));
        require(std::abs(double(rewound) - before["fps"].number * multiplier * evidence.seconds) <= 5,
            "Smooth native rewind speed is still quantized to the full keyframe interval");
        require(after["rewindFrameRestores"].integer() - before["rewindFrameRestores"].integer() >= 40,
            "Rewind displayed pixels without restoring the actual complete native core on each tick");
        require(after["rewindBytes"].integer() <= 96 * 1024 * 1024,
            "Per-frame native rewind delta/PCM/keyframe allocations exceed the RAM budget");
        require(after["rewindCacheBytes"].integer() > 1024 * 1024 && after["rewindDeltaBytes"].integer() > 0,
            "Smooth rewind lacks its full native state cache or owned reverse delta tape");
        std::cout << "{\"check\":\"native_smooth_full_rewind_interval_" << interval << "_speed_" << int(multiplier)
            << "\",\"different_pixel_frames\":" << evidence.pixelChanges << ",\"wall_seconds\":" << evidence.seconds
            << ",\"max_pixel_gap_ms\":" << evidence.longestPixelGapMs << ",\"capture_p95_ms\":" << evidence.captureP95Ms
            << ",\"rewound_frames\":" << rewound << ",\"complete_core_restores\":"
            << after["rewindFrameRestores"].integer() - before["rewindFrameRestores"].integer()
            << ",\"nonzero_reverse_samples\":" << evidence.pcm.nonzero
            << ",\"source_frames\":" << firstFrame - fillFirst
            << ",\"source_palette_counter_delta\":" << uint16_t(((colorAfter[0] << 8) | colorAfter[1]) - ((colorBefore[0] << 8) | colorBefore[1]))
            << ",\"rewind_restore_max_ms\":" << after["rewindRestoreMaxMs"].number
            << ",\"rewind_capture_max_ms\":" << after["rewindCaptureMaxMs"].number
            << ",\"actual_rewind_ram_bytes\":" << after["rewindBytes"].integer() << "}\n";
    }
}
static void checkQuickBlastWhilePlaying(NativeBackend& backend) {
    pause(backend); configure(backend, "wram", 0xa800, 0xabff, "random", 64);
    auto expected = backend.readMemory("wram", 0xa800, 1024); std::vector<uint8_t> previous;
    const auto original = backend.exportData("original");
    const auto initial = frame(backend); pause(backend, false);
    std::set<std::string> seeds; double longestMs = 0;
    for (unsigned blast = 0; blast < 3; ++blast) {
        previous = expected; const auto started = Clock::now();
        command(backend, "blast", "{\"quick\":true}");
        longestMs = std::max(longestMs, std::chrono::duration<double, std::milli>(Clock::now() - started).count());
        const auto history = command(backend, "history", "{\"includeUnits\":true}")["history"];
        require(!history.array.empty(), "Quick gameplay Blast did not record native RTC history");
        const auto& record = history.array.back(); seeds.insert(record["seed"].text());
        require(record["random"].flag() && !record["automatic"].flag() && record["active"].flag(),
            "Quick gameplay Blast is not a fresh random manual live-memory operation");
        require(record["units"].array.size() == 64, "Quick Blast ignored the selected RTC intensity");
        for (const auto& unit : record["units"].array) {
            const auto address = unit["address"].integer();
            require(unit["domain"].text() == "wram" && address >= 0xa800 && address <= 0xabff,
                "Quick Blast ignored the selected native domain/address range");
            require(unit["previous"].integer() == expected.at(address - 0xa800)
                && unit["blast"].integer() == record["number"].integer() && unit["engine"].text() == "random",
                "Quick Blast history does not record its real previous byte, engine and blast number");
            expected[address - 0xa800] = uint8_t(unit["value"].integer());
        }
        require(expected != previous && backend.readMemory("wram", 0xa800, 1024) == expected,
            "Quick gameplay Blast did not mutate the selected live core memory");
        require(!status(backend)["paused"].flag(), "Quick Blast paused gameplay");
        std::this_thread::sleep_for(70ms);
    }
    require(seeds.size() == 3, "Quick gameplay Blast reused a fixed seed");
    command(backend, "undo"); require(backend.readMemory("wram", 0xa800, 1024) == previous,
        "Quick Blast cannot be undone by directly restoring its previous live bytes");
    const auto resumedAudio = consumeAudioFor(backend, 120ms); pause(backend);
    require(frame(backend) > initial + 10 && status(backend)["error"].text().empty(),
        "Quick Blast stalls or stops the native gameplay worker");
    require(backend.exportData("original") == original, "Quick Blast changed the original ROM");
    require(resumedAudio.nonzero > 2000 && resumedAudio.values.size() > 100,
        "Quick gameplay Blast interrupted real native Genesis audio");
    std::cout << "{\"check\":\"native_quick_blast_playing_random_history_live_undo\",\"fresh_seeds\":" << seeds.size()
        << ",\"manual_blasts\":3,\"byte_writes_each\":64,\"longest_command_ms\":" << longestMs
        << ",\"nonzero_forward_samples\":" << resumedAudio.nonzero
        << ",\"gameplay_continued\":true,\"original_rom_preserved\":true}\n";
}
static void checkRewindFutureAcrossBlasts(NativeBackend& backend) {
    pause(backend); command(backend, "rewind_config", "{\"seconds\":15,\"intervalFrames\":15}");
    speed(backend, 4, 2, true); configure(backend, "wram", 0x9000, 0x903f, "random", 8, true, 3);
    const auto start = frame(backend); pause(backend, false); std::this_thread::sleep_for(800ms); pause(backend);
    configure(backend, "wram", 0x9000, 0x903f, "random", 8, false, 3);
    const auto historyBefore = command(backend, "history")["history"];
    command(backend, "rewind", "{\"held\":true}"); const auto audio = consumeAudioFor(backend, 230ms);
    command(backend, "rewind", "{\"held\":false}");
    require(frame(backend) > start && audio.nonzero > 3000, "RTC rewind lost its genuine state/audio timeline");
    const auto restored = frame(backend); const auto cursor = status(backend)["rtc"]["blastCursor"].integer();
    const auto after = command(backend, "history")["history"]; size_t inactive = 0;
    for (const auto& record : after.array) {
        if (record["active"].flag()) require(record["frame"].integer() <= int64_t(restored)
            && record["number"].integer() <= cursor, "Rewind left a future native corruption record active");
        else if (record["frame"].integer() > int64_t(restored)) ++inactive;
    }
    require(inactive >= 3 && historyBefore.array.size() == after.array.size(),
        "Rewind across native RTC blasts lost history or failed to deactivate future corruptions");
    const auto checkpoint = backend.exportState();
    configure(backend, "wram", 0xf000, 0xf000, "zero");
    command(backend, "harvester_start"); command(backend, "harvester_next", "{\"runFrames\":20}"); waitPaused(backend);
    const auto first = executionPayload(backend.exportState()); const auto debug = backend.command("debug", "{}");
    command(backend, "harvester_stop"); pause(backend);
    require(backend.importState(checkpoint).empty(), "Released rewind full native checkpoint failed to reload");
    command(backend, "harvester_start"); command(backend, "harvester_next", "{\"runFrames\":20}"); waitPaused(backend);
    require(executionPayload(backend.exportState()) == first && backend.command("debug", "{}") == debug,
        "After release across RTC blasts, rewind did not preserve exact future CPU/Z80/VDP/FM/PSG/pad/SRAM/ROM/framebuffer execution");
    command(backend, "harvester_stop"); pause(backend);
    std::cout << "{\"check\":\"native_smooth_rewind_exact_future_across_rtc_blasts\",\"future_frames\":20,\"inactive_future_blasts\":"
        << inactive << ",\"future_execution_bytes\":" << first.size() << ",\"full_future_payload_identical\":true}\n";
}
static void checkLongRewindTape(NativeBackend& backend) {
    pause(backend); configure(backend, "wram", 0xf000, 0xf000, "zero");
    command(backend, "rewind_config", "{\"seconds\":120,\"intervalFrames\":15}"); speed(backend, 8, 16, true);
    pause(backend, false); fastForward(backend, true);
    const auto deadline = Clock::now() + 45s;
    while (status(backend)["rewindAvailable"].number < 110 && Clock::now() < deadline) std::this_thread::sleep_for(250ms);
    pause(backend); fastForward(backend, false); const auto full = status(backend);
    require(full["rewindAvailable"].number >= 110, "Actual 120-second native rewind tape could not retain near-full diagnostic history");
    require(full["rewindAudioBytes"].integer() > 110 * 44100 * 4,
        "Long native rewind history does not retain its real core PCM");
    command(backend, "rewind", "{\"held\":true}");
    // Scrub far into the tape before measuring ordinary playback. The previous
    // audio implementation rescanned backwards from the newest PCM segment on
    // every tick, so a short history could conceal a history-length-dependent
    // cost. This traverses actual full states and their original audio.
    const auto scrub = consumeAudioFor(backend, 4800ms); const auto middle = status(backend);
    require(full["frame"].integer() - middle["frame"].integer() >= 60 * full["fps"].number,
        "Long-history rewind cannot scrub through actual native emulated time");
    speed(backend, 8, 2, true); const auto evidence = observeNativePlayback(backend, 1000ms);
    command(backend, "rewind", "{\"held\":false}"); const auto after = status(backend);
    requireSmoothNativeFrames(evidence, "Near-full 120-second history after a long reverse scrub");
    require(scrub.nonzero > 10000 && after["rewindBytes"].integer() <= 96 * 1024 * 1024,
        "Long native rewind audio or actual allocation limit failed");
    std::cout << "{\"check\":\"native_120_second_rewind_long_tape_pcm_smoothness\",\"history_seconds\":" << full["rewindAvailable"].number
        << ",\"long_scrub_native_frames\":" << full["frame"].integer() - middle["frame"].integer()
        << ",\"different_pixel_frames\":" << evidence.pixelChanges << ",\"wall_seconds\":" << evidence.seconds
        << ",\"max_pixel_gap_ms\":" << evidence.longestPixelGapMs << ",\"capture_p95_ms\":" << evidence.captureP95Ms
        << ",\"nonzero_reverse_samples\":" << evidence.pcm.nonzero
        << ",\"rewind_restore_max_ms\":" << after["rewindRestoreMaxMs"].number
        << ",\"actual_rewind_ram_bytes\":" << after["rewindBytes"].integer() << "}\n";
}
int main(int argc, char** argv) {
    try {
        require(argc == 2 || (argc == 3 && std::string(argv[2]) == "--rewind-regressions"),
            "Usage: backend-validation diagnostic.bin [--rewind-regressions]");
        const auto rom = readFile(argv[1]);
        const std::string directory = "/tmp/badgenesis-native-backend-" + std::to_string(Clock::now().time_since_epoch().count());
        std::filesystem::create_directories(directory);
        {
            NativeBackend backend(directory);
            if (argc == 2) {
            checkClock(backend, rom, false); checkAudioAndInput(backend);
            checkLiveDomainsAndState(backend, rom); checkFutureReplay(backend); checkVisibleVideoCorruption(backend); checkAutoAndRewind(backend);
            checkFastForwardClock(backend, false); checkFastForwardAutoFrames(backend, false);
            for (unsigned interval : {2U, 15U}) for (double multiplier : {1.0, 4.0}) checkRewindPlayback(backend, interval, multiplier);
            checkRewindAudioToggle(backend);
            checkClock(backend, palROM(rom), true); checkAudioAndInput(backend);
            checkFastForwardClock(backend, true); checkFastForwardAutoFrames(backend, true);
            checkReverseStereoOrder(backend, rom);
            checkBenchmarkPreservesSession(backend);
            }
            checkSmoothRewindFrames(backend, rom);
            checkQuickBlastWhilePlaying(backend);
            checkRewindFutureAcrossBlasts(backend);
            checkLongRewindTape(backend);
        }
        std::filesystem::remove_all(directory);
        std::cout << "{\"check\":\"production_native_worker_validation_complete\",\"passed\":true,\"phone_performance_tested\":false}\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "Native backend validation failed: " << error.what() << '\n'; return 1;
    }
}

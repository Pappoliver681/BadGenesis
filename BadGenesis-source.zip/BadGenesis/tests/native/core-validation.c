/* Real upstream Genesis Plus GX validation against our public-domain ROM.
 * Commercial Sonic ROMs are deliberately not included or downloaded. */
#define _POSIX_C_SOURCE 200809L
#ifdef NDEBUG
#undef NDEBUG
#endif
#include <assert.h>
#include <math.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "libretro.h"
#include "vendor_adapter.h"
#include "shared.h"
#include "gamepad.h"
#undef FILE
#undef fopen
#undef fclose
#undef fread
#undef fseek
#undef ftell
#undef fprintf

extern uint8_t work_ram[0x10000], zram[0x2000];
extern uint8_t vram[0x10000], cram[0x80], vsram[0x80];

static const char *region_option = "auto";
static uint16_t buttons;
static size_t audio_frames, audio_nonzero, video_frames;
static uint64_t audio_hash, video_hash;
static unsigned last_width, last_height;
static int16_t peak;
static int capture;
static struct retro_game_info_ext game_ext;
static size_t positive_crossings;
static int previous_sample;

static uint64_t hash_bytes(uint64_t hash, const void *ptr, size_t size) {
    const uint8_t *bytes = ptr;
    size_t i;
    for (i = 0; i < size; ++i) hash = (hash ^ bytes[i]) * UINT64_C(1099511628211);
    return hash;
}

static bool environment(unsigned command, void *data) {
    switch (command) {
    case RETRO_ENVIRONMENT_GET_GAME_INFO_EXT:
        *(const struct retro_game_info_ext **)data = &game_ext; return true;
    case RETRO_ENVIRONMENT_GET_VARIABLE: {
        struct retro_variable *variable = data;
        variable->value = NULL;
        if (!strcmp(variable->key, "genesis_plus_gx_region_detect"))
            variable->value = region_option;
        else if (!strcmp(variable->key, "genesis_plus_gx_audio_filter"))
            variable->value = "disabled";
        else if (!strcmp(variable->key, "genesis_plus_gx_blargg_ntsc_filter"))
            variable->value = "disabled";
        else if (!strcmp(variable->key, "genesis_plus_gx_lcd_filter"))
            variable->value = "disabled";
        else if (!strcmp(variable->key, "genesis_plus_gx_bios"))
            variable->value = "disabled";
        return variable->value != NULL;
    }
    case RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE:
        *(bool *)data = false; return true;
    case RETRO_ENVIRONMENT_GET_AUDIO_VIDEO_ENABLE:
        *(int *)data = 3; return true;
    case RETRO_ENVIRONMENT_GET_CORE_OPTIONS_VERSION:
        *(unsigned *)data = 0; return true;
    case RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY:
    case RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY:
        *(const char **)data = "/tmp"; return true;
    case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT:
        return *(unsigned *)data == RETRO_PIXEL_FORMAT_RGB565;
    case RETRO_ENVIRONMENT_SET_VARIABLES:
    case RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS:
    case RETRO_ENVIRONMENT_SET_CONTROLLER_INFO:
    case RETRO_ENVIRONMENT_SET_CONTENT_INFO_OVERRIDE:
    case RETRO_ENVIRONMENT_SET_MEMORY_MAPS:
    case RETRO_ENVIRONMENT_SET_SYSTEM_AV_INFO:
    case RETRO_ENVIRONMENT_SET_GEOMETRY:
    case RETRO_ENVIRONMENT_SET_PERFORMANCE_LEVEL:
    case RETRO_ENVIRONMENT_SET_SERIALIZATION_QUIRKS:
    case RETRO_ENVIRONMENT_SET_DISK_CONTROL_INTERFACE:
        return true;
    default: return false;
    }
}

static void video(const void *data, unsigned width, unsigned height, size_t pitch) {
    unsigned row;
    if (!data) return;
    video_frames++;
    last_width = width; last_height = height;
    if (capture)
        for (row = 0; row < height; ++row)
            video_hash = hash_bytes(video_hash, (const uint8_t *)data + row * pitch, width * 2);
}

static size_t audio(const int16_t *data, size_t frames) {
    size_t i;
    audio_frames += frames;
    if (capture) audio_hash = hash_bytes(audio_hash, data, frames * 4);
    for (i = 0; i < frames * 2; ++i) {
        int value = data[i] < 0 ? -data[i] : data[i];
        audio_nonzero += value != 0;
        if (value > peak) peak = value > 32767 ? 32767 : value;
        if (!(i & 1)) {
            positive_crossings += previous_sample < 0 && data[i] >= 0;
            previous_sample = data[i];
        }
    }
    return frames;
}

static void input_poll(void) {}
static int16_t input_state(unsigned port, unsigned device, unsigned index, unsigned id) {
    (void)index;
    return port == 0 && device == RETRO_DEVICE_JOYPAD && id < 16 && (buttons & (1U << id)) ? 1 : 0;
}

static double now(void) {
    struct timespec value;
    assert(clock_gettime(CLOCK_MONOTONIC, &value) == 0);
    return value.tv_sec + value.tv_nsec / 1e9;
}

static void run_frames(unsigned count) {
    unsigned i;
    for (i = 0; i < count; ++i) retro_run();
}

static void begin_capture(void) {
    audio_frames = audio_nonzero = video_frames = 0;
    audio_hash = video_hash = UINT64_C(1469598103934665603);
    peak = 0;
    positive_crossings = 0; previous_sample = 0;
    capture = 1;
}

static uint8_t ram_byte(size_t address) { return work_ram[address ^ 1]; }

static void verify_gamepad_protocol(void) {
    uint16_t prior_input = input.pad[0];
    size_t size = bg_gamepad_size();
    uint8_t *saved = malloc(size);
    unsigned i;
    uint8_t expected[6], restored[6];
    assert(saved);
    input.pad[0] = INPUT_MODE | INPUT_X | INPUT_Y | INPUT_Z;
    gamepad_reset(0);
    /* Capture the 6-button protocol in the middle of its TH handshake. */
    gamepad_1_write(0, 0x40); gamepad_1_write(0x40, 0x40);
    gamepad_1_write(0, 0x40); gamepad_1_write(0x40, 0x40);
    gamepad_1_write(0, 0x40);
    assert(bg_gamepad_save(saved, size));
    for (i = 0; i < 6; ++i) {
        gamepad_1_write((i & 1) ? 0 : 0x40, 0x40);
        expected[i] = gamepad_1_read();
    }
    assert((expected[0] & 15) == 0); /* MODE/X/Y/Z held on fourth TH high */
    assert(bg_gamepad_load(saved, size));
    for (i = 0; i < 6; ++i) {
        gamepad_1_write((i & 1) ? 0 : 0x40, 0x40);
        restored[i] = gamepad_1_read();
    }
    assert(!memcmp(expected, restored, sizeof(expected)));
    saved[0] ^= 1;
    assert(!bg_gamepad_load(saved, size));
    gamepad_reset(0); input.pad[0] = prior_input;
    printf("{\"check\":\"native_six_button_handshake_snapshot\",\"state_bytes\":%zu,\"extra_buttons_held\":true,\"future_protocol_exact\":true}\n", size);
    free(saved);
}

static void verify_state(void) {
    size_t core_size = retro_serialize_size(), sound_size = bg_sound_size();
    uint8_t *core_a = calloc(1, core_size), *core_b = calloc(1, core_size);
    uint8_t *sound_a = malloc(sound_size), *sound_b = malloc(sound_size);
    size_t pad_size = bg_gamepad_size();
    uint8_t *pad_a = malloc(pad_size), *pad_b = malloc(pad_size);
    uint8_t original[0x10000], future[0x10000];
    uint64_t future_audio, future_video;
    size_t future_samples;
    uint32_t pref_address = m68k.pref_addr, pref_data = m68k.pref_data, instruction = m68k.ir;
    int refresh = m68k.refresh_cycles;
    assert(core_a && core_b && sound_a && sound_b && pad_a && pad_b);
    assert(retro_serialize(core_a, core_size));
    assert(bg_sound_save(sound_a, sound_size));
    assert(bg_gamepad_save(pad_a, pad_size));
    memcpy(original, work_ram, sizeof(original));
    begin_capture(); run_frames(30);
    future_audio = audio_hash; future_video = video_hash; future_samples = audio_frames;
    memcpy(future, work_ram, sizeof(future));
    uint32_t pref_address_b = m68k.pref_addr, pref_data_b = m68k.pref_data, instruction_b = m68k.ir;
    int refresh_b = m68k.refresh_cycles;
    /* Capture a second state to prove the first owns its sound tails rather
     * than being overwritten by the core's global scratch audio snapshot. */
    assert(retro_serialize(core_b, core_size));
    assert(bg_sound_save(sound_b, sound_size));
    assert(bg_gamepad_save(pad_b, pad_size));
    work_ram[42] ^= 0xff; zram[500] ^= 0xa5; vram[400] ^= 0xff;
    assert(retro_unserialize(core_a, core_size));
    m68k.pref_addr = pref_address; m68k.pref_data = pref_data; m68k.ir = instruction;
    m68k.refresh_cycles = refresh;
    assert(bg_sound_load(sound_a, sound_size));
    assert(bg_gamepad_load(pad_a, pad_size));
    assert(!memcmp(original, work_ram, sizeof(original)));
    begin_capture(); run_frames(30);
    assert(audio_frames == future_samples);
    assert(audio_hash == future_audio);
    assert(video_hash == future_video);
    if (memcmp(future, work_ram, sizeof(future))) {
        for (size_t i = 0; i < sizeof(future); ++i) if (future[i] != work_ram[i]) {
            fprintf(stderr, "future RAM divergence offset=%zu expected=%02x actual=%02x\n", i, future[i], work_ram[i]); break;
        }
    }
    assert(!memcmp(future, work_ram, sizeof(future)));
    assert(retro_unserialize(core_b, core_size));
    m68k.pref_addr = pref_address_b; m68k.pref_data = pref_data_b; m68k.ir = instruction_b;
    m68k.refresh_cycles = refresh_b;
    assert(bg_sound_load(sound_b, sound_size));
    assert(bg_gamepad_load(pad_b, pad_size));
    assert(!memcmp(future, work_ram, sizeof(future)));
    sound_a[0] ^= 1;
    assert(!bg_sound_load(sound_a, sound_size));
    printf("{\"check\":\"full_native_state_and_independent_audio_snapshots\",\"core_bytes\":%zu,\"sound_extra_bytes\":%zu,\"future_pcm_exact\":true,\"future_framebuffer_exact\":true}\n", core_size, sound_size);
    free(core_a); free(core_b); free(sound_a); free(sound_b);
    free(pad_a); free(pad_b);
}

static void verify_region(const uint8_t *rom, size_t rom_size, bool pal) {
    struct retro_game_info game = { .path = "/tmp/badgenesis-native-diagnostic.bin", .data = rom, .size = rom_size, .meta = NULL };
    struct retro_system_av_info av;
    double segments[3], begin, expected_audio;
    unsigned segment;
    region_option = pal ? "pal" : "ntsc-u";
    buttons = 0;
    memset(&game_ext, 0, sizeof(game_ext));
    game_ext.full_path = game.path;
    game_ext.dir = "/tmp";
    game_ext.name = "badgenesis-native-diagnostic";
    game_ext.ext = "bin";
    game_ext.data = rom;
    game_ext.size = rom_size;
    assert(retro_load_game(&game));
    retro_set_controller_port_device(0, RETRO_DEVICE_SUBCLASS(RETRO_DEVICE_JOYPAD, 1));
    run_frames(20);
    retro_get_system_av_info(&av);
    assert(retro_get_region() == (pal ? RETRO_REGION_PAL : RETRO_REGION_NTSC));
    assert(fabs(av.timing.fps - (pal ? 49.701459 : 59.922743)) < 0.001);
    assert(av.timing.sample_rate == 44100);
    assert(retro_get_memory_size(RETRO_MEMORY_SYSTEM_RAM) == 65536);
    if (zram[0x1ff0] != 0x42) fprintf(stderr, "Z80 signature=%02x driver0=%02x %02x %02x %02x framebuffer=%ux%u pad=%02x\n", zram[0x1ff0], zram[0], zram[1], zram[2], zram[3], last_width, last_height, ram_byte(0));
    assert(zram[0x1ff0] == 0x42);
    assert(last_width == 320 && last_height == 224);
    assert((ram_byte(0) & 0x3f) == 0x3f);
    buttons = (1U << RETRO_DEVICE_ID_JOYPAD_B) | (1U << RETRO_DEVICE_ID_JOYPAD_RIGHT) | (1U << RETRO_DEVICE_ID_JOYPAD_UP);
    run_frames(2);
    assert((ram_byte(0) & 0x19) == 0); /* up + right + Genesis B */
    buttons = 0;
    begin_capture();
    for (segment = 0; segment < 3; ++segment) {
        begin = now(); run_frames(200); segments[segment] = now() - begin;
    }
    expected_audio = 600 * av.timing.sample_rate / av.timing.fps;
    assert(fabs((double)audio_frames - expected_audio) < 3);
    assert(video_frames == 600);
    assert(audio_nonzero > audio_frames && peak > 1000);
    assert(segments[2] < segments[0] * 2.5 + 0.2);
    printf("{\"check\":\"native_%s_cpu_z80_input_video_audio\",\"fps\":%.9f,\"sample_rate\":%.0f,\"frames\":600,\"audio_frames\":%zu,\"peak\":%d,\"framebuffer\":\"%ux%u RGB565\",\"wall_seconds\":[%.6f,%.6f,%.6f],\"rtc_off\":true}\n", pal ? "pal" : "ntsc", av.timing.fps, av.timing.sample_rate, audio_frames, peak, last_width, last_height, segments[0], segments[1], segments[2]);
    verify_gamepad_protocol();
    verify_state();
    retro_unload_game();
}

static void verify_sound_sources(const uint8_t *original, size_t size) {
    uint8_t *rom = malloc(size);
    unsigned fm_only, i;
    assert(rom);
    for (fm_only = 0; fm_only < 2; ++fm_only) {
        struct retro_game_info game = { .path = "/tmp/badgenesis-sound-diagnostic.bin", .data = rom, .size = size, .meta = NULL };
        bool keyon_found = false;
        memcpy(rom, original, size);
        /* 610 Z80 driver bytes are emitted by actual MOVE.B immediate stores
         * beginning at 0x210. Silence exactly one real chip via its register;
         * all output still comes from Genesis Plus GX's native sound cores. */
        if (fm_only) rom[0x210 + 15 * 8 + 3] = 0x9f;
        else {
            for (i = 0; i + 14 < 610; ++i) {
                if (rom[0x210 + i * 8 + 3] == 0x3e &&
                    rom[0x210 + (i + 1) * 8 + 3] == 0x28 &&
                    rom[0x210 + (i + 9) * 8 + 3] == 0x3e &&
                    rom[0x210 + (i + 10) * 8 + 3] == 0xf0) {
                    rom[0x210 + (i + 10) * 8 + 3] = 0;
                    keyon_found = true; break;
                }
            }
            assert(keyon_found);
        }
        region_option = "ntsc-u";
        memset(&game_ext, 0, sizeof(game_ext));
        game_ext.full_path = game.path; game_ext.dir = "/tmp";
        game_ext.name = "badgenesis-sound-diagnostic"; game_ext.ext = "bin";
        game_ext.data = rom; game_ext.size = size;
        assert(retro_load_game(&game));
        run_frames(20); begin_capture(); run_frames(120);
        assert(peak > 100 && audio_nonzero > audio_frames);
        double frequency = positive_crossings * 44100.0 / audio_frames;
        if (!fm_only) assert(fabs(frequency - (53693175.0 / 15 / 32 / 261)) < 2);
        printf("{\"check\":\"native_%s_audio_independent\",\"audio_frames\":%zu,\"peak\":%d,\"measured_fundamental_hz\":%.3f}\n", fm_only ? "ym2612_fm" : "sn76489_psg", audio_frames, peak, frequency);
        verify_state();
        retro_unload_game();
    }
    free(rom);
}

int main(int argc, char **argv) {
    FILE *file;
    uint8_t *rom;
    long length;
    setvbuf(stdout, NULL, _IONBF, 0);
    assert(argc == 2);
    file = fopen(argv[1], "rb"); assert(file);
    assert(fseek(file, 0, SEEK_END) == 0); length = ftell(file);
    assert(length > 0 && fseek(file, 0, SEEK_SET) == 0);
    rom = malloc((size_t)length); assert(rom);
    assert(fread(rom, 1, (size_t)length, file) == (size_t)length); fclose(file);
    retro_set_environment(environment);
    retro_set_video_refresh(video);
    retro_set_audio_sample_batch(audio);
    retro_set_input_poll(input_poll);
    retro_set_input_state(input_state);
    retro_init();
    verify_region(rom, (size_t)length, false);
    verify_region(rom, (size_t)length, true);
    verify_sound_sources(rom, (size_t)length);
    retro_deinit();
    free(rom);
    return 0;
}

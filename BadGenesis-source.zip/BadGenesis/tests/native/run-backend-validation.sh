#!/usr/bin/env bash
set -Eeuo pipefail
BG_PROJECT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/../.." && pwd)"
BG_VENDOR="$BG_PROJECT/vendor/genesis-plus-gx"
BG_NATIVE="$BG_PROJECT/app/src/main/cpp"
BG_BUILD="$BG_PROJECT/test-results/native-backend-host"
mkdir -p "$BG_BUILD"
BG_INCLUDE=("-I$BG_NATIVE" "-I$BG_VENDOR/libretro" "-I$BG_VENDOR/libretro/libretro-common/include" "-I$BG_VENDOR/libretro/deps/zlib-1.2.11")
for BG_CORE_DIR in core core/z80 core/m68k core/ntsc core/sound core/sound/minimp3 core/input_hw core/cd_hw core/cart_hw core/cart_hw/svp core/sound/tremor; do
  BG_INCLUDE+=("-I$BG_VENDOR/$BG_CORE_DIR")
done
BG_DEFINES=(-DLSB_FIRST -DBYTE_ORDER=LITTLE_ENDIAN -D__LIBRETRO__ -DUSE_LIBRETRO_VFS -DUSE_LIBTREMOR -DUSE_16BPP_RENDERING -DFRONTEND_SUPPORTS_RGB565 -DHAVE_YM3438_CORE -DHAVE_OPLL_CORE -DMAXROMSIZE=33554432 -DM68K_OVERCLOCK_SHIFT=20 -DZ80_OVERCLOCK_SHIFT=20 '-DINLINE=static inline')
if [[ ! -f "$BG_VENDOR/genesis_plus_gx_libretro.so" ]]; then
  printf 'Build the actual pinned core with Makefile.libretro before the host validation.\n' >&2
  exit 1
fi
gcc -std=gnu11 -O2 "${BG_INCLUDE[@]}" "${BG_DEFINES[@]}" -c "$BG_NATIVE/vendor_adapter.c" -o "$BG_BUILD/vendor_adapter.o"
python3 - "$BG_VENDOR/core/input_hw/gamepad.c" "$BG_NATIVE/gamepad_snapshot.inc" "$BG_BUILD/gamepad-snapshot.c" <<'PY'
import pathlib, sys
source, supplement, output = map(pathlib.Path, sys.argv[1:])
output.write_text(source.read_text()+'\n'+supplement.read_text())
PY
gcc -std=gnu11 -O2 "${BG_INCLUDE[@]}" "${BG_DEFINES[@]}" -c "$BG_BUILD/gamepad-snapshot.c" -o "$BG_BUILD/gamepad-snapshot.o"
g++ -std=c++17 -O2 -Wall -Wextra "${BG_INCLUDE[@]}" "${BG_DEFINES[@]}" \
  "$BG_PROJECT/tests/native/backend-validation.cpp" "$BG_NATIVE/native_backend.cpp" "$BG_NATIVE/rtc_engine.cpp" \
  "$BG_BUILD/vendor_adapter.o" "$BG_BUILD/gamepad-snapshot.o" "$BG_VENDOR/genesis_plus_gx_libretro.so" -lz -lm -pthread -Wl,--export-dynamic \
  "-Wl,-rpath,$BG_VENDOR" -o "$BG_BUILD/backend-validation"
"$BG_BUILD/backend-validation" "$BG_PROJECT/tests/native/native-diagnostic.bin" | tee "$BG_PROJECT/test-results/native-backend-validation.jsonl"

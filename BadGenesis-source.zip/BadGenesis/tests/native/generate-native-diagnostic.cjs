/* Native hardware diagnostic derived from the original public-domain test
 * fixture. Genesis hardware only grants the M68000 access to Z80 RAM with
 * reset released AND the bus requested. Hold BUSREQ, release RESET, upload
 * the driver, then release BUSREQ. The prototype fixture uploaded under
 * asserted RESET, which the actual Genesis Plus GX bus correctly rejects. */
const fs = require('node:fs');
const path = require('node:path');
const { makeDiagnosticROM } = require('../generate-diagnostic.cjs');
const { rom, ...metadata } = makeDiagnosticROM();
if (rom.readUInt16BE(0x208) !== 0x33fc || rom.readUInt32BE(0x20c) !== 0xa11200)
  throw new Error('The public-domain diagnostic bus sequence changed');
rom.writeUInt16BE(0x0100, 0x20a);
let checksum = 0;
for (let i = 0x200; i + 1 < rom.length; i += 2)
  checksum = (checksum + rom.readUInt16BE(i)) & 65535;
rom.writeUInt16BE(checksum, 0x18e);
const output = path.join(__dirname, 'native-diagnostic.bin');
fs.writeFileSync(output, rom);
console.log(JSON.stringify({ output, ...metadata, busSequence: 'BUSREQ -> release RESET -> upload -> release BUSREQ' }));

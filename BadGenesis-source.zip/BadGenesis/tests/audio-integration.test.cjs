'use strict';
const assert=require('node:assert/strict');
const test=require('node:test');
const {loadProject}=require('./dom-harness.cjs');
const {makeDiagnosticROM}=require('./generate-diagnostic.cjs');
function project(){const p=loadProject({audio:true,native:true,stripRetiredVideoHook:true});p.context.testROM=new Uint8Array(makeDiagnosticROM().rom);p.run("machine.loadROM(testROM,'diagnostic.bin');machine.power(true);for(let i=0;i<4;i++)machine.runFrame()");p.json=code=>JSON.parse(p.run(`JSON.stringify(${code})`));p.frames=n=>p.run(`for(let i=0;i<${n};i++)machine.runFrame()`);return p;}
function pcmCalls(p){return p.nativeCalls.filter(c=>c[0]==='audio:writePCM').map(c=>Buffer.from(c[1],'base64'));}
function pcmValues(buffer){return Array.from({length:buffer.length/2},(_,i)=>buffer.readInt16LE(i*2));}

test('diagnostic executes the real Z80 sound program and produces native FM/PSG stereo PCM',()=>{
 const p=project();assert.equal(p.run('machine.bus.zram[0x1ff0]'),0x42);assert.ok(p.run('machine.audio.totalZ80Cycles')>100000);assert.equal(p.run('machine.bus.ym[0xa0]'),0x69);assert.deepEqual(p.json('machine.audio.psg.tone'),[0x105,0,0]);
 const buffers=pcmCalls(p);assert.equal(buffers.length,4);assert.ok(buffers.every(b=>b.length>=2800&&b.length<=3100));const samples=pcmValues(Buffer.concat(buffers));assert.ok(samples.some(v=>v!==0));assert.ok(new Set(samples).size>500,'actual FM plus PSG must produce varying PCM');assert.ok(samples.every(v=>Number.isFinite(v)&&v>=-32768&&v<=32767));
});

test('SN76489 divider frequency, volume latch, noise and chip state replay are functional',()=>{
 const p=project();p.run('globalThis.psg=new GenesisPSG(3579545);psg.write(0x85);psg.write(0x10);psg.write(0x90)');
 const signal=p.json('Array.from({length:44100},()=>psg.sample(44100))');let crossings=0;for(let i=1;i<signal.length;i++)if(signal[i-1]<0&&signal[i]>=0)crossings++;assert.ok(Math.abs(crossings-3579545/(32*261))<2,`tone cycles ${crossings}`);
 p.run('globalThis.psgState=psg.state();globalThis.psgNext=Array.from({length:500},()=>psg.sample(44100));psg.loadState(psgState)');assert.deepEqual(p.json('Array.from({length:500},()=>psg.sample(44100))'),p.json('psgNext'));
 p.run('psg.write(0x9f)');assert.ok(p.json('Array.from({length:100},()=>psg.sample(44100))').every(v=>v===0));
 p.run('psg.write(0xe4);psg.write(0xf0)');assert.ok(new Set(p.json('Array.from({length:4000},()=>psg.sample(44100))')).size>2,'real noise LFSR output varies');
});

test('FM and PSG generate separately, silence when chips are muted, and bus request freezes Z80 only',()=>{
 const p=project();p.run('machine.bus.z80BusReq=1;machine.audio.psg.volume.fill(15)');const cycles=p.run('machine.audio.totalZ80Cycles');p.nativeCalls.length=0;p.frames(2);assert.equal(p.run('machine.audio.totalZ80Cycles'),cycles);const fm=pcmValues(pcmCalls(p).at(-1));assert.ok(new Set(fm).size>200,'FM synthesis must generate its own signal');
 p.run('machine.audio.fm.reset();machine.audio.psg.volume[0]=0');p.nativeCalls.length=0;p.frames(2);const psg=pcmValues(pcmCalls(p).at(-1));assert.ok(psg.some(v=>v>0)&&psg.some(v=>v<0),'PSG must generate an independent waveform');
 p.run('machine.audio.psg.volume.fill(15)');p.nativeCalls.length=0;p.frames(2);assert.ok(pcmValues(pcmCalls(p).at(-1)).every(v=>v===0),'no artificial sound when FM/PSG are silent');
});

test('full save/load reproduces exact future PCM and flushes output queues',()=>{
 const p=project();p.run('globalThis.audioSaved=machine.state()');p.nativeCalls.length=0;p.frames(3);const next=pcmCalls(p).map(b=>b.toString('hex'));const cpu=p.json('({D:[...machine.cpu.D],A:[...machine.cpu.A],PC:machine.cpu.PC,total:machine.cpu.total,zram:[...machine.bus.zram]})');
 p.run('machine.audio.pcm.push(123,456);machine.loadState(audioSaved);machine.paused=false');assert.ok(p.nativeCalls.some(c=>c[0]==='audio:flush'));assert.equal(p.run('machine.audio.pcm.length'),0);p.nativeCalls.length=0;p.frames(3);assert.deepEqual(pcmCalls(p).map(b=>b.toString('hex')),next);assert.deepEqual(p.json('({D:[...machine.cpu.D],A:[...machine.cpu.A],PC:machine.cpu.PC,total:machine.cpu.total,zram:[...machine.bus.zram]})'),cpu);
});

test('sound continues through safe RTC blasts, quick load, recovery and rewind, with exact restored PCM',()=>{
 const p=project();for(const e of p.elements.filter(e=>e.dataset.rtcDomain))e.checked=['ram','zram'].includes(e.dataset.rtcDomain);p.document.getElementById('rtcMode').value='random';p.document.getElementById('rtcDomainRanges').value='ram: 8000-803F\nzram: 1800-183F';p.run('rtcSetClean();rtcCapture();rtcBlast()');p.nativeCalls.length=0;p.frames(2);assert.ok(pcmValues(Buffer.concat(pcmCalls(p))).some(v=>v!==0));
 p.run('rtcCapture();rtcRewindStart();rtcRewindStep();rtcRewindStop()');p.nativeCalls.length=0;p.frames(1);const rewindPCM=pcmCalls(p).at(-1).toString('hex');p.run('rtcRestoreClean()');p.nativeCalls.length=0;p.frames(1);assert.equal(pcmCalls(p).at(-1).toString('hex'),rewindPCM,'rewind across a blast restores chip phase and Z80 state exactly');
 p.document.getElementById('rtcQuickSave').click();p.frames(1);p.document.getElementById('rtcQuickLoad').click();p.nativeCalls.length=0;p.frames(1);assert.ok(pcmValues(pcmCalls(p).at(-1)).some(v=>v!==0));
 p.run('rtcBlast();rtcRecover()');p.nativeCalls.length=0;p.frames(1);assert.ok(pcmValues(pcmCalls(p).at(-1)).some(v=>v!==0));
});

test('audio mute and lifecycle pause flush native playback while retaining emulated sound state',()=>{
 const p=project();p.document.getElementById('audioBtn').click();assert.equal(p.run('machine.audio.enabled'),false);p.nativeCalls.length=0;p.frames(1);assert.equal(pcmCalls(p).length,0);p.document.getElementById('audioBtn').click();assert.equal(p.run('machine.audio.enabled'),true);p.nativeCalls.length=0;p.frames(1);assert.equal(pcmCalls(p).length,1);
 p.nativeCalls.length=0;p.context.BadGenesisLifecycle(true);assert.equal(p.run('machine.audio.foreground'),false);assert.equal(p.run('machine.audio.enabled'),true);assert.ok(p.nativeCalls.some(c=>c[0]==='audio:flush'));assert.ok(!p.nativeCalls.some(c=>c[0]==='audio:setEnabled'&&c[1]===false));p.frames(1);assert.equal(pcmCalls(p).length,0);p.context.BadGenesisLifecycle(false);assert.equal(p.run('machine.audio.foreground'),true);p.frames(1);assert.equal(pcmCalls(p).length,1);
});

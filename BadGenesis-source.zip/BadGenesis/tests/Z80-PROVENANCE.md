# Z80 validation

The production interpreter is based on Molly Howell's MIT-licensed Z80.js:
https://github.com/DrGoldfire/Z80.js/commit/2207d7c6a8b42246ea12efbf9dba8b2adf010437

BadGenesis adds a Genesis bus wrapper, correct HALT/INT/EI/DI timing, bounded
repeated-prefix scheduling, indexed CB and undefined ED timing, MEMPTR/Q/P
latches, complete block I/O behavior, and undocumented flags. The opcode
interpreter does not contain its own ROM or RAM.

Run `node tests/z80.test.cjs` for synthetic instruction-family, interrupt,
prefix-corruption and full-state replay checks covering 1,792 opcode paths.

Run `node tests/z80-vectors.test.cjs` for 3,600 independent instruction vectors
from 36 families: primary arithmetic and DAA, SCF/CCF, register and memory BIT,
IX/IY and indexed CB, ED arithmetic and transfers, and repeating block I/O.
These compare registers, flags, memory, I/O writes, WZ/Q/P internal latches,
and instruction cycle counts. They do not verify individual bus-cycle timing.

The fixtures contain the first 100 vectors per selected file from:
https://github.com/SingleStepTests/z80/commit/ebe1875d48f374bcfd4b505d8eb8ee751568b5f7
Fixture license: [SingleStepTests-MIT.txt](licenses/SingleStepTests-MIT.txt).

The additional repeat-cycle flag formulas are documented hardware behavior:
https://github.com/hoglet67/Z80Decoder/wiki/Undocumented-Flags

These tests cover the Z80 core. End-to-end game audio also requires the Genesis
bus, CPU scheduling, YM2612/PSG implementations, and output transport tests.

'use strict';
const fs=require('node:fs'),path=require('node:path');
const {run}=require('node:test');
const {spec}=require('node:test/reporters');
const files=['z80.test.cjs','z80-vectors.test.cjs','integration.test.cjs','audio-integration.test.cjs'];
const report={timestamp:new Date().toISOString(),scope:'Actual emulator scripts with deterministic DOM adapter and original diagnostic ROM. Browser and physical Android checks are separate.',files,checks:[],failed:0};
// In-process isolation avoids a restricted cloud sandbox disguising blocked
// child launches as empty successful processes. Each emulator has its own VM.
const stream=run({files:files.map(file=>path.join(__dirname,file)),isolation:'none'});
stream.on('test:pass',event=>report.checks.push({name:event.name,passed:true}));
stream.on('test:fail',event=>{report.failed++;report.checks.push({name:event.name,passed:false,error:event.details?.error?.message})});
stream.on('end',()=>{
 const out=path.join(__dirname,'../test-results');fs.mkdirSync(out,{recursive:true});fs.writeFileSync(path.join(out,'integration-report.json'),JSON.stringify(report,null,2)+'\n');
 if(report.failed||report.checks.length<22)process.exitCode=1;
});
stream.compose(spec).pipe(process.stdout);

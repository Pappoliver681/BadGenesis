#!/usr/bin/env python3
"""Package the Android project's assets and auditable source without toolchains."""
from pathlib import Path
import hashlib, json, re, zipfile

ROOT=Path(__file__).resolve().parents[1]
ASSETS=ROOT/'reference-webview/assets'
DIST=ROOT/'dist'
DIST.mkdir(exist_ok=True)
html=(ASSETS/'BadGenesis.html').read_text()
# Optional inline WASM is consumed by the sound-module loader for file:// use.
wasms=list(ASSETS.rglob('*.wasm'))
if wasms:
 import base64
 data={p.name:base64.b64encode(p.read_bytes()).decode() for p in wasms}
 html=html.replace('<script src="core.js">', '<script>window.BADGENESIS_EMBEDDED_WASM='+json.dumps(data)+';</script>\n<script src="core.js">',1)

def inline_script(m):
 path=ASSETS/m.group(1)
 code=path.read_text().replace('</script','<\\/script')
 return '<script>\n'+code+'\n</script>'
html=re.sub(r'<script src="([^"\:]+)"></script>',inline_script,html)
def inline_style(m):
 return '<style>\n'+(ASSETS/m.group(1)).read_text()+'\n</style>'
html=re.sub(r'<link[^>]*href="([^"\:]+\.css)"[^>]*>',inline_style,html)
(DIST/'BadGenesis_Offline.html').write_text(html)
exclusions={'node_modules','.gradle','build','dist','.git','__pycache__','toolchain','.toolchain','android-sdk','sdk','jdk','gradle-cache','gradle-home','signing','native-backend-host'}
with zipfile.ZipFile(DIST/'BadGenesis-source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(ROOT.rglob('*')):
  if not p.is_file(): continue
  rel=p.relative_to(ROOT)
  if any(part in exclusions for part in rel.parts):continue
  if p.suffix in {'.log','.tmp','.o','.so','.a','.class','.apk','.keystore','.part'}:continue
  with p.open('rb') as check:
   if check.read(4)==b'\x7fELF':continue
  z.write(p,'BadGenesis/'+str(rel))
artifacts={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(DIST.iterdir()) if p.is_file() and p.name in {'BadGenesis-source.zip','BadGenesis_Offline.html','BadGenesis-Native-Android16.apk','phone-native-build.txt','phone-native-build.yml'}}
(DIST/'checksums.json').write_text(json.dumps(artifacts,indent=2)+'\n')
for name,meta in artifacts.items():print(name,meta['bytes'],meta['sha256'])

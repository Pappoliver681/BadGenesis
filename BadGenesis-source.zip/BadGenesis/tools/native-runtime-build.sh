#!/usr/bin/env bash
# Build the native Android host/core in the cloud. No WebView or JS runtime.
set -Eeuo pipefail
trap 'printf "Native build failed at line %s\n" "$LINENO" >&2' ERR
BG_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
BG_TOOLS="${BADGENESIS_TOOLCHAIN:-$BG_ROOT/toolchain}"
BG_BUILD="$BG_ROOT/build/native-cloud"
BG_DIST="$BG_ROOT/dist"
BG_VENDOR="$BG_ROOT/vendor/genesis-plus-gx"
BG_COMMIT=c2838c7dc4236fc2fe94e5dbd08b41486067918e
BG_NDK_VERSION=28.2.13676358
BG_VERSION_CODE=4
BG_VERSION_NAME=2.1.1
BG_SIGNER_SHA256=62bb12d4f1908cb3703f3345b89b878c01663796ee9ddf5fe108b5fc49d9b1c4
BG_KEY="$BG_ROOT/signing/badgenesis-development.keystore"
BG_ABIS=(arm64-v8a armeabi-v7a x86_64)
mkdir -p "$BG_TOOLS/downloads" "$BG_BUILD" "$BG_DIST" "$BG_ROOT/signing"

for BG_COMMAND in java keytool curl python3 cmake; do
  command -v "$BG_COMMAND" >/dev/null || { printf 'Required cloud command is missing: %s\n' "$BG_COMMAND" >&2; exit 1; }
done
if command -v javac >/dev/null; then
  BG_JAVAC=(javac)
elif java --list-modules | python3 -c 'import sys; sys.exit(not any(line.startswith("jdk.compiler@") for line in sys.stdin))'; then
  BG_JAVAC=(java -m jdk.compiler/com.sun.tools.javac.Main)
else
  printf 'The cloud JDK must include its Java compiler.\n' >&2
  exit 1
fi

# This is an update to the installed native app. A replacement key cannot
# update it, so check the retained identity before downloading or compiling.
if [[ ! -f "$BG_KEY" ]]; then
  printf '%s\n' \
    'The installed native app signing key is missing; this update cannot be signed.' \
    'Restore signing/badgenesis-development.keystore from the existing GitHub Actions cache.' \
    'Keep BG_PROJECT=badgenesis-native-build/BadGenesis and the existing signing cache key/path.' \
    'No replacement key was generated. The installed APK and its data remain unchanged.' >&2
  exit 1
fi
if ! keytool -exportcert -keystore "$BG_KEY" -storepass badgenesis-development \
  -alias badgenesis -file "$BG_BUILD/signing-certificate.der" >/dev/null; then
  printf '%s\n' 'The retained native signing key could not be opened. Restore its original cache entry; do not generate a replacement key.' >&2
  exit 1
fi
python3 - "$BG_BUILD/signing-certificate.der" "$BG_SIGNER_SHA256" <<'PY'
import hashlib, pathlib, sys
actual = hashlib.sha256(pathlib.Path(sys.argv[1]).read_bytes()).hexdigest()
expected = sys.argv[2]
if actual != expected:
    raise SystemExit('Signing identity mismatch: expected '+expected+', found '+actual+'. '
                     'Restore the installed native APK signing key from the native build cache. '
                     'No APK was signed with this replacement identity.')
print('Verified installed native APK signing identity: '+actual, flush=True)
PY

# Refuse to accidentally publish the previous browser host as a native build.
python3 - "$BG_ROOT" "$BG_VENDOR" "$BG_COMMIT" "$BG_VERSION_CODE" "$BG_VERSION_NAME" <<'PY'
import hashlib, json, pathlib, re, sys
root, vendor = map(pathlib.Path, sys.argv[1:3])
commit = sys.argv[3]
version_code, version_name = sys.argv[4:6]
gradle = (root/'app/build.gradle').read_text()
if not re.search(r'\bversionCode\s+'+re.escape(version_code)+r'\b', gradle) or not re.search(
        r'\bversionName\s+[\'"]'+re.escape(version_name)+r'[\'"]', gradle):
    raise RuntimeError('Gradle and native cloud build application versions differ.')
if not (root/'app/src/main/cpp/CMakeLists.txt').is_file():
    raise RuntimeError('The native CMake project is missing.')
sources = list((root/'app/src/main/java').rglob('*.java'))
if not sources or any(re.search(r'\bandroid\.webkit\b|\bWebView\b|com\.eclipsesource\.v8', p.read_text()) for p in sources):
    raise RuntimeError('The APK source still contains a WebView/JavaScript runtime host.')
if not any('System.loadLibrary("badgenesis")' in p.read_text() for p in sources):
    raise RuntimeError('The native Genesis JNI bridge is missing.')
for path in ('LICENSE.txt', 'core/genesis.c', 'libretro/libretro.c'):
    if not (vendor/path).is_file():
        raise RuntimeError('The pinned Genesis Plus GX sources are missing: '+path)
manifest = json.loads((vendor/'UPSTREAM.json').read_text())
if manifest.get('commit') != commit:
    raise RuntimeError('The Genesis Plus GX vendor revision differs from the pinned build revision.')
for item in manifest['files']:
    path = vendor/item['path']
    data = path.read_bytes()
    digest = hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    if digest != item['sha']: raise RuntimeError('The pinned upstream source was altered: '+item['path'])
print('Verified '+str(len(manifest['files']))+' pinned native source files.', flush=True)
PY

python3 - "$BG_TOOLS" "$BG_BUILD" "${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}" \
  "${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}" "$BG_NDK_VERSION" <<'PY'
import hashlib, os, pathlib, stat, subprocess, sys, xml.etree.ElementTree as ET, zipfile
root, build = map(pathlib.Path, sys.argv[1:3])
cache = root/'downloads'
installed_sdk = pathlib.Path(sys.argv[3]) if sys.argv[3] else None
explicit_ndk = pathlib.Path(sys.argv[4]) if sys.argv[4] else None
ndk_version = sys.argv[5]
tree = None
def fetch(url, path):
    if path.is_file() and path.stat().st_size: return
    temporary = path.with_suffix(path.suffix+'.part')
    print('Downloading '+url, flush=True)
    subprocess.run(['curl', '--fail', '--location', '--retry', '3', '--connect-timeout', '30',
                    '--max-time', '900', '--output', str(temporary), url], check=True)
    temporary.replace(path)
def tag(element): return element.tag.rsplit('}', 1)[-1]
def child(element, name): return next((c for c in element if tag(c) == name), None)
def text(element, name):
    item = child(element, name)
    return item.text if item is not None else None
def extract(archive, destination):
    destination.mkdir(parents=True, exist_ok=True)
    base = destination.resolve()
    with zipfile.ZipFile(archive) as handle:
        for member in handle.infolist():
            target = destination/member.filename
            if not target.resolve().is_relative_to(base): raise RuntimeError('Unsafe SDK archive member')
            mode = member.external_attr >> 16
            if stat.S_ISLNK(mode):
                link = handle.read(member).decode('utf-8')
                if os.path.isabs(link) or not (target.parent/link).resolve().is_relative_to(base):
                    raise RuntimeError('Unsafe SDK archive symlink')
                target.parent.mkdir(parents=True, exist_ok=True)
                target.unlink(missing_ok=True)
                target.symlink_to(link)
            else:
                handle.extract(member, destination)
                if mode: target.chmod(mode & 0o777)
def install(package, marker, destination, required_files=()):
    global tree
    candidates = sorted(destination.rglob(marker)) if destination.exists() else []
    if candidates and all((candidates[0].parent/name).is_file() for name in required_files): return candidates[0]
    if tree is None:
        metadata = cache/'repository2-3.xml'
        fetch('https://dl.google.com/android/repository/repository2-3.xml', metadata)
        tree = ET.parse(metadata)
    package_entry = next((e for e in tree.iter() if tag(e) == 'remotePackage' and e.get('path') == package), None)
    if package_entry is None: raise RuntimeError('The official SDK repository lacks '+package)
    archive = next((a for a in child(package_entry, 'archives')
                    if text(a, 'host-os') in (None, 'linux') and child(a, 'complete') is not None), None)
    if archive is None: raise RuntimeError('No Linux SDK archive for '+package)
    complete = child(archive, 'complete')
    relative = text(complete, 'url')
    url = relative if relative.startswith('https://') else 'https://dl.google.com/android/repository/'+relative
    download = cache/pathlib.Path(relative).name
    fetch(url, download)
    checksum = child(complete, 'checksum')
    if checksum is None: raise RuntimeError('The SDK archive has no published checksum.')
    digest = hashlib.new(checksum.get('type', 'sha1'))
    with download.open('rb') as input_file:
        for chunk in iter(lambda: input_file.read(4*1024*1024), b''): digest.update(chunk)
    digest = digest.hexdigest()
    if digest.lower() != checksum.text.strip().lower():
        download.unlink(missing_ok=True)
        raise RuntimeError('SDK archive checksum mismatch: '+package)
    if text(complete, 'size') and download.stat().st_size != int(text(complete, 'size')):
        raise RuntimeError('Incomplete SDK archive: '+package)
    extract(download, destination)
    candidates = sorted(destination.rglob(marker))
    if len(candidates) != 1: raise RuntimeError('Expected one '+marker+' in '+package)
    if not all((candidates[0].parent/name).is_file() for name in required_files):
        raise RuntimeError('The official archive is missing a required component: '+package)
    return candidates[0]
sdk = root/'sdk'
platform = installed_sdk/'platforms/android-36/android.jar' if installed_sdk else None
if platform is None or not platform.is_file():
    platform = install('platforms;android-36', 'android.jar', sdk/'platform-36')
tools = installed_sdk/'build-tools/36.0.0' if installed_sdk else None
required = ('aapt2', 'd8', 'apksigner', 'zipalign')
if tools is None or not all((tools/name).is_file() for name in required):
    tools = install('build-tools;36.0.0', 'aapt2', sdk/'build-tools-36', required).parent
def valid_ndk(path):
    return path is not None and (path/'build/cmake/android.toolchain.cmake').is_file() \
        and (path/'toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-strip').is_file()
ndk = explicit_ndk if valid_ndk(explicit_ndk) else None
if ndk is None and installed_sdk and (installed_sdk/'ndk').is_dir():
    def version(path):
        try: return tuple(int(part) for part in path.name.split('.'))
        except ValueError: return (0,)
    choices = sorted((p for p in (installed_sdk/'ndk').iterdir() if valid_ndk(p) and version(p)[0] >= 28),
                     key=version, reverse=True)
    if choices: ndk = choices[0]
if ndk is None:
    ndk = install('ndk;'+ndk_version, 'source.properties', sdk/('ndk-'+ndk_version),
                  ('build/cmake/android.toolchain.cmake',
                   'toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-strip',
                   'toolchains/llvm/prebuilt/linux-x86_64/bin/clang')).parent
if not valid_ndk(ndk): raise RuntimeError('The selected Android NDK is incomplete.')
if not all((tools/name).is_file() for name in required): raise RuntimeError('The SDK build tools are incomplete.')
(build/'sdk-paths.txt').write_text(str(platform)+'\n'+str(tools)+'\n'+str(ndk)+'\n')
print('Android NDK: '+str(ndk), flush=True)
PY

mapfile -t BG_SDK_PATHS < "$BG_BUILD/sdk-paths.txt"
BG_ANDROID_JAR="${BG_SDK_PATHS[0]}"
BG_SDK_BIN="${BG_SDK_PATHS[1]}"
BG_NDK="${BG_SDK_PATHS[2]}"
BG_STRIP="$BG_NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-strip"
BG_GENERATOR='Unix Makefiles'
if command -v ninja >/dev/null; then BG_GENERATOR=Ninja; fi
mkdir -p "$BG_BUILD/jni"
for BG_ABI in "${BG_ABIS[@]}"; do
  printf 'Compiling the native Genesis RTC backend for %s\n' "$BG_ABI"
  cmake -S "$BG_ROOT/app/src/main/cpp" -B "$BG_BUILD/$BG_ABI" -G "$BG_GENERATOR" \
    -DCMAKE_TOOLCHAIN_FILE="$BG_NDK/build/cmake/android.toolchain.cmake" \
    -DANDROID_ABI="$BG_ABI" -DANDROID_PLATFORM=android-26 -DANDROID_STL=c++_static \
    -DCMAKE_BUILD_TYPE=Release -DGPGX_SOURCE_DIR="$BG_VENDOR"
  cmake --build "$BG_BUILD/$BG_ABI" --parallel "${BADGENESIS_JOBS:-2}" --target badgenesis
  mkdir -p "$BG_BUILD/jni/$BG_ABI"
  cp "$BG_BUILD/$BG_ABI/libbadgenesis.so" "$BG_BUILD/jni/$BG_ABI/libbadgenesis.so"
  "$BG_STRIP" --strip-unneeded "$BG_BUILD/jni/$BG_ABI/libbadgenesis.so"
done

python3 - "$BG_ROOT" "$BG_BUILD" "$BG_COMMIT" <<'PY'
import json, pathlib, shutil, struct, sys, xml.etree.ElementTree as ET
root, build = map(pathlib.Path, sys.argv[1:3])
commit = sys.argv[3]
report = []
for library in sorted((build/'jni').rglob('*.so')):
    data = library.read_bytes()
    if data[:4] != b'\x7fELF' or data[5] != 1: raise RuntimeError('Invalid native ELF: '+str(library))
    if data[4] == 2:
        offset = struct.unpack_from('<Q', data, 32)[0]
        stride, count = struct.unpack_from('<HH', data, 54)
        entry = '<IIQQQQQQ'
    elif data[4] == 1:
        offset = struct.unpack_from('<I', data, 28)[0]
        stride, count = struct.unpack_from('<HH', data, 42)
        entry = '<IIIIIIII'
    else: raise RuntimeError('Unsupported ELF class')
    alignments = []
    for index in range(count):
        values = struct.unpack_from(entry, data, offset+index*stride)
        if values[0] == 1:
            alignment = values[-1]
            if alignment < 16384 or alignment & (alignment-1):
                raise RuntimeError('The native library lacks 16 KB load-segment alignment: '+str(library))
            file_offset, address = (values[2], values[3]) if data[4] == 2 else (values[1], values[2])
            if file_offset % 16384 != address % 16384:
                raise RuntimeError('The native ELF load segments cannot map on 16 KB pages.')
            alignments.append(alignment)
    if not alignments: raise RuntimeError('The native ELF has no loadable segments.')
    report.append({'abi': library.parent.name, 'library': library.name,
                   'bytes': len(data), 'load_segment_alignment': alignments})
    print('Verified 16 KB native alignment: '+library.parent.name, flush=True)
(root/'dist/native-libraries.json').write_text(json.dumps({'genesis_plus_gx_commit': commit, 'libraries': report}, indent=2)+'\n')
# Stage only notices for the APK; the original HTML/JS project stays in the source archive.
assets = build/'assets'
if assets.exists(): shutil.rmtree(assets)
licenses = assets/'licenses'
licenses.mkdir(parents=True)
shutil.copyfile(root/'vendor/genesis-plus-gx/LICENSE.txt', licenses/'Genesis-Plus-GX.txt')
notice = root/'app/src/main/assets/licenses/THIRD_PARTY_NOTICES.txt'
if not notice.is_file(): raise RuntimeError('The native third-party/source notices are missing.')
shutil.copyfile(notice, licenses/'THIRD_PARTY_NOTICES.txt')
for license_file in (root/'app/src/main/assets/licenses').iterdir():
    if license_file.is_file() and license_file.name not in {'Genesis-Plus-GX.txt', 'THIRD_PARTY_NOTICES.txt'}:
        shutil.copyfile(license_file, licenses/license_file.name)
ET.register_namespace('android', 'http://schemas.android.com/apk/res/android')
tree = ET.parse(root/'app/src/main/AndroidManifest.xml')
tree.getroot().set('package', 'com.badgenesis.app')
application = tree.getroot().find('application')
if application is None: raise RuntimeError('The app manifest has no application.')
application.set('{http://schemas.android.com/apk/res/android}extractNativeLibs', 'true')
tree.write(build/'AndroidManifest.xml', encoding='utf-8', xml_declaration=True)
PY

rm -rf "$BG_BUILD/classes" "$BG_BUILD/generated" "$BG_BUILD/dex"
mkdir -p "$BG_BUILD/classes" "$BG_BUILD/generated" "$BG_BUILD/dex"
printf 'Compiling Android 16 native interface resources\n'
"$BG_SDK_BIN/aapt2" compile --dir "$BG_ROOT/app/src/main/res" -o "$BG_BUILD/resources.zip"
"$BG_SDK_BIN/aapt2" link -o "$BG_BUILD/resources.apk" -I "$BG_ANDROID_JAR" \
  --manifest "$BG_BUILD/AndroidManifest.xml" --min-sdk-version 26 --target-sdk-version 36 \
  --version-code "$BG_VERSION_CODE" --version-name "$BG_VERSION_NAME" --java "$BG_BUILD/generated" \
  -A "$BG_BUILD/assets" "$BG_BUILD/resources.zip"
python3 - "$BG_ROOT" "$BG_BUILD" <<'PY'
import pathlib, sys
root, build = map(pathlib.Path, sys.argv[1:])
sources = sorted((root/'app/src/main/java').rglob('*.java'))+sorted((build/'generated').rglob('*.java'))
(build/'sources.txt').write_text('\n'.join('"'+str(p)+'"' for p in sources)+'\n')
PY
printf 'Compiling the native Android Java interface\n'
# The modular-JDK fallback uses -Xmx directly instead of javac's -J launcher flag.
if [[ "${BG_JAVAC[0]}" == javac ]]; then
  "${BG_JAVAC[@]}" -J-Xmx1024m --release 17 -proc:none -classpath "$BG_ANDROID_JAR" \
    -d "$BG_BUILD/classes" @"$BG_BUILD/sources.txt"
else
  java -Xmx1024m -m jdk.compiler/com.sun.tools.javac.Main -source 17 -target 17 -proc:none \
    -classpath "$BG_ANDROID_JAR" -d "$BG_BUILD/classes" @"$BG_BUILD/sources.txt"
fi
python3 - "$BG_BUILD" <<'PY'
import pathlib, sys, zipfile
build = pathlib.Path(sys.argv[1])
with zipfile.ZipFile(build/'classes.jar', 'w', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted((build/'classes').rglob('*.class')): archive.write(path, path.relative_to(build/'classes'))
PY
"$BG_SDK_BIN/d8" --release --min-api 26 --lib "$BG_ANDROID_JAR" \
  --output "$BG_BUILD/dex" "$BG_BUILD/classes.jar"
python3 - "$BG_BUILD" <<'PY'
import pathlib, shutil, sys, zipfile
build = pathlib.Path(sys.argv[1])
apk = build/'unaligned.apk'
shutil.copyfile(build/'resources.apk', apk)
with zipfile.ZipFile(apk, 'a', zipfile.ZIP_DEFLATED) as archive:
    for path in sorted((build/'dex').glob('*.dex')): archive.write(path, path.name)
    for path in sorted((build/'jni').rglob('*.so')): archive.write(path, pathlib.Path('lib')/path.relative_to(build/'jni'))
with zipfile.ZipFile(apk) as archive:
    forbidden = [path for path in archive.namelist() if path.startswith('assets/') and not path.startswith('assets/licenses/')]
    if forbidden: raise RuntimeError('Unexpected executable/runtime APK assets: '+str(forbidden))
PY
"$BG_SDK_BIN/zipalign" -P 16 -f 4 "$BG_BUILD/unaligned.apk" "$BG_BUILD/aligned.apk"
printf 'Signing and verifying the native test APK\n'
"$BG_SDK_BIN/apksigner" sign --ks "$BG_KEY" --ks-key-alias badgenesis \
  --ks-pass pass:badgenesis-development --key-pass pass:badgenesis-development \
  --min-sdk-version 26 --out "$BG_DIST/BadGenesis-Native-Android16.apk" "$BG_BUILD/aligned.apk"
"$BG_SDK_BIN/apksigner" verify --verbose --print-certs "$BG_DIST/BadGenesis-Native-Android16.apk" \
  | tee "$BG_BUILD/apk-signature-verification.txt"
"$BG_SDK_BIN/zipalign" -c -P 16 4 "$BG_DIST/BadGenesis-Native-Android16.apk"
"$BG_SDK_BIN/aapt2" dump badging "$BG_DIST/BadGenesis-Native-Android16.apk" > "$BG_DIST/apk-badging.txt"
python3 - "$BG_DIST/BadGenesis-Native-Android16.apk" "$BG_BUILD" "$BG_VERSION_CODE" "$BG_VERSION_NAME" "$BG_SIGNER_SHA256" <<'PY'
import hashlib, json, pathlib, re, sys, zipfile
apk = pathlib.Path(sys.argv[1])
build = pathlib.Path(sys.argv[2])
version_code, version_name, expected_signer = sys.argv[3:6]
certificates = re.findall(r'^Signer #\d+ certificate SHA-256 digest: ([0-9a-fA-F]+)$',
                        (build/'apk-signature-verification.txt').read_text(), re.MULTILINE)
if [certificate.lower() for certificate in certificates] != [expected_signer]:
    raise RuntimeError('The final APK signing certificate differs from the installed native APK.')
with zipfile.ZipFile(apk) as archive:
    libraries = sorted(path for path in archive.namelist() if path.startswith('lib/') and path.endswith('.so'))
    expected = ['lib/'+abi+'/libbadgenesis.so' for abi in ('arm64-v8a', 'armeabi-v7a', 'x86_64')]
    if libraries != sorted(expected): raise RuntimeError('The APK is missing a required native ABI.')
    runtime_assets = [path for path in archive.namelist() if path.startswith('assets/') and not path.startswith('assets/licenses/')]
    if runtime_assets: raise RuntimeError('The APK unexpectedly includes executable/runtime assets.')
    for path in archive.namelist():
        if path.endswith('.dex'):
            data = archive.read(path)
            if b'Landroid/webkit/' in data or b'Lcom/eclipsesource/v8/' in data:
                raise RuntimeError('The APK bytecode still refers to a WebView or embedded JavaScript runtime.')
badging = (apk.parent/'apk-badging.txt').read_text()
if "targetSdkVersion:'36'" not in badging or "versionCode='"+version_code+"'" not in badging or "versionName='"+version_name+"'" not in badging:
    raise RuntimeError('The APK version or Android target differs from the native build configuration.')
proof = json.loads((apk.parent/'native-libraries.json').read_text())
proof.update({'artifact': apk.name, 'sha256': hashlib.sha256(apk.read_bytes()).hexdigest(),
              'bytes': apk.stat().st_size, 'target_android_api': 36, 'version_code': int(version_code),
              'version_name': version_name, 'signing_certificate_sha256': expected_signer,
              'signature_verified': True, 'apk_alignment_verified': True,
              'webview_class_references': False, 'javascript_runtime_class_references': False,
              'executable_assets': runtime_assets, 'packaged_native_libraries': libraries})
(apk.parent/'apk-native-verification.json').write_text(json.dumps(proof, indent=2)+'\n')
print('Built native APK: '+str(apk))
print('APK bytes: '+str(apk.stat().st_size))
print('SHA-256: '+hashlib.sha256(apk.read_bytes()).hexdigest())
PY

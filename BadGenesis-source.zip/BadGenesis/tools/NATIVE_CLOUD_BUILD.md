# Native Android cloud build

The current build entry point is `tools/cloud-build.sh`, which delegates to
`tools/native-runtime-build.sh`. It builds the Android Java interface and the
C/C++ Genesis Plus GX RTC backend. It does not package a WebView, JavaScript
engine, HTML game page, or browser emulation code.

All build tools run on the cloud runner. The phone only uploads the project,
downloads the resulting APK, and installs it.

## Inputs and toolchains

- Android compile/target API 36, minimum API 26.
- Native Android NDK 28 or newer when preinstalled. If absent, the script
  downloads NDK `28.2.13676358` from Google's official SDK repository.
- Android SDK platform 36 and build-tools `36.0.0`. Existing runner SDK packages
  are reused; missing packages are downloaded from Google and checked against
  the repository's published checksums.
- CMake 3.22 or newer, a Java compiler, Python 3, and curl. Ninja is optional.
- Native ABIs: `arm64-v8a`, `armeabi-v7a`, and `x86_64`.
- Genesis Plus GX source revision
  `c2838c7dc4236fc2fe94e5dbd08b41486067918e`. Its complete selected source and
  `UPSTREAM.json` manifest are included in `vendor/genesis-plus-gx`.

The script checks every pinned vendor file against its Git blob SHA before
building. BadGenesis-specific core extensions live in `app/src/main/cpp`,
and generated extended files are written into build directories. The verified
vendor source remains unchanged.

The CMake build statically links the C++ runtime. The resulting
`libbadgenesis.so` is stripped with the selected NDK's `llvm-strip`, checked
for 16 KB ELF load-segment alignment, and packaged for all three ABIs. Native
libraries use compressed APK entries with `extractNativeLibs=true`.

## Artifacts and update identity

- `dist/BadGenesis-Native-Android16.apk`: version code 3, version name 2.1.0.
- `dist/apk-native-verification.json`: source revision, ABI/library inventory,
  ELF alignment, package version/target, APK hash, and successful package checks.
- `dist/native-libraries.json`: stripped library sizes and ELF segment alignment.
- `dist/apk-badging.txt`: Android package metadata.

The build reuses the installed native app's `signing/badgenesis-development.keystore`
from the existing GitHub Actions signing cache. The phone-upload workflow's
project path must remain `badgenesis-native-build/BadGenesis`; changing the
cached key's path can prevent restoration even when the cache key stays the same.
The existing signing cache key is `badgenesis-development-signing-v1-${github.repository_id}`.
The retained certificate SHA-256 must be
`62bb12d4f1908cb3703f3345b89b878c01663796ee9ddf5fe108b5fc49d9b1c4`.

Before any toolchain downloads or compilation, the build checks that the key
exists and matches this installed native certificate. It fails with a cache
restoration diagnostic if either check fails; it never creates a replacement
key for this update. The final signed APK certificate is checked again and
recorded in `apk-native-verification.json`. The private key belongs in the
cloud signing cache, never a public source ZIP or downloadable build artifact.
This identity updates native version 2. The earlier WebView prototype used a
different certificate.

Both signatures and APK alignment are checked before the verification artifact
is written. The final APK is also inspected for browser/JavaScript runtime
class references and for unexpected runtime assets. Only license and source
notices are packaged as assets.

## Source and licenses

Genesis Plus GX uses a noncommercial source license. Its complete license,
including bundled component terms, is in `vendor/genesis-plus-gx/LICENSE.txt`.
The APK includes this file as `assets/licenses/Genesis-Plus-GX.txt`, with
component copyright/source notices in `assets/licenses/THIRD_PARTY_NOTICES.txt`.
The native application's source archive must accompany distribution of the
APK; it includes the native host, RTC extensions, selected upstream core,
headers, and build configuration. See the vendor provenance document for the
exact upstream files and licensing details.

The original HTML project is retained as reference source. The old manual
WebView build script is retained in `tools/archive/cloud-build-v1.sh`; the
current build never calls it.

## Validation limits

A successful cloud build establishes that the Android native binaries,
resources, and Java interface compile and that the APK passes package checks.
It does not establish performance or audio latency on a physical phone.
Gameplay, Bluetooth/USB controllers, multitouch, rewind, and audio still need
device verification after installation.

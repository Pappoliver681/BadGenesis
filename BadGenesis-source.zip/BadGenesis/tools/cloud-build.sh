#!/usr/bin/env bash
# The current application always builds the native Genesis RTC backend.
set -Eeuo pipefail
BG_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
exec bash "$BG_ROOT/tools/native-runtime-build.sh" "$@"

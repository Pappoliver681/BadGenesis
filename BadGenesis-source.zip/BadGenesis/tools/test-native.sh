#!/usr/bin/env bash
# Validate real native emulation first, followed by RTC and frontend integration.
set -Eeuo pipefail
BG_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
BG_VENDOR="$BG_ROOT/vendor/genesis-plus-gx"
BG_BUILD="$BG_ROOT/build/native-host"
BG_RESULTS="$BG_ROOT/test-results"
mkdir -p "$BG_BUILD" "$BG_RESULTS"
for BG_COMMAND in node python3 gcc g++ make; do
  command -v "$BG_COMMAND" >/dev/null || { printf 'Missing native test command: %s\n' "$BG_COMMAND" >&2; exit 1; }
done
python3 - "$BG_VENDOR" <<'PY'
import hashlib, json, pathlib, sys
vendor = pathlib.Path(sys.argv[1])
manifest = json.loads((vendor/'UPSTREAM.json').read_text())
if manifest['commit'] != 'c2838c7dc4236fc2fe94e5dbd08b41486067918e':
    raise RuntimeError('Unexpected native emulator source revision')
for item in manifest['files']:
    data = (vendor/item['path']).read_bytes()
    digest = hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    if digest != item['sha'] or len(data) != item['size']:
        raise RuntimeError('Native upstream source differs: '+item['path'])
print('Verified '+str(len(manifest['files']))+' pristine native core source files.')
PY
node "$BG_ROOT/tests/native/generate-native-diagnostic.cjs"
if command -v cmake >/dev/null; then
  cmake -S "$BG_ROOT/app/src/main/cpp" -B "$BG_BUILD" \
    -DCMAKE_BUILD_TYPE=Release -DGPGX_SOURCE_DIR="$BG_VENDOR"
  cmake --build "$BG_BUILD" --parallel "${BADGENESIS_JOBS:-2}" --target core_validation backend_validation
  BG_CORE_TEST="$BG_BUILD/core_validation"
  BG_BACKEND_TEST="$BG_BUILD/backend_validation"
else
  # The restricted workspace has GCC/Make but no CMake. This builds the same
  # genuine upstream C core and state supplements, without Android stubs.
  make -C "$BG_VENDOR" -f Makefile.libretro -j"${BADGENESIS_JOBS:-2}" \
    platform=unix HAVE_CHD=0 FLAGS=-DHAVE_NO_LANGEXTRA FRONTEND_SUPPORTS_RGB565=1 \
    SHARED='-shared -Wl,--no-undefined'
  BG_NATIVE="$BG_ROOT/app/src/main/cpp"
  BG_INCLUDE=("-I$BG_NATIVE" "-I$BG_VENDOR/libretro" "-I$BG_VENDOR/libretro/libretro-common/include" "-I$BG_VENDOR/libretro/deps/zlib-1.2.11")
  for BG_DIR in core core/z80 core/m68k core/ntsc core/sound core/sound/minimp3 core/input_hw core/cd_hw core/cart_hw core/cart_hw/svp core/sound/tremor; do
    BG_INCLUDE+=("-I$BG_VENDOR/$BG_DIR")
  done
  BG_DEFINES=(-DLSB_FIRST -DBYTE_ORDER=LITTLE_ENDIAN -D__LIBRETRO__ -DUSE_LIBRETRO_VFS -DUSE_LIBTREMOR -DUSE_16BPP_RENDERING -DFRONTEND_SUPPORTS_RGB565 -DHAVE_YM3438_CORE -DHAVE_OPLL_CORE -DMAXROMSIZE=33554432 -DM68K_OVERCLOCK_SHIFT=20 -DZ80_OVERCLOCK_SHIFT=20 '-DINLINE=static inline')
  python3 - "$BG_VENDOR/core/input_hw/gamepad.c" "$BG_NATIVE/gamepad_snapshot.inc" "$BG_BUILD/gamepad-snapshot.c" <<'PY'
import pathlib, sys
source, supplement, output = map(pathlib.Path, sys.argv[1:])
output.write_text(source.read_text()+'\n'+supplement.read_text())
PY
  gcc -std=gnu11 -O2 "${BG_INCLUDE[@]}" "${BG_DEFINES[@]}" \
    "$BG_ROOT/tests/native/core-validation.c" "$BG_NATIVE/vendor_adapter.c" "$BG_BUILD/gamepad-snapshot.c" \
    "$BG_VENDOR/genesis_plus_gx_libretro.so" -lm -Wl,--export-dynamic \
    "-Wl,-rpath,$BG_VENDOR" -o "$BG_BUILD/core_validation"
  BG_CORE_TEST="$BG_BUILD/core_validation"
  BG_BACKEND_TEST=''
fi
printf 'Checking actual native CPU, video, input, FM/PSG and full state with RTC OFF\n'
"$BG_CORE_TEST" "$BG_ROOT/tests/native/native-diagnostic.bin" | tee "$BG_RESULTS/native-core-validation.jsonl"
printf 'Checking live-memory RTC mutations, randomness and Undo\n'
g++ -std=c++17 -Wall -Wextra -Werror -pedantic -O2 -I "$BG_ROOT/app/src/main/cpp" \
  "$BG_ROOT/app/src/main/cpp/rtc_engine.cpp" "$BG_ROOT/tests/native/rtc_engine_test.cpp" \
  -o "$BG_BUILD/rtc_engine_test"
"$BG_BUILD/rtc_engine_test" | tee "$BG_RESULTS/native-rtc-validation.log"
printf 'Checking the production native worker, domains, audio, rewind and states\n'
if [[ -n "$BG_BACKEND_TEST" ]]; then
  "$BG_BACKEND_TEST" "$BG_ROOT/tests/native/native-diagnostic.bin" | tee "$BG_RESULTS/native-backend-validation.jsonl"
else
  bash "$BG_ROOT/tests/native/run-backend-validation.sh"
fi
python3 - "$BG_RESULTS" <<'PY'
import collections, hashlib, json, pathlib, sys
root = pathlib.Path(sys.argv[1])
def records(name):
    return [json.loads(line) for line in (root/name).read_text().splitlines() if line.strip().startswith('{')]
core = records('native-core-validation.jsonl')
backend = records('native-backend-validation.jsonl')
rtc = [line[5:] for line in (root/'native-rtc-validation.log').read_text().splitlines() if line.startswith('PASS ')]
required_backend = collections.Counter([
    'native_worker_ntsc_clock_pause_resume', 'native_worker_pal_clock_pause_resume',
    'native_worker_real_pcm_and_simultaneous_input', 'native_worker_real_pcm_and_simultaneous_input',
    'native_live_seven_domains_endian_cram_undo_sram_rom_states',
    'native_owned_full_future_payload_and_harvester',
    'native_visible_tile_palette_and_sprite_cache_corruption',
    'native_random_auto_blast_continuous_rewind_history_resume',
    'native_ntsc_fast_forward_hold_release_clock', 'native_pal_fast_forward_hold_release_clock',
    'native_ntsc_fast_forward_auto_blast_emulated_frames', 'native_pal_fast_forward_auto_blast_emulated_frames',
    'native_audible_rewind_interval_2_speed_1', 'native_audible_rewind_interval_2_speed_4',
    'native_audible_rewind_interval_15_speed_1', 'native_audible_rewind_interval_15_speed_4',
    'native_rewind_audio_toggle', 'native_rewind_real_pcm_reverse_stereo_order',
    'native_benchmark_preserves_state_history_rewind_audio',
    'native_actual_vblank_framebuffer_animation',
    'native_smooth_full_rewind_interval_6_speed_1', 'native_smooth_full_rewind_interval_6_speed_2',
    'native_smooth_full_rewind_interval_6_speed_4', 'native_smooth_full_rewind_interval_15_speed_1',
    'native_smooth_full_rewind_interval_15_speed_2', 'native_smooth_full_rewind_interval_15_speed_4',
    'native_quick_blast_playing_random_history_live_undo',
    'native_smooth_rewind_exact_future_across_rtc_blasts',
    'native_120_second_rewind_long_tape_pcm_smoothness',
    'production_native_worker_validation_complete',
])
actual_backend = collections.Counter(item['check'] for item in backend)
if len(core) < 10 or len(rtc) < 12 or required_backend - actual_backend:
    raise RuntimeError('Native validation reports are incomplete')
if any(item.get('passed') is False for item in core + backend):
    raise RuntimeError('A native validation report contains a failing check')
project = root.parent
sources = ('app/src/main/cpp/native_backend.cpp', 'app/src/main/cpp/native_backend.h',
           'app/src/main/cpp/rtc_engine.cpp', 'app/src/main/cpp/rtc_engine.h',
           'app/src/main/cpp/vendor_adapter.c', 'app/src/main/cpp/vendor_adapter.h',
           'app/src/main/cpp/gamepad_snapshot.inc', 'app/src/main/cpp/mini_json.h',
           'tests/native/core-validation.c', 'tests/native/rtc_engine_test.cpp',
           'tests/native/backend-validation.cpp', 'tests/native/run-backend-validation.sh')
report = {'emulator': 'Genesis Plus GX native C', 'fixture': 'original public-domain diagnostic ROM',
          'core_checks': core, 'rtc_checks': rtc, 'backend_checks': backend,
          'passed_checks': len(core)+len(backend)+len(rtc),
          'host_source_sha256': {name: hashlib.sha256((project/name).read_bytes()).hexdigest() for name in sources},
          'rtc_test_log': 'native-rtc-validation.log',
          'sonic_tested': False, 'physical_android_tested': False}
(root/'native-validation-report.json').write_text(json.dumps(report, indent=2)+'\n')
print('Native emulation, live-memory RTC and backend validation passed.')
PY

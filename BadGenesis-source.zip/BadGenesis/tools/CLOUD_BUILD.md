# BadGenesis native Android cloud build

The current Android application is native. Its emulator, RTC, rewind, video,
and audio run in C/C++; the menu, document picker, touch controls, and gamepad
input use Android APIs. The APK contains no WebView or JavaScript emulator.
The original working HTML project remains available in the source archive.

`tools/cloud-build.sh` delegates to `tools/native-runtime-build.sh`. GitHub
Actions runs the build in the cloud, so no PC, Android Studio, ADB, Termux, or
local Gradle commands are needed on the user's phone.

## Build configuration

- Android API 36 compile/target, API 26 minimum.
- Application version code 2, version name 2.0.0.
- Native ABIs `arm64-v8a`, `armeabi-v7a`, and `x86_64`.
- CMake and Android NDK 28+; missing NDK packages are downloaded from Google's
  official SDK repository, pinned to `28.2.13676358`.
- SDK platform 36 and build-tools `36.0.0`; existing runner packages are reused.
- Native Genesis Plus GX core revision
  `c2838c7dc4236fc2fe94e5dbd08b41486067918e`, included with provenance and
  checksums in `vendor/genesis-plus-gx`.
- Native OpenGL ES presentation scales the clean framebuffer without display
  filters; native AAudio sends the core's stereo PCM output to Android.

The build verifies the selected upstream source files against the pinned Git
blob SHAs, compiles the core and JNI host for each ABI, strips unneeded native
symbols, and verifies 16 KB native load-segment alignment. Only source/license
notices are included as APK assets. It checks the APK bytecode for browser or
embedded JavaScript runtime references.

## Outputs

The cloud artifact includes `dist/BadGenesis-Native-Android16.apk`,
`dist/apk-native-verification.json`, and `dist/apk-badging.txt`. Native library
sizes/alignment are also recorded in `dist/native-libraries.json`.

The signing key remains `signing/badgenesis-development.keystore` and uses the
existing repository's GitHub Actions signing cache. It must remain private.
Reusing that key allows the version 2 native APK to update the previous
installation. APK signature and archive alignment checks finish before the
final verification JSON is created.

Genesis Plus GX is licensed for noncommercial distribution and requires
corresponding source. The source ZIP contains the native application, RTC/core
extensions, pinned upstream files, original reference project, and build files.
The APK's Open source licenses screen includes the upstream license and
component/source notices. Distribute this source ZIP alongside the APK.

Build checks establish compilation and package integrity. Physical-phone
performance, audio latency, touch controls, and Bluetooth/USB controllers need
device testing after installation. See [NATIVE_CLOUD_BUILD.md](NATIVE_CLOUD_BUILD.md)
for toolchain, licensing, and packaging details.

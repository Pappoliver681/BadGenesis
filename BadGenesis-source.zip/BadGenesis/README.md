# BadGenesis native Android RTC

This continues the existing BadGenesis project with a native Genesis Plus GX backend. The original HTML, previous emulator, RTC design and Android wrapper are preserved in `original.html` and `reference-webview/`.

The Android app uses C/C++ emulation through JNI, native Android controls and native audio and video output. No WebView, JavaScript emulator, HTML canvas or JavaScript clock is used or packaged in the native APK.

## Native architecture

```
Genesis Plus GX C core
       |
Live memory domains + native RTC + native savestates
       |
JNI + Android frontend + native audio / Surface output
```

The native worker schedules emulated frames using the core's hardware timing, approximately 59.92 Hz NTSC or 49.70 Hz PAL. Presentation runs separately, so Android display refresh cannot advance emulation. Audio comes from the core's YM2612 and SN76489 implementations, including Z80 sound execution.

Video is sharp and unfiltered. There are no CRT effects, scanlines, curvature, phosphor effects or blur filters.

## Features

- Native ROM loading through Android's document picker, including ROM ZIPs.
- Native multitouch D-pad, A/B/C, X/Y/Z, START and MODE, with separate pointer IDs, diagonals and multiple held buttons. Three- and six-button modes.
- Adjustable control size, group positions and opacity; hide/show and vibration controls; Android Bluetooth/USB gamepad and keyboard input.
- MD.emu-style native menus with a black background, blue title bar and divided text rows. The navigation and layouts follow the supplied MD.emu screen recording while retaining BadGenesis's RTC, state and resource tools. Gameplay has compact corner controls and the beveled D-pad, green A, red B and purple C layout from the supplied reference.
- Hold-to-fast-forward with selectable 2×, 3×, 4× or 8× speed. Held rewind has an independent 0.5×, 1×, 2×, 4×, 8× or 16× playback speed and an optional audible reverse of the core's recorded stereo PCM. Normal gameplay retains hardware timing.
- Routine actions such as Blast and Undo complete without repeated text notifications. Errors and requested details remain available in the menus.
- Live 68000 Work RAM, Z80 RAM, VRAM, CRAM, VSRAM, supported cartridge RAM and optional ROM working-copy corruption. Domain metadata and a memory inspector.
- Bit Flip, Random Byte, Add, Subtract, Tilt, Zero, FF, Swap, big-endian 16/32-bit mutations and advanced 68000 NOP `4E71`.
- Blast Once, an in-game manual Blast shortcut, Auto Blast measured in emulated frames, intensity, domain ranges and exclusions. Fresh independent system randomness is the default. Manual seed/replay is optional; generated seeds are recorded in Blast History.
- Direct live-memory Undo with previous/new byte values and bounded history.
- Full native state rewind in a bounded RAM ring, with complete state reconstruction for each emulated frame and 15/30/60/120-second presets. Compact reverse deltas retain intermediate frames between full keyframes, so the keyframe interval does not limit reverse playback to sparse jumps. Recorded core PCM supplies audible rewind. The RAM budget includes state, delta and audio storage. Manual Quick Save and four save slots are separate. Supported duration depends on state size and the RAM limit.
- Glitch Harvester, native state import/export, SRAM import/export and corrupted ROM export to a new document. The original ROM is opened read-only.
- Read-only CRAM palette, VRAM tile and CPU/VDP register tools.
- English native menus, fullscreen landscape, optional portrait or automatic orientation. Android 16/API 36 target; Android 8/API 26 minimum.

Upstream savestate serialization is supplemented with cartridge RAM, ROM working patches, RTC timeline metadata and core context omitted by the stock serializer. Corruption writes directly to live domains. It does not modify/reload savestate files as its normal corruption mechanism.

Old JavaScript savestate files belong to the preserved prototype and are not compatible with Genesis Plus GX native states.

## Cloud builds from a phone

The source archive includes the pinned native core, frontend, build scripts, tests and license notices. No Android Studio, ADB, local shell, rooting or PC is required by the user.

1. Upload the updated `BadGenesis-source.zip` at the root of the dedicated BadGenesis repo.
2. Keep the existing native `.github/workflows/phone-upload-build.yml` workflow. For the first native setup only, use `.github/workflows/phone-native-build.yml` from the archive or paste the supplied `phone-native-build.txt` into that workflow.
3. The GitHub Actions cloud runner validates the native core, compiles Android resources and Java, builds the C/C++ core/JNI library with the Android NDK, and signs an installable `BadGenesis-Native-Android16.apk`.
4. Download the **BadGenesis-Native-Android16** artifact from the successful run.

This update is version **2.1.1**, application version code **4**. It retains the installed native APK's signing certificate, including the 2.1.0 installation, so the update keeps app data. The build checks the retained certificate before compiling and verifies the final APK certificate again. A missing or different signing key stops the build instead of silently generating a replacement.

Keep the existing native signing cache key and its `badgenesis-native-build/BadGenesis/signing/badgenesis-development.keystore` path. The native APK certificate SHA-256 is `62bb12d4f1908cb3703f3345b89b878c01663796ee9ddf5fe108b5fc49d9b1c4`. Signing keys and downloaded toolchains are excluded from the public source archive. The earlier WebView prototype had a different certificate; this update targets the installed native app.

## Validation and current status

`tools/test-native.sh` runs the actual compiled Genesis Plus GX core against an original public-domain diagnostic ROM before running live RTC and backend tests. It tests hardware frame/audio timing, native sound, input, state restoration and the corruption/rewind integration. It does not emulate Sonic in JavaScript.

The native version 2 APK completed its Android NDK/SDK cloud build on October 1, 2026: [GitHub Actions run 36916673029](https://github.com/Pappoliver681/BadGenesis/actions/runs/36916673029). All three Android ABIs compiled and the APK passed package, signature and 16 KB alignment checks. Its original source ZIP and APK are retained separately from this update.

The 2.1.0 UI/playback update passed 42 native host checks on October 2, 2026. These cover NTSC/PAL fast-forward and release, Auto Blast frame timing and fresh seeds, adjustable audible rewind at different snapshot intervals, exact reverse stereo PCM, benchmark state preservation, and compressed snapshot allocation. All four Android Java sources passed syntax parsing.

The **2.1.0** update completed its Android cloud build on October 2, 2026: [GitHub Actions run 37019243345](https://github.com/Pappoliver681/BadGenesis/actions/runs/37019243345), commit `b66872874a72c481f7c7fd98f14083be08e91124`. The cloud runner passed all 42 native checks again, compiled all three Android ABIs, and verified the signed APK with the installed native certificate and 16 KB alignment. Its APK SHA-256 is `cd5e6eb7c1f073f91c8566559349034c512b971dae5a3a4eaa9dafb387020824`.

The **2.1.1** repair addresses the reported menu layout/navigation problems, sparse rewind playback and access to manual Blast during gameplay. On October 3, 2026, its final native host validation passed **52 checks**: 10 core, 12 live RTC and 30 backend checks. `test-results/native-validation-report.json` records the results and hashes of the tested source files. The Android cloud build is still pending upload of the updated ZIP; the previous 2.1.0 APK and exact source are preserved separately. The existing phone-upload workflow and signing cache path remain unchanged.

The new rewind tests inspect actual native framebuffer pixels and recorded PCM. At 1×, 2× and 4× rewind, both 6- and 15-frame keyframe spacing produced about 59 different framebuffer images per second, with maximum measured image-update gaps of 17–21 ms on the cloud host. Each displayed frame restores the complete native state; intermediate reverse deltas prevent keyframe spacing from limiting visual cadence. The 120-second preset retained 111.71 seconds within the 96 MiB RAM limit on the diagnostic ROM. After rewinding 4,624 native frames at 16×, subsequent 2× rewind still produced 59 distinct images in one second with a maximum 17.53 ms gap and nonzero reverse audio.

The in-game Blast test issued three fresh random live-memory blasts and Undo during playback. Gameplay and real PCM continued; the longest command measured 2.89 ms on the host. Rewind across RTC blasts also restored a byte-identical full future-execution payload after resuming. These are diagnostic host measurements, not Android or Sonic performance claims.

These checks used the original diagnostic ROM. Sonic gameplay and physical-phone performance, audio latency, appearance and controller behavior still require device verification after installation.

The user-reported Sonic baseline must be checked on the native APK with RTC OFF: normal movement/jump speed, normal music pitch, smooth sustained play and no progressive slowdown. Then test CRAM, VRAM, VSRAM, Z80 RAM and 68000 RAM separately.

## Source and licenses

Genesis Plus GX is pinned to upstream commit `c2838c7dc4236fc2fe94e5dbd08b41486067918e` in `vendor/genesis-plus-gx/`. Its non-commercial license and all component notices accompany the source and APK. See `vendor/genesis-plus-gx/LICENSE.txt`, its provenance record and the app's **About → Open source licenses**.

The native build workflow also uploads the complete corresponding source archive.

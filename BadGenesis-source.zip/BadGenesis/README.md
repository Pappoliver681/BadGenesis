# BadGenesis native Android RTC

This continues the existing BadGenesis project with a native Genesis Plus GX backend. The original HTML, previous emulator, RTC design and Android wrapper are preserved in `original.html` and `reference-webview/`.

The Android app uses C/C++ emulation through JNI, native Android controls and native audio and video output. No WebView, JavaScript emulator, HTML canvas or JavaScript clock is used or packaged in the native APK.

## Native architecture

```
Genesis Plus GX C core
       |
Live memory domains + native RTC + native savestates
       |
JNI + Android frontend + native audio / Surface output
```

The native worker schedules emulated frames using the core's hardware timing, approximately 59.92 Hz NTSC or 49.70 Hz PAL. Presentation runs separately, so Android display refresh cannot advance emulation. Audio comes from the core's YM2612 and SN76489 implementations, including Z80 sound execution.

Video is sharp and unfiltered. There are no CRT effects, scanlines, curvature, phosphor effects or blur filters.

## Features

- Native ROM loading through Android's document picker, including ROM ZIPs.
- Native multitouch D-pad, A/B/C, X/Y/Z, START and MODE, with separate pointer IDs, diagonals and multiple held buttons. Three- and six-button modes.
- Adjustable control size, group positions and opacity; hide/show and vibration controls; Android Bluetooth/USB gamepad and keyboard input.
- Live 68000 Work RAM, Z80 RAM, VRAM, CRAM, VSRAM, supported cartridge RAM and optional ROM working-copy corruption. Domain metadata and a memory inspector.
- Bit Flip, Random Byte, Add, Subtract, Tilt, Zero, FF, Swap, big-endian 16/32-bit mutations and advanced 68000 NOP `4E71`.
- Blast Once, Auto Blast measured in emulated frames, intensity, domain ranges and exclusions. Fresh independent system randomness is the default. Manual seed/replay is optional; generated seeds are recorded in Blast History.
- Direct live-memory Undo with previous/new byte values and bounded history.
- Full native state rewind in a bounded RAM ring, configurable snapshot interval and 15/30/60/120-second presets. Manual Quick Save and four save slots are separate. Supported duration depends on state size and the RAM limit.
- Glitch Harvester, native state import/export, SRAM import/export and corrupted ROM export to a new document. The original ROM is opened read-only.
- Read-only CRAM palette, VRAM tile and CPU/VDP register tools.
- English native menus, fullscreen landscape, optional portrait or automatic orientation. Android 16/API 36 target; Android 8/API 26 minimum.

Upstream savestate serialization is supplemented with cartridge RAM, ROM working patches, RTC timeline metadata and core context omitted by the stock serializer. Corruption writes directly to live domains. It does not modify/reload savestate files as its normal corruption mechanism.

Old JavaScript savestate files belong to the preserved prototype and are not compatible with Genesis Plus GX native states.

## Cloud builds from a phone

The source archive includes the pinned native core, frontend, build scripts, tests and license notices. No Android Studio, ADB, local shell, rooting or PC is required by the user.

1. Upload `BadGenesis-source.zip` at the root of the dedicated BadGenesis repo.
2. Use `.github/workflows/phone-native-build.yml` from the archive as a workflow, or paste the supplied `phone-native-build.txt` into the existing `.github/workflows/phone-upload-build.yml`.
3. The GitHub Actions cloud runner validates the native core, compiles Android resources and Java, builds the C/C++ core/JNI library with the Android NDK, and signs an installable `BadGenesis-Native-Android16.apk`.
4. Download the **BadGenesis-Native-Android16** artifact from the successful run.

The development signing key is kept in the repository's existing Actions cache so a native version 2 APK can update the previous package. Signing keys and downloaded toolchains are excluded from the public source archive.

## Validation and current status

`tools/test-native.sh` runs the actual compiled Genesis Plus GX core against an original public-domain diagnostic ROM before running live RTC and backend tests. It tests hardware frame/audio timing, native sound, input, state restoration and the corruption/rewind integration. It does not emulate Sonic in JavaScript.

The native source has compiled on the cloud workspace host. A successful Android NDK/SDK build and physical phone gameplay checks must be recorded separately; host tests alone do not establish phone performance or Sonic correctness.

The user-reported Sonic baseline must be checked on the native APK with RTC OFF: normal movement/jump speed, normal music pitch, smooth sustained play and no progressive slowdown. Then test CRAM, VRAM, VSRAM, Z80 RAM and 68000 RAM separately.

## Source and licenses

Genesis Plus GX is pinned to upstream commit `c2838c7dc4236fc2fe94e5dbd08b41486067918e` in `vendor/genesis-plus-gx/`. Its non-commercial license and all component notices accompany the source and APK. See `vendor/genesis-plus-gx/LICENSE.txt`, its provenance record and the app's **About → Open source licenses**.

The native build workflow also uploads the complete corresponding source archive.

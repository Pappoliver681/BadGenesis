'use strict';
// A feasibility proof in an isolated audit VM: creates precisely the current
// full state schema directly in owned memory, retaining current export/load.
// Does not modify any production file or emulator execution method.
const fs=require('node:fs');const {loadProject}=require('../tests/dom-harness.cjs');const {makeDiagnosticROM}=require('../tests/generate-diagnostic.cjs');
const p=loadProject({audio:true,native:true,mobile:false,stripRetiredVideoHook:true});p.context.testROM=new Uint8Array(4*1024*1024);p.context.testROM.set(makeDiagnosticROM().rom);
p.run("machine.loadROM(testROM,'diagnostic.bin');machine.power(true);AndroidAudio.writePCM=()=>{};for(let i=0;i<8;i++)machine.runFrame()");
p.run(`
function auditDirectState(m,checksum=true){
 rtcEnsureOriginal(m);
 return {v:2,romName:m.romName,romChecksum:checksum?checksum16(m.rom):m._rtcBaseChecksum,pal:m.pal,
 cpu:{D:[...m.cpu.D],A:[...m.cpu.A],PC:m.cpu.PC,SR:m.cpu.SR,USP:m.cpu.USP,total:m.cpu.total,stopped:m.cpu.stopped},
 bus:{ram:m.bus.ram.slice(),zram:m.bus.zram.slice(),sramCtrl:m.bus.sramCtrl},sram:m.sram?m.sram.slice():null,
 vdp:{vram:m.vdp.vram.slice(),cram:[...m.vdp.cram],vsram:[...m.vdp.vsram],reg:[...m.vdp.reg],addr:m.vdp.addr,code:m.vdp.code,status:m.vdp.status,frame:m.vdp.frame},pad:m.pad.state(),audio:m.audio.state(),
 rtcState:{version:3,romIdentity:m._rtcRomIdentity,originalChecksum:m._rtcBaseChecksum,romPatches:rtcRomPatches(m),frame:m===machine?RTC.frame:m.frames,blastCursor:RTC.blast,historySession:RTC.historySession,activeBlasts:RTC.history.filter(h=>h.active!==false).map(h=>h.n),machine:rtcPrimitives(m),cpu:rtcPrimitives(m.cpu),vdp:rtcPrimitives(m.vdp),bus:rtcPrimitives(m.bus),ym:b64(m.bus.ym),ymAddr:b64(m.bus.ymAddr),framebufferWidth:m.vdp.img.width,framebuffer:new Uint8Array(m.vdp.pixels.buffer,m.vdp.pixels.byteOffset,m.vdp.pixels.byteLength).slice()}
 }
}
globalThis.auditOriginal=rtcSnapshot();globalThis.auditDirect=auditDirectState(machine);
`);
const serializedOriginal=p.run('JSON.stringify(rtcSerializableState(auditOriginal.state))');const serializedDirect=p.run('JSON.stringify(rtcSerializableState(auditDirect))');
if(serializedOriginal!==serializedDirect)throw Error('Direct snapshot differs from preserved current full state schema');
const directResults={schemaIdentical:true,ROMBytes:p.context.testROM.length,cases:[]};
for(const [name,call]of [['current full RTC snapshot','rtcSnapshot()'],['direct owned memory + current checksum','auditDirectState(machine)'],['direct owned memory + cached identity checksum audit-only','auditDirectState(machine,false)']]){
 const ms=JSON.parse(p.run(`JSON.stringify((()=>{const out=[];for(let r=0;r<3;r++){const t=performance.now();for(let i=0;i<80;i++){${call}}out.push((performance.now()-t)/80)}return out})())`));
 directResults.cases.push({name,costMs:ms,averageMs:ms.reduce((a,b)=>a+b)/ms.length});
}
const initialPCM=p.nativeCalls.filter(c=>c[0]==='audio:writePCM').map(c=>c[1]);p.nativeCalls.length=0;
p.run('machine.runFrame();globalThis.auditFuture=machine.state();machine.loadState(auditDirect);machine.paused=false;machine.runFrame();globalThis.auditRestoredFuture=machine.state()');
if(p.run('JSON.stringify(auditFuture)===JSON.stringify(auditRestoredFuture)')!==true)throw Error('Direct snapshot restore did not reproduce current complete future emulator state');
directResults.currentLoaderRoundTripAndNextFrameIdentical=true;
fs.writeFileSync(__dirname+'/binary-snapshot-proof.json',JSON.stringify(directResults,null,2)+'\n');console.log(JSON.stringify(directResults,null,2));

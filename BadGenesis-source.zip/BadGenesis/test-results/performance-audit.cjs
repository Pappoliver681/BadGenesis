'use strict';
// Read-only performance audit of the actual retained project. Scenario-level
// instrumentation lives solely in these VM contexts, never the runtime files.
// This is a desktop Node V8 benchmark, not an Android/browser FPS measurement.
const fs=require('node:fs');
const path=require('node:path');
const os=require('node:os');
const {loadProject}=require('../tests/dom-harness.cjs');
const {makeDiagnosticROM}=require('../tests/generate-diagnostic.cjs');
const root=path.resolve(__dirname,'..');
function project({baseline=false,audio=false,bytes=0,setup=''}={}){
  const p=loadProject({baseline,audio,native:audio,mobile:false,stripRetiredVideoHook:true});
  const diagnostic=makeDiagnosticROM().rom;
  p.context.testROM=new Uint8Array(bytes||diagnostic.length);p.context.testROM.set(diagnostic);
  p.run("machine.loadROM(testROM,'diagnostic.bin');machine.power(true)");
  p.run(`globalThis.transportBytes=0;globalThis.transportPackets=0;${audio?"AndroidAudio.writePCM=s=>{transportBytes+=s.length;transportPackets++}":''}`);
  if(setup)p.run(setup);
  p.run('for(let i=0;i<24;i++)machine.runFrame()');
  p.nativeCalls.length=0;
  return p;
}
function json(p,code){return JSON.parse(p.run(`JSON.stringify(${code})`));}
function measure(p,code,count=60,repeats=3){
  return json(p,`(()=>{const samples=[];for(let r=0;r<${repeats};r++){const t=performance.now();for(let i=0;i<${count};i++){${code}}samples.push((performance.now()-t)/${count})}return samples})()`);
}
const report={generatedAt:new Date().toISOString(),environment:{node:process.version,cpu:os.cpus()[0].model,logicalCPUs:os.cpus().length},limitations:[
  'Desktop Node V8 and diagnostic ROM only; not phone FPS, browser Canvas presentation, or native JNI/AudioTrack timing.',
  'The DOM harness records/stubs drawing and localStorage; paint, style, disk latency and WebView bridge latency are excluded.',
  'No gameplay instructions or emulated frames are skipped in production; disabled-component cases are audit-only isolated VMs.'
],scenarios:[],microbenchmarks:[]};
const cases=[
 {name:'original CPU + raster VDP, no audio or RTC',baseline:true},
 {name:'retained CPU + raster VDP + RTC, snapshots suppressed in audit VM',setup:'rtcCapture=()=>{}'},
 {name:'retained CPU + raster VDP + default RTC rewind'},
 {name:'retained CPU + raster VDP + full YM2612/PSG/Z80, snapshots suppressed in audit VM',audio:true,setup:'rtcCapture=()=>{}'},
 {name:'full Android script path + default RTC rewind + native PCM serialization',audio:true},
 {name:'full path + default RTC, playback muted but synthesis preserved',audio:true,setup:'machine.audio.enabled=false'},
 {name:'full path + 4 MiB ROM + default RTC rewind',audio:true,bytes:4*1024*1024}
];
for(const options of cases){
  global.gc?.();const p=project(options);const frameSamples=measure(p,'machine.runFrame()',80,3);
  const result={name:options.name,frameCostMs:frameSamples,averageFrameMs:frameSamples.reduce((a,b)=>a+b)/frameSamples.length,...json(p,'({frames:machine.frames,running:machine.running,romBytes:machine.rom.length,transportPackets,transportBase64Chars:transportBytes})')};
  if(!options.baseline)Object.assign(result,json(p,'({rewindSnapshots:RTC.rewind.length,rewindBytes:RTC.rewindBytes,stateBytes:RTC.rewindStateBytes,rewindProfile:rtcRewindProfile()})'));
  report.scenarios.push(result);console.log(JSON.stringify(result));
}
const p=project({audio:true,bytes:4*1024*1024});
p.run('globalThis.auditSaved=machine.state();globalThis.auditCompact=rtcCompactState(machine.state());globalThis.auditSerializable=rtcSerializableState(auditCompact);globalThis.auditPCM=new Uint8Array(2944)');
const micro=[
 ['4 MiB ROM checksum16','checksum16(machine.rom)',120],
 ['base64 encode complete 320x224 RGBA framebuffer','b64(machine.vdp.pixels)',60],
 ['base64 decode complete framebuffer','unb64(auditSaved.rtcState.framebuffer)',60],
 ['FM/Z80/PSG state creation','machine.audio.state()',60],
 ['complete machine.state()','machine.state()',30],
 ['compact existing serialized full state','rtcCompactState({...auditSaved,bus:{...auditSaved.bus},vdp:{...auditSaved.vdp},rtcState:{...auditSaved.rtcState}})',30],
 ['complete RTC snapshot (serialized then compacted)','rtcSnapshot()',30],
 ['serialize compact full state to JSON','JSON.stringify(rtcSerializableState(auditCompact))',30],
 ['restore compact full state','machine.loadState(auditCompact)',20],
 ['base64 encode one 16.7ms PCM packet','b64(auditPCM)',500],
 ['refreshUI with DOM writes stubbed','refreshUI()',120]
];
for(const [name,code,count]of micro){const samples=measure(p,code,count,3);const result={name,costMs:samples,averageMs:samples.reduce((a,b)=>a+b)/samples.length};report.microbenchmarks.push(result);console.log(JSON.stringify(result));}
p.run('machine.paused=false;rtcCapture=()=>{};globalThis.auditCounts={m68kSteps:0,fmSamples:0,psgSamples:0,z80Steps:0,framebufferUploads:0};globalThis.auditCpu=machine.cpu.step;machine.cpu.step=function(){auditCounts.m68kSteps++;return auditCpu.call(this)};globalThis.auditFm=machine.audio.fm.update;machine.audio.fm.update=function(n){auditCounts.fmSamples+=n;return auditFm.call(this,n)};globalThis.auditPsg=machine.audio.psg.sample;machine.audio.psg.sample=function(rate){auditCounts.psgSamples++;return auditPsg.call(this,rate)};globalThis.auditZ80=machine.audio.z80.step;machine.audio.z80.step=function(){auditCounts.z80Steps++;return auditZ80.call(this)};globalThis.auditUpload=machine.vdp.endFrame;machine.vdp.endFrame=function(){auditCounts.framebufferUploads++;return auditUpload.call(this)};machine.runFrame()');
report.operationsPerDiagnosticFrame=json(p,'auditCounts');
report.serializedStateChars=p.run('JSON.stringify(auditSerializable).length');
report.fmStateChars=p.run('JSON.stringify(auditSerializable.audio.fm).length');
report.compactStateBytes=p.run('rtcStateBytes(auditCompact)');
report.auditSourceSHA256=require('node:crypto').createHash('sha256').update(fs.readFileSync(path.join(root,'app/src/main/assets/core.js'))).digest('hex');
const target=path.join(__dirname,'performance-audit.json');fs.writeFileSync(target,JSON.stringify(report,null,2)+'\n');console.log(`Audit written to ${target}`);

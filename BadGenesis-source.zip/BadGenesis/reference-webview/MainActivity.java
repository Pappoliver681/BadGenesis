package com.badgenesis.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.hardware.input.InputManager;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Base64;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import org.json.JSONObject;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** Native phone shell: document I/O, gamepad input, audio output, lifecycle and display. */
public final class MainActivity extends Activity implements InputManager.InputDeviceListener {
    private static final String ORIGIN = "https://appassets.androidplatform.net";
    private static final String PAGE = ORIGIN + "/assets/BadGenesis.html";
    private static final int PICK_FILE = 41, EXPORT_FILE = 42;
    private final Handler main = new Handler(Looper.getMainLooper());
    private WebView web;
    private NativeAudio audio;
    private InputManager inputManager;
    private ValueCallback<Uri[]> fileCallback;
    private byte[] exportBytes;
    private boolean resumed, focused = true, gameplay;
    private volatile boolean vibrationEnabled = true;
    private Vibrator vibrator;
    private OnBackInvokedCallback backCallback;
    private String wantedOrientation = "landscape";
    private final Map<Integer, Set<String>> padKeys = new HashMap<>();
    private final Set<String> sentKeys = new HashSet<>();

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = Build.VERSION.SDK_INT >= 30
                ? WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                : WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        audio = new NativeAudio();
        vibrator = (Vibrator)getSystemService(VIBRATOR_SERVICE);
        if (Build.VERSION.SDK_INT >= 33) {
            backCallback = this::requestBack;
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT, backCallback);
        }
        inputManager = (InputManager)getSystemService(INPUT_SERVICE);
        inputManager.registerInputDeviceListener(this, main);
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(16, 16, 18));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true); // SAF URIs returned only by the system file picker.
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportMultipleWindows(false);
        web.addJavascriptInterface(new AppBridge(), "AndroidApp");
        web.addJavascriptInterface(audio, "AndroidAudio");
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (!"https".equals(u.getScheme()) || !"appassets.androidplatform.net".equals(u.getHost())
                        || u.getPort() != -1 || !"GET".equals(request.getMethod())) return denied();
                String path = u.getPath();
                if (path == null || !path.startsWith("/assets/") || path.contains("..") || path.contains("\\")) return denied();
                String file = path.substring(8);
                try {
                    InputStream in = getAssets().open(file);
                    String mime = file.endsWith(".html") ? "text/html" : file.endsWith(".js") ? "application/javascript"
                        : file.endsWith(".css") ? "text/css" : file.endsWith(".json") ? "application/json"
                        : file.endsWith(".png") ? "image/png" : "application/octet-stream";
                    WebResourceResponse out = new WebResourceResponse(mime, "UTF-8", in);
                    Map<String, String> h = new HashMap<>();
                    h.put("X-Content-Type-Options", "nosniff");
                    h.put("Content-Security-Policy", "default-src 'self' data: blob:; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; connect-src 'none'; frame-src 'none'; object-src 'none'");
                    out.setResponseHeaders(h);
                    return out;
                } catch (IOException e) { return denied(); }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return !PAGE.equals(r.getUrl().toString());
            }
            @Override public void onPageFinished(WebView v, String url) {
                if (PAGE.equals(url)) { sendConnected(); dispatchLifecycle(); applyInsets(); }
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType("*/*"); // ROM extensions have no consistent Android MIME type.
                pick.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                try { startActivityForResult(pick, PICK_FILE); }
                catch (RuntimeException e) { fileCallback.onReceiveValue(null); fileCallback = null; notifyUser("No document picker is available"); }
                return true;
            }
        });
        web.setDownloadListener((url, agent, disposition, mime, length) -> notifyUser("Use Export to save this file"));
        setContentView(web);
        web.setOnApplyWindowInsetsListener((v, insets) -> { main.post(this::applyInsets); return insets; });
        immersive();
        web.loadUrl(PAGE);
    }

    private static WebResourceResponse denied() {
        return new WebResourceResponse("text/plain", "UTF-8", 403, "Forbidden", new HashMap<>(), new ByteArrayInputStream(new byte[0]));
    }
    private void js(String source) { if (web != null) main.post(() -> { if (web != null) web.evaluateJavascript(source, null); }); }
    private void notifyUser(String message) { main.post(() -> Toast.makeText(this, message, Toast.LENGTH_SHORT).show()); }
    private void immersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) { c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE); c.hide(WindowInsets.Type.systemBars()); }
        } else getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }
    private void applyInsets() {
        if (web == null) return;
        WindowInsets w = web.getRootWindowInsets();
        int left=0, top=0, right=0, bottom=0;
        if (w != null && Build.VERSION.SDK_INT >= 28 && w.getDisplayCutout() != null) {
            left=w.getDisplayCutout().getSafeInsetLeft(); top=w.getDisplayCutout().getSafeInsetTop();
            right=w.getDisplayCutout().getSafeInsetRight(); bottom=w.getDisplayCutout().getSafeInsetBottom();
        }
        float d=getResources().getDisplayMetrics().density;
        js("(()=>{const s=document.documentElement.style;s.setProperty('--native-safe-left','"+(left/d)+"px');s.setProperty('--native-safe-top','"+(top/d)+"px');s.setProperty('--native-safe-right','"+(right/d)+"px');s.setProperty('--native-safe-bottom','"+(bottom/d)+"px');window.BadGenesisInsetsChanged&&window.BadGenesisInsetsChanged()})()");
    }
    private void dispatchLifecycle() {
        boolean pause = !resumed || !focused;
        audio.setForeground(!pause);
        js("window.BadGenesisLifecycle&&window.BadGenesisLifecycle("+pause+")");
    }
    @Override protected void onResume() {
        super.onResume(); resumed=true; if (web != null) { web.onResume(); web.resumeTimers(); }
        immersive(); audio.requestFocusIfEnabled(); dispatchLifecycle();
    }
    @Override protected void onPause() {
        resumed=false; releasePads(); dispatchLifecycle(); audio.abandonFocus();
        if (web != null) { web.onPause(); web.pauseTimers(); }
        super.onPause();
    }
    @Override protected void onDestroy() {
        inputManager.unregisterInputDeviceListener(this); audio.close();
        if (vibrator != null) vibrator.cancel();
        if (Build.VERSION.SDK_INT >= 33 && backCallback != null) getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(backCallback);
        if (fileCallback != null) fileCallback.onReceiveValue(null);
        if (web != null) { web.removeJavascriptInterface("AndroidApp"); web.removeJavascriptInterface("AndroidAudio"); web.destroy(); web=null; }
        exportBytes=null; super.onDestroy();
    }
    @Override public void onConfigurationChanged(Configuration c) { super.onConfigurationChanged(c); immersive(); applyInsets(); }
    @Override public void onWindowFocusChanged(boolean hasFocus) { super.onWindowFocusChanged(hasFocus); if (hasFocus) immersive(); }
    @Override public void onBackPressed() { requestBack(); }
    private void requestBack() {
        if (web == null) return;
        web.evaluateJavascript("window.BadGenesisBack?window.BadGenesisBack():false", value -> {
            if (!"true".equals(value)) new AlertDialog.Builder(this).setTitle("Exit BadGenesis?")
                .setMessage("Your saved slots and battery saves are kept on this phone.")
                .setNegativeButton("Cancel", null).setPositiveButton("Exit", (d, which) -> finish()).show();
        });
    }

    private final class AppBridge {
        @JavascriptInterface public void enterGameplay() { main.post(() -> { gameplay=true; getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); applyOrientation(); immersive(); }); }
        @JavascriptInterface public void exitGameplay() { main.post(() -> { gameplay=false; getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_FULL_USER); immersive(); }); }
        @JavascriptInterface public void setOrientation(String orientation) { main.post(() -> { wantedOrientation="portrait".equals(orientation)?"portrait":"landscape".equals(orientation)?"landscape":"auto"; applyOrientation(); }); }
        @JavascriptInterface public void setVibrationEnabled(boolean enabled) {
            vibrationEnabled=enabled;
            if (!enabled && vibrator != null) main.post(vibrator::cancel);
        }
        @JavascriptInterface public void vibrate(long milliseconds) {
            if (!vibrationEnabled || milliseconds <= 0 || vibrator == null) return;
            final long duration=Math.min(milliseconds,250);
            main.post(() -> {
                if (!vibrationEnabled || !resumed || !vibrator.hasVibrator()) return;
                try { vibrator.vibrate(VibrationEffect.createOneShot(duration,VibrationEffect.DEFAULT_AMPLITUDE)); }
                catch (SecurityException ignored) { }
            });
        }
        @JavascriptInterface public void copyText(String text) { main.post(() -> ((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("BadGenesis log", text))); }
        @JavascriptInterface public void exportFile(String name, String base64, String mime) {
            if (base64 == null || base64.length()>64*1024*1024) { notifyUser("Export is too large"); return; }
            final byte[] data;
            try { data=Base64.decode(base64, Base64.DEFAULT); } catch (IllegalArgumentException e) { notifyUser("Export data is invalid"); return; }
            String safeName = name == null ? "BadGenesis.bin" : name.replaceAll("[\\\\/\\p{Cntrl}]", "_");
            main.post(() -> {
                if (exportBytes != null) { notifyUser("Finish the current export first"); return; }
                exportBytes=data;
                Intent save = new Intent(Intent.ACTION_CREATE_DOCUMENT); save.addCategory(Intent.CATEGORY_OPENABLE);
                save.setType(mime != null && mime.matches("[a-zA-Z0-9.+-]+/[a-zA-Z0-9.+-]+") ? mime : "application/octet-stream");
                save.putExtra(Intent.EXTRA_TITLE, safeName); save.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                try { startActivityForResult(save, EXPORT_FILE); } catch (RuntimeException e) { exportBytes=null; notifyUser("No document picker is available"); }
            });
        }
    }
    private void applyOrientation() {
        int requested="portrait".equals(wantedOrientation)?ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            :"landscape".equals(wantedOrientation)?ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE:ActivityInfo.SCREEN_ORIENTATION_FULL_USER;
        setRequestedOrientation(requested);
    }
    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request==PICK_FILE) {
            if (fileCallback==null) return;
            Uri[] files=null;
            if (result==RESULT_OK && data!=null) {
                ClipData clip=data.getClipData();
                if (clip != null) { files=new Uri[clip.getItemCount()]; for (int i=0;i<files.length;i++) files[i]=clip.getItemAt(i).getUri(); }
                else if (data.getData()!=null) files=new Uri[]{data.getData()};
                if (files!=null) for (Uri uri:files) try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (SecurityException ignored) { }
            }
            fileCallback.onReceiveValue(files); fileCallback=null;
        } else if (request==EXPORT_FILE) {
            final byte[] bytes=exportBytes; exportBytes=null;
            if (result==RESULT_OK && data!=null && data.getData()!=null && bytes!=null) {
                Uri uri=data.getData();
                new Thread(() -> { try (OutputStream out=getContentResolver().openOutputStream(uri, "wt")) {
                    if (out==null) throw new IOException("No output stream"); out.write(bytes); notifyUser("File exported");
                } catch (IOException | SecurityException e) { notifyUser("Export failed: "+e.getMessage()); } }, "BadGenesis export").start();
            }
        }
    }

    private boolean isPad(InputDevice d) { return d!=null && ((d.getSources()&InputDevice.SOURCE_GAMEPAD)==InputDevice.SOURCE_GAMEPAD || (d.getSources()&InputDevice.SOURCE_JOYSTICK)==InputDevice.SOURCE_JOYSTICK); }
    private String padButton(int code) {
        switch (code) {
            case KeyEvent.KEYCODE_DPAD_UP: return "up"; case KeyEvent.KEYCODE_DPAD_DOWN: return "down";
            case KeyEvent.KEYCODE_DPAD_LEFT: return "left"; case KeyEvent.KEYCODE_DPAD_RIGHT: return "right";
            case KeyEvent.KEYCODE_BUTTON_X: return "a"; case KeyEvent.KEYCODE_BUTTON_A: return "b";
            case KeyEvent.KEYCODE_BUTTON_B: return "c"; case KeyEvent.KEYCODE_BUTTON_Y: return "z";
            case KeyEvent.KEYCODE_BUTTON_L1: return "x"; case KeyEvent.KEYCODE_BUTTON_R1: return "y";
            case KeyEvent.KEYCODE_BUTTON_C: return "c"; case KeyEvent.KEYCODE_BUTTON_Z: return "z";
            case KeyEvent.KEYCODE_BUTTON_START: return "start"; case KeyEvent.KEYCODE_BUTTON_SELECT: return "mode";
            case KeyEvent.KEYCODE_BUTTON_MODE: return "mode"; default: return null;
        }
    }
    @Override public boolean dispatchKeyEvent(KeyEvent e) {
        if (isPad(e.getDevice())) {
            String button=padButton(e.getKeyCode());
            if (button!=null) { Set<String> held=padKeys.computeIfAbsent(e.getDeviceId(), k -> new HashSet<>());
                if (e.getAction()==KeyEvent.ACTION_DOWN) held.add(button); else if (e.getAction()==KeyEvent.ACTION_UP) held.remove(button);
                mergePads(); return true;
            }
        }
        return super.dispatchKeyEvent(e);
    }
    private float axis(MotionEvent e, int axis) {
        InputDevice.MotionRange range=e.getDevice().getMotionRange(axis,e.getSource());
        float value=e.getAxisValue(axis); return range!=null && Math.abs(value)>Math.max(range.getFlat(), 0.20f) ? value : 0;
    }
    @Override public boolean dispatchGenericMotionEvent(MotionEvent e) {
        if (isPad(e.getDevice()) && e.getAction()==MotionEvent.ACTION_MOVE) {
            // Analog directions use separate source IDs so a held D-pad key is preserved.
            Set<String> analog=padKeys.computeIfAbsent(-e.getDeviceId()-1, k -> new HashSet<>()); analog.clear();
            float x=axis(e,MotionEvent.AXIS_X), y=axis(e,MotionEvent.AXIS_Y), hx=axis(e,MotionEvent.AXIS_HAT_X), hy=axis(e,MotionEvent.AXIS_HAT_Y);
            if (x<-.4f || hx<-.4f) analog.add("left"); if (x>.4f || hx>.4f) analog.add("right");
            if (y<-.4f || hy<-.4f) analog.add("up"); if (y>.4f || hy>.4f) analog.add("down");
            mergePads(); return true;
        }
        return super.dispatchGenericMotionEvent(e);
    }
    private void mergePads() {
        Set<String> next=new HashSet<>(); for (Set<String> held:padKeys.values()) next.addAll(held);
        for (String k:new HashSet<>(sentKeys)) if (!next.contains(k)) js("window.BadGenesisNativePad&&window.BadGenesisNativePad("+JSONObject.quote(k)+",false)");
        for (String k:next) if (!sentKeys.contains(k)) js("window.BadGenesisNativePad&&window.BadGenesisNativePad("+JSONObject.quote(k)+",true)");
        sentKeys.clear(); sentKeys.addAll(next);
    }
    private void releasePads() { padKeys.clear(); sentKeys.clear(); js("window.BadGenesisNativePad&&window.BadGenesisNativePad('releaseAll',false)"); }
    private void sendConnected() { boolean connected=false; for (int id:inputManager.getInputDeviceIds()) if (isPad(inputManager.getInputDevice(id))) connected=true; js("window.BadGenesisNativePad&&window.BadGenesisNativePad('connected',"+connected+")"); }
    @Override public void onInputDeviceAdded(int id) { sendConnected(); }
    @Override public void onInputDeviceChanged(int id) { padKeys.remove(id); padKeys.remove(-id-1); mergePads(); sendConnected(); }
    @Override public void onInputDeviceRemoved(int id) { padKeys.remove(id); padKeys.remove(-id-1); mergePads(); sendConnected(); }

    /** PCM is synthesized by the real YM2612/PSG implementation; Android only plays samples. */
    private final class NativeAudio {
        private final Object lock=new Object();
        private final ArrayDeque<Packet> queue=new ArrayDeque<>();
        private final AudioManager manager=(AudioManager)getSystemService(AUDIO_SERVICE);
        private final AudioAttributes attributes=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();
        private final AudioFocusRequest focus=new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(attributes).setOnAudioFocusChangeListener(change -> main.post(() -> {
                focused=change==AudioManager.AUDIOFOCUS_GAIN; dispatchLifecycle();
            }),main).build();
        private volatile boolean enabled, foreground, closed;
        private AudioTrack track;
        private int generation;
        private final Thread worker;
        NativeAudio() { worker=new Thread(this::drain,"BadGenesis AudioTrack"); worker.start(); }
        @JavascriptInterface public void writePCM(String base64) {
            if (!enabled || !foreground || closed || base64==null || base64.length()>65536) return;
            byte[] pcm; try { pcm=Base64.decode(base64,Base64.DEFAULT); } catch (IllegalArgumentException e) { return; }
            if (pcm.length==0 || pcm.length%4!=0) return;
            synchronized(lock) { if (!enabled || !foreground) return; while(queue.size()>=6) queue.removeFirst(); queue.addLast(new Packet(pcm,generation)); lock.notifyAll(); }
        }
        @JavascriptInterface public void flush() {
            synchronized(lock) { generation++; queue.clear(); if (track!=null) { try { track.pause(); track.flush(); } catch (IllegalStateException ignored) { } } lock.notifyAll(); }
        }
        @JavascriptInterface public void setEnabled(boolean value) {
            enabled=value;
            if (value) main.post(() -> { requestFocusIfEnabled(); dispatchLifecycle(); });
            else { flush(); main.post(() -> { abandonFocus(); focused=true; dispatchLifecycle(); }); }
        }
        void requestFocusIfEnabled() { if (enabled && resumed) { focused=manager.requestAudioFocus(focus)==AudioManager.AUDIOFOCUS_REQUEST_GRANTED; foreground=resumed&&focused; } }
        void abandonFocus() { manager.abandonAudioFocusRequest(focus); }
        void setForeground(boolean value) { foreground=value; if (!value) flush(); synchronized(lock) { lock.notifyAll(); } }
        private AudioTrack createTrack() {
            int min=AudioTrack.getMinBufferSize(44100,AudioFormat.CHANNEL_OUT_STEREO,AudioFormat.ENCODING_PCM_16BIT);
            return new AudioTrack.Builder().setAudioAttributes(attributes).setAudioFormat(new AudioFormat.Builder()
                .setSampleRate(44100).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                .setTransferMode(AudioTrack.MODE_STREAM).setBufferSizeInBytes(Math.max(min,4410*4))
                .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY).build();
        }
        private void drain() {
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_AUDIO);
            while(!closed) {
                Packet packet;
                synchronized(lock) {
                    while(!closed && (!enabled || !foreground || queue.isEmpty())) try { lock.wait(); } catch (InterruptedException ignored) { }
                    if (closed) break; packet=queue.removeFirst();
                    if (packet.generation!=generation) continue;
                    try { if(track==null) track=createTrack(); if(track.getPlayState()!=AudioTrack.PLAYSTATE_PLAYING) track.play(); }
                    catch (RuntimeException error) { if(track!=null) { track.release(); track=null; } queue.clear(); notifyUser("Audio output could not start"); continue; }
                }
                int offset=0;
                while(offset<packet.pcm.length && !closed && enabled && foreground) {
                    final int written;
                    synchronized(lock) {
                        if(packet.generation!=generation || track==null) break;
                        // A save/load/rewind flush cannot race a write of old PCM.
                        written=track.write(packet.pcm,offset,packet.pcm.length-offset,AudioTrack.WRITE_NON_BLOCKING);
                    }
                    if(written<0) { flush(); break; }
                    if(written==0) { try { Thread.sleep(2); } catch(InterruptedException ignored) { } } else offset+=written;
                }
            }
            synchronized(lock) { if(track!=null) { track.release(); track=null; } }
        }
        void close() { closed=true; flush(); abandonFocus(); worker.interrupt(); }
        private final class Packet { final byte[] pcm; final int generation; Packet(byte[] p,int g) { pcm=p;generation=g; } }
    }
}

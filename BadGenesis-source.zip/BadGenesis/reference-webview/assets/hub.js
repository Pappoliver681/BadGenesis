
(function(){
  'use strict';
  var JSD_SYS='megadrive';
  var m=(location.hash||'').match(/(?:^#|&)jsdlaunch=([^&]+)/);
  var JSD_TOKEN=m?decodeURIComponent(m[1]):'';
  var JSD_PARENT=null;
  function jsdPostTo(target,type,extra){try{if(target)target.postMessage(Object.assign({type:type,token:JSD_TOKEN,system:JSD_SYS},extra||{}),'*')}catch(_){}}
  function jsdPost(type,extra){jsdPostTo(JSD_PARENT||window.opener,type,extra)}
  function jsdFile(x){return new File([x.bytes],x.name||'game.bin',{type:'application/octet-stream',lastModified:Date.now()})}
  function jsdRole(p,r){return (p.files||[]).filter(function(x){return x.role===r})}
  function jsdSet(id,files,fire){var el=document.querySelector(id);if(!el||!files.length)return null;var dt=new DataTransfer();files.forEach(function(f){dt.items.add(f)});el.files=dt.files;if(fire!==false)el.dispatchEvent(new Event('change',{bubbles:true}));return el}
  function jsdSleep(ms){return new Promise(function(r){setTimeout(r,ms)})}
  function jsdWaitUntil(test,ms){return new Promise(function(resolve,reject){var t=Date.now();(function poll(){try{if(test())return resolve()}catch(_){}if(Date.now()-t>=ms)return reject(new Error('ROM received but the core did not load it'));setTimeout(poll,50)})()})}
  async function jsdInject(p){
    var games=jsdRole(p,'game').map(jsdFile),bios=jsdRole(p,'bios').map(jsdFile),execs=jsdRole(p,'exec').map(jsdFile),groms=jsdRole(p,'grom').map(jsdFile);
    var game=games[0]||null;
    if(JSD_SYS==='gameboy'){jsdSet('#romFile',games);await jsdWaitUntil(function(){return !!((typeof gba!=='undefined'&&gba&&gba.rom)||(typeof machine!=='undefined'&&machine&&machine.cart&&machine.cart.rom))},5000);var b=document.querySelector('#powerBtn');if(b)b.click()}
    else if(JSD_SYS==='sega'){if(bios[0]){var bi=jsdSet('#biosFile',[bios[0]],false);await fileLoad(bi,'bios')}if(game){var ri=jsdSet('#romFile',[game],false);await fileLoad(ri,'rom');if(!machine.romInfo)throw new Error('ROM SEGA not loaded')}}
    else if(JSD_SYS==='megadrive'){if(game){await loadFile(game);if(!machine.rom)throw new Error('ROM Mega Drive not loaded');machine.power(true);refreshUI()}}
    else if(JSD_SYS==='neogeo'){if(bios.length)await loadPackage(bios,'bios');if(games.length)await loadPackage(games,'game');ngPower();if(typeof ngToggleRun==='function')ngToggleRun()}
    else if(JSD_SYS==='nes'){if(game){await loadFile(game);if(!nes.cart)throw new Error('ROM NES not loaded');if(!nes.powered)power()}}
    else if(JSD_SYS==='snes'){if(game){jsdSet('#romFile',[game],false);await loadSelected();if(!emu||!emu.cart)throw new Error('ROM SNES not loaded');await jsdSleep(80);if(!emu.running)document.querySelector('#runBtn')?.click()}}
    else if(JSD_SYS==='pce'){if(game){await loadROM(game);if(!(bus.rom&&bus.rom.length)&&!bus.hesMode)throw new Error('ROM PC Engine not loaded')}}
    else if(JSD_SYS==='coleco'){if(bios[0]){machine.loadBios(new Uint8Array(await bios[0].arrayBuffer()),bios[0].name);document.querySelector('#biosInfo').textContent=bios[0].name}if(game){machine.loadCart(new Uint8Array(await game.arrayBuffer()),game.name);document.querySelector('#romInfo').textContent=game.name}if(game&&!machine.cart)throw new Error('ROM Coleco not loaded');if(machine.bios&&machine.cart&&!machine.powered){machine.power(true);running=true}refreshStatus()}
    else if(JSD_SYS==='spectrum'){if(bios[0])machine.setROM(new Uint8Array(await bios[0].arrayBuffer()),bios[0].name);if(game){var u=new Uint8Array(await game.arrayBuffer()),x=(game.name.split('.').pop()||'').toLowerCase();if(x==='sna'||x==='z80')machine.loadSnapshot(x==='sna'?parseSNA(u):parseZ80(u));else if(x==='tap'){machine.tape=new Tape(parseTAP(u));machine.autoLoad()}else if(x==='scr'){machine.reset();machine.paused=true;machine.mem.set(u,0x4000);machine.drawFull()}document.querySelector('#gameName').textContent=game.name;render();refresh()}}
    else if(JSD_SYS==='msx1'){if(bios[0])machine.loadBios(new Uint8Array(await bios[0].arrayBuffer()),bios[0].name);if(game)machine.loadCart(new Uint8Array(await game.arrayBuffer()),game.name);if(game&&!machine.cart)throw new Error('ROM MSX not loaded');if(machine.bios&&machine.cart&&!machine.powered){machine.power(true);running=true}refreshStatus()}
    else if(JSD_SYS==='intellivision'){if(execs[0])await loadFile('exec',execs[0]);if(groms[0])await loadFile('grom',groms[0]);if(game)await loadFile('cart',game);if(!state.power)boot();reset();if(state.paused)togglePause()}
    else if(JSD_SYS==='vectrex'){if(bios[0])machine.loadBios(new Uint8Array(await bios[0].arrayBuffer()),bios[0].name);if(game)machine.loadCart(new Uint8Array(await game.arrayBuffer()),game.name);if(game&&!machine.cartLoaded)throw new Error('ROM Vectrex not loaded');if(machine.biosLoaded&&machine.cartLoaded){machine.reset();machine.running=true}machine.updateUI();renderMachineText()}
    jsdPost('jsd-launch-accepted',{files:(p.files||[]).length});
  }
  window.addEventListener('message',function(ev){
    if(!JSD_TOKEN||!ev.data||ev.data.token!==JSD_TOKEN||ev.data.system!==JSD_SYS)return;
    if(ev.data.type==='jsd-probe'){
      JSD_PARENT=ev.source||JSD_PARENT;
      jsdPostTo(JSD_PARENT,'jsd-emulator-ready');
      return;
    }
    if(ev.data.type!=='jsd-launch')return;
    JSD_PARENT=ev.source||JSD_PARENT;
    jsdInject(ev.data).catch(function(err){console.error(err);jsdPost('jsd-launch-error',{error:err&&err.message?err.message:String(err)})});
  });
  // Backward-compatible proactive ready signal when opener is available.
  function ready(){if(JSD_TOKEN&&window.opener)jsdPostTo(window.opener,'jsd-emulator-ready')}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',ready,{once:true});else ready();

})();


(function(){
'use strict';
var JSD_SAVE_SYS='megadrive';
function metaFor(k){try{return JSON.parse(localStorage.getItem('jsd-save-meta:'+k)||'null')||{}}catch(_){return{}}}
function allowed(k){
  if(!k||k.indexOf('jsd-save-meta:')===0||k.indexOf('jsd-save-bank:')===0||/_rtc$/.test(k))return false;
  if(JSD_SAVE_SYS==='gameboy')return /^gbjsd_[0-9a-f]+_/i.test(k)||/^gbxjsd_clean_gba_/i.test(k);
  if(JSD_SAVE_SYS==='sega')return /^segajsd:sram:/i.test(k);
  if(JSD_SAVE_SYS==='megadrive')return /^mdjsd:sram:/i.test(k);
  if(JSD_SAVE_SYS==='nes')return /^nesjsd:sram:/i.test(k)||/^nesjsd_sram_/i.test(k);
  if(JSD_SAVE_SYS==='pce')return /^pcejsd:bram:/i.test(k);
  if(JSD_SAVE_SYS==='neogeo')return k==='neogeojsd.mvs.backup.v137';
  return false;
}
function defaultMeta(k,v){
  var m=metaFor(k);if(m&&Object.keys(m).length)return m;
  if(JSD_SAVE_SYS==='neogeo')return{system:'neogeo',name:'Neo Geo MVS Backup RAM',format:'brm',size:65536,updated:0};
  if(JSD_SAVE_SYS==='sega')return{system:'sega',name:'Master System / Game Gear SRAM',format:'sav',size:32768,updated:0};
  return{system:JSD_SAVE_SYS,name:k,format:JSD_SAVE_SYS==='megadrive'?'srm':'sav',size:0,updated:0};
}
function list(){var out=[];try{for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i);if(!allowed(k))continue;var v=localStorage.getItem(k);if(!v)continue;out.push({key:k,data_base64:v,meta:defaultMeta(k,v),rtc:localStorage.getItem(k+'_rtc')||null})}}catch(_){}return out}
function reply(ev,type,extra){try{if(ev.source)ev.source.postMessage(Object.assign({type:type,token:ev.data.token,system:JSD_SAVE_SYS},extra||{}),'*')}catch(_){}}
window.addEventListener('message',function(ev){var d=ev.data;if(!d||!d.token||d.system!==JSD_SAVE_SYS)return;
  if(d.type==='jsd-save-probe'){reply(ev,'jsd-save-list',{entries:list()});return}
  if(d.type==='jsd-save-write'){
    try{if(!allowed(d.key))throw new Error('save key is not allowed');localStorage.setItem(d.key,String(d.data_base64||''));if(d.meta)localStorage.setItem('jsd-save-meta:'+d.key,JSON.stringify(d.meta));if(d.rtc!==undefined&&d.rtc!==null)localStorage.setItem(d.key+'_rtc',String(d.rtc));else if(d.clearRtc)localStorage.removeItem(d.key+'_rtc');reply(ev,'jsd-save-write-ok',{key:d.key})}catch(e){reply(ev,'jsd-save-error',{error:e.message||String(e)})}return
  }
  if(d.type==='jsd-save-delete'){
    try{if(!allowed(d.key))throw new Error('save key is not allowed');localStorage.removeItem(d.key);localStorage.removeItem('jsd-save-meta:'+d.key);localStorage.removeItem(d.key+'_rtc');reply(ev,'jsd-save-delete-ok',{key:d.key})}catch(e){reply(ev,'jsd-save-error',{error:e.message||String(e)})}
  }
});
})();

/* BadGenesis sound integration. The retained 68000/VDP core drives actual
 * YM2612 synthesis, Sega SN76489 PSG and the Z80 sound CPU by emulated clocks.
 * Android uses native AudioTrack; ordinary browsers use Web Audio. */
'use strict';

class GenesisPSG {
  constructor(clock) { this.clock = clock; this.attenuation = Array.from({length:16}, (_, v) => v === 15 ? 0 : Math.pow(10, -v / 10)); this.reset(); }
  reset() {
    this.tone = [0, 0, 0]; this.volume = [15, 15, 15, 15];
    this.counter = [1, 1, 1, 16]; this.level = [1, 1, 1, 1];
    this.noise = 0; this.lfsr = 0x8000; this.latch = 0; this.fraction = 0;
  }
  write(v) {
    v &= 255;
    if (v & 128) this.latch = (v >>> 4) & 7;
    const channel = this.latch >>> 1;
    if (this.latch & 1) this.volume[channel] = v & 15;
    else if (channel === 3) {
      this.noise = v & 7; this.lfsr = 0x8000;
      this.counter[3] = this.noisePeriod(); this.level[3] = 1;
    } else if (v & 128) this.tone[channel] = (this.tone[channel] & 0x3f0) | (v & 15);
    else this.tone[channel] = (this.tone[channel] & 15) | ((v & 63) << 4);
  }
  period(channel) { return Math.max(1, this.tone[channel]); }
  noisePeriod() { return (this.noise & 3) === 3 ? this.period(2) : 16 << (this.noise & 3); }
  amplitude() {
    let output = 0;
    for (let ch = 0; ch < 4; ch++) {
      if (this.volume[ch] === 15) continue;
      // Sega tone periods 0/1 stay high rather than aliasing at ultrasonic rates.
      const sign = ch === 3 ? ((this.lfsr & 1) ? 1 : -1) : this.tone[ch] < 2 ? 1 : this.level[ch];
      output += sign * this.attenuation[this.volume[ch]];
    }
    return output;
  }
  tick() {
    for (let ch = 0; ch < 3; ch++) if (--this.counter[ch] <= 0) {
      this.counter[ch] += this.period(ch); this.level[ch] = -this.level[ch];
    }
    if (--this.counter[3] <= 0) {
      this.counter[3] += this.noisePeriod(); this.level[3] = -this.level[3];
      if (this.level[3] > 0) {
        const feedback = (this.noise & 4) ? ((this.lfsr ^ (this.lfsr >>> 3)) & 1) : this.lfsr & 1;
        this.lfsr = (this.lfsr >>> 1) | (feedback << 15);
      }
    }
  }
  sample(rate) {
    // Integrate the real divider's square/noise signal over this sample window.
    let remaining = this.clock / (16 * rate), sum = 0;
    const duration = remaining;
    while (remaining > 1e-10) {
      const portion = Math.min(remaining, 1 - this.fraction);
      sum += this.amplitude() * portion; remaining -= portion; this.fraction += portion;
      if (this.fraction >= 1 - 1e-10) { this.fraction = 0; this.tick(); }
    }
    return sum / duration;
  }
  state() {
    return { clock: this.clock, tone: [...this.tone], volume: [...this.volume], counter: [...this.counter],
      level: [...this.level], noise: this.noise, lfsr: this.lfsr, latch: this.latch, fraction: this.fraction };
  }
  loadState(s) {
    for (const field of ['tone','volume','counter','level']) this[field] = [...s[field]];
    for (const field of ['clock','noise','lfsr','latch','fraction']) this[field] = s[field];
  }
}

class GenesisAudio {
  constructor(m) {
    this.m = m; this.sampleRate = 44100; this.enabled = true; this.foreground = true;
    this.context = null; this.nodes = new Set(); this.nextTime = 0; this.pcm = [];
    this.fm = new YM2612();
    this.z80 = new GenesisZ80(a => this.zread(a), (a, v) => this.zwrite(a, v), () => 255, () => {});
    this.psg = new GenesisPSG(3579545); this.reset();
  }
  reset() {
    this.masterClock = this.m.pal ? 53203424 : 53693175;
    this.fmClock = this.masterClock / 7; this.nativeRate = this.fmClock / 144;
    this.psg.clock = this.masterClock / 15; this.psg.reset();
    this.fm.init(this.fmClock, this.nativeRate); this.fm.reset(); this.z80.reset();
    this.bank = 0; this.z80Credit = 0; this.fmCycles = 0; this.outputPhase = 0;
    this.previousLeft = 0; this.previousRight = 0; this.irqCycles = 0; this.totalZ80Cycles = 0;
    this.fmBusyCycles = 0; this.flush();
  }
  setControl(kind, value) {
    const b = this.m.bus;
    if (kind === 'reset' && b.z80Reset && !value) {
      this.z80.reset(); this.bank = 0; this.z80Credit = 0;
      this.fm.reset(); b.ym.fill(0); b.ymAddr.fill(0); b.ymStatus = 0; this.fmBusyCycles = 0;
    }
    if (kind === 'reset') b.z80Reset = value;
    else b.z80BusReq = value;
  }
  busStatus() { return (!this.m.bus.z80BusReq && this.m.bus.z80Reset) ? 1 : 0; }
  ymRead() { this.m.bus.ymStatus = this.fm.read() | (this.fmBusyCycles > 0 ? 0x80 : 0); return this.m.bus.ymStatus; }
  ymWrite(port, value) {
    const bus = this.m.bus, bank = (port >>> 1) & 1;
    if (!(port & 1)) bus.ymAddr[bank] = value & 255;
    else { const address = (bank << 8) | bus.ymAddr[bank]; bus.ym[address] = value & 255; this.fm.write(address, value); this.fmBusyCycles = 32; }
  }
  zread(address) {
    address &= 65535;
    if (address < 0x4000) return this.m.bus.zram[address & 0x1fff];
    if (address < 0x6000) return this.ymRead();
    if (address >= 0x8000) {
      const mapped = ((this.bank << 15) | (address & 0x7fff)) & 0xffffff;
      if (mapped >= 0xa00000 && mapped <= 0xa0ffff) return 255;
      return this.m.bus.rb(mapped);
    }
    return 255;
  }
  zwrite(address, value) {
    address &= 65535; value &= 255;
    if (address < 0x4000) this.m.bus.zram[address & 0x1fff] = value;
    else if (address < 0x6000) this.ymWrite(address & 3, value);
    else if (address >= 0x6000 && address < 0x6100) this.bank = ((this.bank >>> 1) | ((value & 1) << 8)) & 0x1ff;
    else if ((address & 0xfff9) === 0x7f11) { this.m.bus.psgLast = value; this.psg.write(value); }
    else if (address >= 0x8000) {
      const mapped = ((this.bank << 15) | (address & 0x7fff)) & 0xffffff;
      if (mapped < 0xa00000 || mapped > 0xa0ffff) this.m.bus.wb(mapped, value);
    }
  }
  vblank() { this.irqCycles = 488; }
  advance(m68kCycles) {
    if (!(m68kCycles > 0)) return;
    const bus = this.m.bus;
    // Z80 and 68000 divide the same master clock by 15 and 7 respectively.
    if (!bus.z80BusReq && bus.z80Reset) {
      this.z80Credit += m68kCycles * 7 / 15;
      let guard = 0;
      while (this.z80Credit > 0 && guard++ < 1024) {
        if (this.irqCycles > 0) this.z80.interrupt(255);
        const cycles = this.z80.step(); this.z80Credit -= cycles; this.totalZ80Cycles += cycles;
        this.irqCycles = Math.max(0, this.irqCycles - cycles * 15 / 7);
      }
    } else { this.irqCycles = Math.max(0, this.irqCycles - m68kCycles); if (!bus.z80Reset) this.z80Credit = 0; }
    this.fmBusyCycles = Math.max(0, this.fmBusyCycles - m68kCycles);
    this.fmCycles += m68kCycles;
    while (this.fmCycles >= 144) {
      this.fmCycles -= 144;
      const fm = this.fm.update(1), psg = this.psg.sample(this.nativeRate) * 1800;
      const left = fm[0][0] * 0.5 + psg, right = fm[1][0] * 0.5 + psg;
      const step = this.sampleRate / this.nativeRate; this.outputPhase += step;
      if (this.outputPhase >= 1) {
        this.outputPhase -= 1;
        const mix = 1 - this.outputPhase / step;
        this.pcm.push(Math.max(-32768, Math.min(32767, Math.round(this.previousLeft + (left - this.previousLeft) * mix))),
          Math.max(-32768, Math.min(32767, Math.round(this.previousRight + (right - this.previousRight) * mix))));
      }
      this.previousLeft = left; this.previousRight = right;
    }
  }
  unlock() {
    if (window.AndroidAudio) {
      // Native lifecycle/focus owns foreground. Losing focus must not abandon
      // that request, otherwise Android cannot notify us when focus returns.
      if (this.nativeEnabled !== this.enabled) { window.AndroidAudio.setEnabled(this.enabled); this.nativeEnabled = this.enabled; }
      return;
    }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC || !this.enabled) return;
    if (!this.context) this.context = new AC({sampleRate: this.sampleRate, latencyHint: 'interactive'});
    if (this.context.state !== 'running') this.context.resume().catch(() => {});
  }
  flush() {
    this.pcm.length = 0;
    if (window.AndroidAudio) window.AndroidAudio.flush();
    for (const node of this.nodes) { try { node.stop(); } catch (_) {} }
    this.nodes.clear(); this.nextTime = this.context?.currentTime || 0;
  }
  endFrame() {
    const samples = this.pcm; this.pcm = [];
    if (!samples.length || !this.enabled || !this.foreground || !this.m.running || this.m.paused) return;
    const frames = samples.length >>> 1;
    if (window.AndroidAudio) {
      const bytes = new Uint8Array(samples.length * 2), view = new DataView(bytes.buffer);
      for (let i = 0; i < samples.length; i++) view.setInt16(i * 2, samples[i], true);
      window.AndroidAudio.writePCM(b64(bytes)); return;
    }
    const ctx = this.context; if (!ctx || ctx.state !== 'running') return;
    if (this.nextTime > ctx.currentTime + 0.16) this.flush();
    const buffer = ctx.createBuffer(2, frames, this.sampleRate), left = buffer.getChannelData(0), right = buffer.getChannelData(1);
    for (let i = 0; i < frames; i++) { left[i] = samples[i * 2] / 32768; right[i] = samples[i * 2 + 1] / 32768; }
    const node = ctx.createBufferSource(); node.buffer = buffer; node.connect(ctx.destination); this.nodes.add(node);
    node.onended = () => { this.nodes.delete(node); node.disconnect(); };
    this.nextTime = Math.max(ctx.currentTime + 0.012, this.nextTime); node.start(this.nextTime); this.nextTime += frames / this.sampleRate;
  }
  setEnabled(enabled) {
    this.enabled = !!enabled; this.flush(); this.unlock();
    if (this.m === machine) { $('#audioBtn').textContent = this.enabled ? 'AUDIO ON' : 'AUDIO OFF'; localStorage.setItem('badgenesis:audio', String(this.enabled)); }
  }
  state() {
    return { version: 1, fm: this.fm.save(), psg: this.psg.state(), z80: this.z80.state(),
      bank: this.bank, z80Credit: this.z80Credit, fmCycles: this.fmCycles, outputPhase: this.outputPhase,
      previousLeft: this.previousLeft, previousRight: this.previousRight, irqCycles: this.irqCycles,
      totalZ80Cycles: this.totalZ80Cycles, fmBusyCycles: this.fmBusyCycles,
      masterClock: this.masterClock, fmClock: this.fmClock, nativeRate: this.nativeRate,
      busReq: this.m.bus.z80BusReq, reset: this.m.bus.z80Reset, ym: [...this.m.bus.ym], ymAddr: [...this.m.bus.ymAddr], psgLast: this.m.bus.psgLast };
  }
  loadState(s) {
    if (!s) { this.reset(); return; }
    const vector = (a, length, low, high) => Array.isArray(a) && a.length === length && a.every(v => Number.isFinite(v) && v >= low && v <= high);
    const finite = value => Number.isFinite(value);
    if (s.version !== 1 || !s.fm || !s.z80 || !s.psg ||
      !vector(s.ym, 512, 0, 255) || !vector(s.ymAddr, 2, 0, 255) ||
      !vector(s.psg.tone, 3, 0, 1023) || !vector(s.psg.volume, 4, 0, 15) ||
      !vector(s.psg.counter, 4, 1, 1024) || !vector(s.psg.level, 4, -1, 1) ||
      !finite(s.psg.clock) || s.psg.clock < 1000000 || s.psg.clock > 10000000 ||
      !finite(s.psg.fraction) || s.psg.fraction < 0 || s.psg.fraction >= 1 ||
      !finite(s.psg.lfsr) || s.psg.lfsr < 0 || s.psg.lfsr > 65535 ||
      !finite(s.psg.noise) || s.psg.noise < 0 || s.psg.noise > 7 ||
      !finite(s.bank) || s.bank < 0 || s.bank > 511 ||
      !finite(s.z80Credit) || s.z80Credit < -1024 || s.z80Credit > 0 ||
      !finite(s.fmCycles) || s.fmCycles < 0 || s.fmCycles >= 144 ||
      !finite(s.outputPhase) || s.outputPhase < 0 || s.outputPhase >= 1 ||
      !finite(s.previousLeft) || !finite(s.previousRight) ||
      !finite(s.irqCycles) || s.irqCycles < 0 || s.irqCycles > 488 ||
      !finite(s.totalZ80Cycles) || s.totalZ80Cycles < 0 ||
      !finite(s.fmBusyCycles) || s.fmBusyCycles < 0 || s.fmBusyCycles > 32 ||
      !finite(s.masterClock) || !finite(s.fmClock) || !finite(s.nativeRate) ||
      s.fmClock !== s.masterClock / 7 || s.nativeRate !== s.fmClock / 144 ||
      ![0,1].includes(s.busReq) || ![0,1].includes(s.reset) ||
      !finite(s.z80.pc) || !finite(s.z80.sp)) throw Error('Invalid Genesis audio state.');
    this.flush();
    this.fm.load(s.fm); this.psg.loadState(s.psg); this.z80.loadState(s.z80);
    for (const key of ['bank','z80Credit','fmCycles','outputPhase','previousLeft','previousRight','irqCycles','totalZ80Cycles','fmBusyCycles','masterClock','fmClock','nativeRate']) this[key] = s[key];
    const bus = this.m.bus; bus.z80BusReq = s.busReq; bus.z80Reset = s.reset;
    bus.ym.set(s.ym); bus.ymAddr.set(s.ymAddr); bus.psgLast = s.psgLast; bus.ymStatus = this.ymRead();
  }
}

function genesisSound(m) { if (!m.audio) m.audio = new GenesisAudio(m); return m.audio; }
const audioOriginalCpuStep = M68K.prototype.step;
M68K.prototype.step = function () { const cycles = audioOriginalCpuStep.call(this); genesisSound(this.m).advance(cycles); return cycles; };
const audioOriginalFrame = MegaDrive.prototype.runFrame;
MegaDrive.prototype.runFrame = function () { const audio = genesisSound(this); audioOriginalFrame.call(this); audio.endFrame(); };
const audioOriginalPower = MegaDrive.prototype.power;
MegaDrive.prototype.power = function (on = true) { const audio = genesisSound(this); audioOriginalPower.call(this, on); if (on && this.rom) audio.reset(); else audio.flush(); audio.unlock(); };
const audioOriginalState = MegaDrive.prototype.state;
MegaDrive.prototype.state = function () { const state = audioOriginalState.call(this); state.audio = genesisSound(this).state(); return state; };
const audioOriginalLoad = MegaDrive.prototype.loadState;
MegaDrive.prototype.loadState = function (state) { audioOriginalLoad.call(this, state); genesisSound(this).loadState(state.audio); };

const genesisAudio = genesisSound(machine);
genesisAudio.enabled = localStorage.getItem('badgenesis:audio') !== 'false';
$('#audioBtn').textContent = genesisAudio.enabled ? 'AUDIO ON' : 'AUDIO OFF';
$('#audioBtn').onclick = () => { genesisAudio.setEnabled(!genesisAudio.enabled); osd(genesisAudio.enabled ? 'Genesis audio enabled' : 'Genesis audio muted'); };
document.addEventListener('pointerdown', () => genesisAudio.unlock(), {capture:true});
document.addEventListener('keydown', () => genesisAudio.unlock(), {capture:true});
const audioPauseClick = $('#pauseBtn').onclick;
$('#pauseBtn').onclick = e => { audioPauseClick(e); if (machine.paused) genesisAudio.flush(); else genesisAudio.unlock(); };
window.BadGenesisAudioLifecycle = paused => { genesisAudio.foreground = !paused; genesisAudio.flush(); if (!paused) genesisAudio.unlock(); };
window.GenesisAudio = GenesisAudio; window.GenesisPSG = GenesisPSG;

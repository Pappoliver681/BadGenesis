/* Native phone integration and pointer-ID input; the original CPU and video remain intact. */
(function(){
  'use strict';
  const keys=Object.keys(machine.pad.keys);
  const pointers=new Map(),nativeKeys=new Set(),keyboardCodes=new Set();
  const defaults={size:100,opacity:75,buttons:'6',orientation:'landscape',visible:true,vibration:false,positions:{landscape:{dpad:{x:14,y:68},face:{x:86,y:68},meta:{x:50,y:86}},portrait:{dpad:{x:21,y:79},face:{x:76,y:79},meta:{x:50,y:94}}}};
  let prefs;
  try{const stored=JSON.parse(localStorage.getItem('badgenesis:controls:v1')||'null');prefs={...defaults,...stored,positions:{landscape:{...defaults.positions.landscape,...stored?.positions?.landscape},portrait:{...defaults.positions.portrait,...stored?.positions?.portrait}}}}catch(_){prefs=JSON.parse(JSON.stringify(defaults))}
  prefs.size=clamp(+prefs.size||100,60,160);prefs.opacity=clamp(+prefs.opacity||75,15,100);
  let editing=false,backgrounded=false,resumeAfterBackground=false,nativeConnected=false,menuPaused=false,menuResume=false,startAfterLoad=false;
  function nativeCall(method,...args){try{if(window.AndroidApp&&typeof window.AndroidApp[method]==='function')return window.AndroidApp[method](...args)}catch(e){log('ANDROID · '+e.message,'bad')}}
  function savePrefs(){try{localStorage.setItem('badgenesis:controls:v1',JSON.stringify(prefs))}catch(e){osd('Could not save control preferences')};applyPrefs()}
  function vibrate(){if(prefs.vibration)nativeCall('vibrate',12)}
  function orientation(){return innerWidth>innerHeight?'landscape':'portrait'}
  function layoutPosition(id){return prefs.positions[orientation()][id]||defaults.positions[orientation()][id]}
  const sixButtonRead=Pad3.prototype.read;
  Pad3.prototype.read=function(){
    if(prefs.buttons!=='3')return sixButtonRead.call(this);
    // A three-button controller never answers the six-button identification bank.
    const k=this.keys,th=this.currentTH();let value=th?0x7f:0x33;
    const low=(bit,held)=>{if(held)value&=~bit};
    low(1,k.up);low(2,k.down);
    if(th){low(4,k.left);low(8,k.right);low(0x10,k.b);low(0x20,k.c)}
    else{low(0x10,k.a);low(0x20,k.start)}
    this.lastRead=((value&~this.ctrl)|(this.data&this.ctrl)|0x80)&255;this.reads++;
    return this.lastRead;
  };
  function safeArea(){
    // CSS resolves browser safe-area values together with Android display cutouts.
    const style=globalThis.getComputedStyle?.($('#mobileControls'));
    const nativeStyle=document.documentElement.style;
    const inset=(side)=>Math.max(0,parseFloat(style?.['padding'+side])||parseFloat(nativeStyle.getPropertyValue?.('--native-safe-'+side.toLowerCase())||nativeStyle['--native-safe-'+side.toLowerCase()])||0);
    return{left:inset('Left'),top:inset('Top'),right:inset('Right'),bottom:inset('Bottom')};
  }
  function applyPrefs(){
    document.documentElement.style.setProperty('--control-scale',prefs.size/100);
    document.documentElement.style.setProperty('--control-opacity',prefs.opacity/100);
    document.body.classList.toggle('controls-hidden',!prefs.visible);
    document.body.classList.toggle('three-buttons',prefs.buttons==='3');
    const safe=safeArea();
    for(const group of document.querySelectorAll('[data-control-group]')){const p=layoutPosition(group.dataset.controlGroup),halfW=group.offsetWidth*prefs.size/200,halfH=group.offsetHeight*prefs.size/200,minX=safe.left+halfW+5,minY=safe.top+halfH+45;group.style.left=clamp(innerWidth*p.x/100,minX,Math.max(minX,innerWidth-safe.right-halfW-5))+'px';group.style.top=clamp(innerHeight*p.y/100,minY,Math.max(minY,innerHeight-safe.bottom-halfH-5))+'px'}
    $('#mobileShow').textContent=prefs.visible?'HIDE PAD':'SHOW PAD';
    $('#controlVisibility').textContent=prefs.visible?'HIDE CONTROLS':'SHOW CONTROLS';
    $('#controlSizeValue').textContent=prefs.size+'%';$('#controlOpacityValue').textContent=prefs.opacity+'%';
    nativeCall('setVibrationEnabled',!!prefs.vibration);
  }
  window.BadGenesisInsetsChanged=applyPrefs;
  function heldByTouch(k){for(const p of pointers.values())if(p.keys?.has(k))return true;return false}
  // Every source is independent. A finger lifting never releases another finger or a physical controller.
  applyMergedPad=function(k){const down=!backgrounded&&(physicalKeys.has(k)||gamepadKeys.has(k)||nativeKeys.has(k)||heldByTouch(k));machine.pad.set(k,down);updatePadVisual(k,down);document.querySelectorAll('[data-direction="'+k+'"]').forEach(e=>e.classList.toggle('held',down))};
  function mergeAll(){for(const k of keys)applyMergedPad(k)}
  function stopPointer(id){const p=pointers.get(id);if(!p)return;pointers.delete(id);mergeAll()}
  function clearTouches(){pointers.clear();mergeAll()}
  function clearInputs(){pointers.clear();keyboardCodes.clear();physicalKeys.clear();nativeKeys.clear();gamepadKeys.clear();mergeAll()}
  function updateKeyboard(){physicalKeys.clear();for(const code of keyboardCodes){const k=keyMap[code];if(k)physicalKeys.add(k)}mergeAll()}
  // Capture avoids the old single-key handler losing a held input when two keyboard keys map to A/B/C.
  addEventListener('keydown',e=>{if(!keyMap[e.code]||editableTarget(e.target))return;e.preventDefault();e.stopImmediatePropagation();keyboardCodes.add(e.code);updateKeyboard()},true);
  addEventListener('keyup',e=>{if(!keyMap[e.code])return;e.preventDefault();e.stopImmediatePropagation();keyboardCodes.delete(e.code);updateKeyboard()},true);
  function capture(el,id){try{el.setPointerCapture(id)}catch(_){}}
  function dragging(e,group){const r=group.getBoundingClientRect(),id=group.dataset.controlGroup;pointers.set(e.pointerId,{drag:id,dx:e.clientX-r.left-r.width/2,dy:e.clientY-r.top-r.height/2,keys:new Set()});capture(group,e.pointerId)}
  function moveGroup(e,p){const pos=prefs.positions[orientation()][p.drag];pos.x=clamp((e.clientX-p.dx)/innerWidth*100,5,95);pos.y=clamp((e.clientY-p.dy)/innerHeight*100,10,95);applyPrefs()}
  function dpadKeys(e){const r=$('#mobileDpad').getBoundingClientRect(),x=(e.clientX-(r.left+r.width/2))/(r.width/2),y=(e.clientY-(r.top+r.height/2))/(r.height/2),held=new Set();if(x<-.24)held.add('left');if(x>.24)held.add('right');if(y<-.24)held.add('up');if(y>.24)held.add('down');return held}
  const dpad=$('#mobileDpad');
  dpad.onpointerdown=e=>{e.preventDefault();if(editing)return dragging(e,dpad);const held=dpadKeys(e);pointers.set(e.pointerId,{dpad:true,keys:held});if(held.size)vibrate();capture(dpad,e.pointerId);mergeAll()};
  dpad.onpointermove=e=>{const p=pointers.get(e.pointerId);if(!p)return;e.preventDefault();if(p.drag)moveGroup(e,p);else p.keys=dpadKeys(e);mergeAll()};
  function pointerUp(e){if(!pointers.has(e.pointerId))return;e.preventDefault();const moved=!!pointers.get(e.pointerId)?.drag;stopPointer(e.pointerId);if(moved){savePrefs();syncPositionSliders()}}
  dpad.onpointerup=dpad.onpointercancel=dpad.onlostpointercapture=pointerUp;
  // Old panels keep their controls, with the same pointer-ID union as the gameplay overlay.
  for(const b of document.querySelectorAll('[data-key]')){
    b.onpointerleave=null;
    b.onpointerdown=e=>{e.preventDefault();if(editing){const group=b.closest('[data-control-group]');if(group)return dragging(e,group);return}pointers.set(e.pointerId,{button:b.dataset.key,keys:new Set([b.dataset.key])});vibrate();capture(b,e.pointerId);mergeAll()};
    b.onpointermove=e=>{const p=pointers.get(e.pointerId);if(!p)return;e.preventDefault();if(p.drag)return moveGroup(e,p);if(b.closest('#mobileFace')){const hit=document.elementFromPoint(e.clientX,e.clientY)?.closest('#mobileFace [data-key]');p.keys=new Set(hit?[hit.dataset.key]:[]);mergeAll()}};
    b.onpointerup=b.onpointercancel=b.onlostpointercapture=pointerUp;
  }
  for(const group of document.querySelectorAll('[data-control-group]')){
    group.addEventListener('pointerdown',e=>{if(editing&&!pointers.has(e.pointerId)){e.preventDefault();dragging(e,group)}});
    group.addEventListener('pointermove',e=>{const p=pointers.get(e.pointerId);if(p?.drag){e.preventDefault();moveGroup(e,p)}});
    group.addEventListener('pointerup',pointerUp);group.addEventListener('pointercancel',pointerUp);group.addEventListener('lostpointercapture',pointerUp);
  }
  addEventListener('pointerup',pointerUp);addEventListener('pointercancel',pointerUp);
  // Browser pads and Android InputDevice pads both map all six action buttons.
  pollGamepad=function(){
    const next=new Set();let pads=[];try{pads=Array.from(navigator.getGamepads?.()||[]).filter(Boolean)}catch(_){}
    const g=pads[0];
    for(const pad of pads){const x=pad.axes[0]||0,y=pad.axes[1]||0;const b=n=>!!pad.buttons[n]?.pressed;
      if(b(12)||y<-.4)next.add('up');if(b(13)||y>.4)next.add('down');if(b(14)||x<-.4)next.add('left');if(b(15)||x>.4)next.add('right');
      if(b(2))next.add('a');if(b(0))next.add('b');if(b(1))next.add('c');if(b(4))next.add('x');if(b(5))next.add('y');if(b(3))next.add('z');if(b(8))next.add('mode');if(b(9))next.add('start');
    }
    gamepadKeys.clear();for(const k of next)gamepadKeys.add(k);mergeAll();
    const name=g?.id||'';if(name!==lastGamepadId){lastGamepadId=name;if(name){log('PAD · connected '+name);osd('Gamepad connected')}}
    const status=$('#gamepadStatus');status.textContent=nativeConnected?'Android gamepad connected':g?'Gamepad: '+g.id.slice(0,34):'Gamepad: not detected';status.className=nativeConnected||g?'gamepad-ok':'gamepad-off';
    $('#padSource').textContent=nativeConnected||g?'GAMEPAD + TOUCH / KEYBOARD':'TOUCH / KEYBOARD';
  };
  window.BadGenesisNativePad=function(k,on){if(k==='connected'){nativeConnected=!!on;if(!on){nativeKeys.clear();mergeAll()}return}if(k==='releaseAll'){nativeKeys.clear();mergeAll();return}if(!keys.includes(k))return;nativeConnected=true;if(on)nativeKeys.add(k);else nativeKeys.delete(k);mergeAll()};
  function setEditing(on){editing=!!on;document.body.classList.toggle('edit-controls',editing);$('#mobileMoveDone').hidden=!editing;clearInputs()}
  function enterGameplay(){if(!machine.rom){osd('Load a ROM first');return}if(menuPaused&&menuResume&&machine.powered){machine.paused=false;machine.running=true}menuPaused=false;menuResume=false;if(window.AndroidApp)clearNativePanels();document.body.classList.add('gameplay');applyPrefs();nativeCall('setOrientation',prefs.orientation);nativeCall('enterGameplay');if(!window.AndroidApp){const p=$('#screenShell').requestFullscreen?.();p?.catch?.(()=>{})}}
  function exitGameplay(){setEditing(false);clearInputs();document.body.classList.remove('gameplay');nativeCall('exitGameplay');if(document.fullscreenElement)document.exitFullscreen?.().catch?.(()=>{});if(window.AndroidApp)showNativeHome()}
  window.BadGenesisBack=function(){if(editing){setEditing(false);return true}if(document.body.classList.contains('gameplay')){exitGameplay();return true}if(window.AndroidApp&&document.body.classList.contains('android-panel')){showNativeHome();return true}return false};
  window.BadGenesisGameplay={enter:enterGameplay,exit:exitGameplay,release:clearInputs,merge:mergeAll};
  $('#fullBtn').onclick=()=>document.body.classList.contains('gameplay')?exitGameplay():enterGameplay();
  $('#mobileMenu').onclick=exitGameplay;$('#controlPlay').onclick=enterGameplay;
  $('#mobileShow').onclick=$('#controlVisibility').onclick=()=>{prefs.visible=!prefs.visible;clearTouches();savePrefs()};
  $('#mobileBlast').onclick=()=>rtcBlast(false);rtcHoldBind($('#mobileRewind'));
  $('#controlMove').onclick=()=>{enterGameplay();if(document.body.classList.contains('gameplay'))setEditing(true)};
  $('#mobileMoveDone').onclick=()=>setEditing(false);
  $('#controlReset').onclick=()=>{prefs.positions=JSON.parse(JSON.stringify(defaults.positions));savePrefs();syncPositionSliders()};
  for(const [id,prop] of [['controlSize','size'],['controlOpacity','opacity'],['controlButtons','buttons'],['controlOrientation','orientation']]){const e=$('#'+id);e.value=prefs[prop];e.oninput=()=>{prefs[prop]=(prop==='size'||prop==='opacity')?+e.value:e.value;if(prop==='buttons'){clearInputs();machine.pad.phase=0;machine.pad.lastToggle=performance.now();machine.pad.lastToggleCycles=machine.cpu.total}savePrefs();if(prop==='orientation'&&document.body.classList.contains('gameplay'))nativeCall('setOrientation',prefs.orientation)}}
  $('#controlVibration').value=prefs.vibration?'on':'off';
  $('#controlVibration').onchange=e=>{prefs.vibration=e.target.value==='on';savePrefs();vibrate()};
  function syncPositionSliders(){const pos=prefs.positions[$('#controlLayout').value][$('#controlGroup').value];$('#controlX').value=Math.round(pos.x);$('#controlY').value=Math.round(pos.y)}
  $('#controlGroup').onchange=$('#controlLayout').onchange=syncPositionSliders;
  for(const [id,axis] of [['controlX','x'],['controlY','y']])$('#'+id).oninput=e=>{prefs.positions[$('#controlLayout').value][$('#controlGroup').value][axis]=+e.target.value;savePrefs()};
  addEventListener('resize',()=>{applyPrefs();syncPositionSliders()});
  addEventListener('fullscreenchange',()=>{if(!document.fullscreenElement&&!window.AndroidApp&&document.body.classList.contains('gameplay'))exitGameplay()});
  // Java delivers lifecycle changes. Browser visibility uses the same safe pause behavior.
  window.BadGenesisLifecycle=function(paused){
    if(paused){if(backgrounded)return;resumeAfterBackground=machine.powered&&machine.running&&!machine.paused;backgrounded=true;if(typeof RTC!=='undefined'&&RTC.rewinding)rtcRewindStop(false);clearInputs();machine.paused=true;machine.persistSRAM?.(true);if(window.BadGenesisAudioLifecycle)window.BadGenesisAudioLifecycle(true)}
    else{if(!backgrounded)return;backgrounded=false;if(resumeAfterBackground&&machine.powered){machine.running=true;machine.paused=false}resumeAfterBackground=false;last=performance.now();acc=0;if(window.BadGenesisAudioLifecycle)window.BadGenesisAudioLifecycle(false);mergeAll()}refreshUI();
  };
  document.addEventListener('visibilitychange',()=>window.BadGenesisLifecycle(document.hidden));
  addEventListener('blur',()=>{clearInputs();if(typeof RTC!=='undefined'&&RTC.rewinding)rtcRewindStop(false)});
  // Native exports use the Android document picker, including save states and screenshots.
  const browserDownload=download;
  download=function(name,blob){if(!window.AndroidApp?.exportFile)return browserDownload(name,blob);const reader=new FileReader();reader.onload=()=>nativeCall('exportFile',name,String(reader.result).split(',')[1]||'',blob.type||'application/octet-stream');reader.onerror=()=>osd('Export could not be prepared');reader.readAsDataURL(blob)};
  // Native gameplay begins from the existing Power gesture; desktop layout is unchanged.
  $('#powerBtn').addEventListener('click',()=>{if(window.AndroidApp&&machine.powered)enterGameplay()});
  $('#copyLog').onclick=async()=>{try{if(window.AndroidApp?.copyText){nativeCall('copyText',machine.logs.join('\n'));osd('Log copied')}else{await navigator.clipboard.writeText(machine.logs.join('\n'));osd('Log copied')}}catch(_){osd('Clipboard unavailable')}};
  function updateNativeMenu(){
    $('#androidGameName').textContent=machine.rom?machine.romName:'No game loaded';
    $('#androidContinue').disabled=!machine.rom;
    $('#androidSystem').disabled=!machine.rom;$('#androidClose').disabled=!machine.rom;
    $('#androidPlay').disabled=!machine.rom;
  }
  function pauseForMenu(){if(!menuPaused){menuResume=machine.powered&&machine.running&&!machine.paused;menuPaused=true;if(menuResume)machine.paused=true}clearInputs()}
  function clearNativePanels(){for(const cls of ['android-home','android-panel','android-system','android-options','android-rtc','android-tools'])document.body.classList.remove(cls)}
  function showNativeHome(){if(!window.AndroidApp)return;pauseForMenu();clearNativePanels();document.body.classList.add('android-home');updateNativeMenu();nativeCall('setOrientation','auto')}
  function showNativePanel(which,title){pauseForMenu();clearNativePanels();document.body.classList.add('android-panel','android-'+which);$('#androidPanelTitle').textContent=title;updateNativeMenu();nativeCall('setOrientation','auto');if(which==='options')document.querySelector('[data-tab="pad"]').click();if(which==='tools')document.querySelector('[data-tab="rom"]').click();if(which==='rtc'&&machine.powered){machine.paused=false;machine.running=true;menuResume=true}}
  function playNative(){if(!machine.rom)return;if(!machine.powered){$('#powerBtn').click();return}machine.paused=false;machine.running=true;enterGameplay()}
  $('#androidLoad').onclick=()=>{startAfterLoad=true;showNativePanel('tools','Load Game');$('#fileInput').click()};
  $('#androidContinue').onclick=$('#androidPlay').onclick=playNative;
  $('#androidSystem').onclick=()=>showNativePanel('system','System Actions');
  $('#androidOptions').onclick=()=>showNativePanel('options','Options');
  $('#androidRtc').onclick=()=>showNativePanel('rtc','RTC / Glitch Harvester');
  $('#androidTools').onclick=()=>showNativePanel('tools','Emulator Tools');
  $('#androidHome').onclick=showNativeHome;
  $('#androidClose').onclick=()=>{machine.persistSRAM?.(true);if(typeof RTC!=='undefined'&&RTC.rewinding)rtcRewindStop(false);clearInputs();machine.power(false);machine.rom=null;menuPaused=false;menuResume=false;refreshUI();showNativeHome()};
  for(const row of document.querySelectorAll('[data-proxy]'))row.onclick=()=>document.getElementById(row.dataset.proxy)?.click();
  for(const row of document.querySelectorAll('[data-file-proxy]'))row.onclick=()=>document.getElementById(row.dataset.fileProxy)?.click();
  if(window.AndroidApp){
    document.body.classList.add('android-mode');
    const oldRefresh=refreshUI;refreshUI=function(){oldRefresh();updateNativeMenu()};
    const oldLoad=MegaDrive.prototype.loadROM;MegaDrive.prototype.loadROM=function(){this.persistSRAM?.(true);const info=oldLoad.apply(this,arguments);updateNativeMenu();if(startAfterLoad){startAfterLoad=false;setTimeout(()=>{if(!machine.powered)$('#powerBtn').click();else enterGameplay()},0)}return info};
    showNativeHome();
  }
  syncPositionSliders();applyPrefs();mergeAll();
})();

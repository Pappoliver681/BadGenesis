# BadGenesis Android RTC port

This continues the supplied BadGenesis HTML emulator. The original 68000 CPU,
VDP renderer, ROM loader and tools remain the base. `original.html` is the exact
uploaded file (SHA-256 `c420f06b3a62f387f3506f66b8ca17ec7b7329182037a371f6481e412b0a9783`).

The retained project now includes real YM2612 FM/DAC, SN76489 PSG and an executing
Z80 sound CPU. Full sound-chip, CPU, memory and raster state is saved and restored.
Android uses native AudioTrack, document pickers, gamepad input, haptics, immersive
display, rotation, audio focus and lifecycle handling around the existing emulator.

The Android interface uses MD.emu-style dark menus and Genesis touch controls.
All interface text is English. The framebuffer is sharp and unfiltered.

RTC supports Work RAM, Z80 RAM, VRAM, CRAM, VSRAM, supported SRAM, and an owned ROM
copy; every requested byte/endian/NOP mutation; domain ranges and exclusions;
fresh random normal/Auto Blasts; optional reproducible mode; Undo/history;
clean-state harvesting; full quick/persistent/manual states; crash recovery; and
hold-to-rewind across blasts. Rewind presets are 15/30/60/120 seconds within a
64 MiB RAM limit, with adaptive snapshot spacing for longer durations.

## Validation and build status

On 2026-10-01, all 25 checks in `tests/run.cjs` passed. They execute the actual
emulator scripts and a generated public-domain diagnostic ROM, including original
CPU/video comparisons, RTC/control behavior, 1,792 Z80 opcode paths, 3,600
independent Z80 reference vectors, independent FM/PSG synthesis, and bit-exact
future PCM after state restoration.

**A signed test APK was built successfully on GitHub Actions.**
[Successful build](https://github.com/Pappoliver681/BadGenesis/actions/runs/36873347132)
compiled the native integration, converted it with D8, verified APK v2/v3 signatures,
checked alignment, and passed all 25 emulator/RTC/audio/control checks.
The downloaded APK is `dist/BadGenesis-Android16.apk` (128,306 bytes; SHA-256
`d86a8412c3da635069afed620aa7d8e16bc408203d45c64edef2b1cf1bd1e4c6`).
Its emulator, audio, RTC and UI assets match the retained source byte for byte.

`tools/cloud-build.sh` contains the concrete cloud build: download checksum-verified
official Android SDK 36 tools, use the installed JDK compiler, compile native code and
resources, produce DEX for API 26+, sign, align, and verify
`dist/BadGenesis-Android16.apk`. It targets Android 16 / API 36. The cloud environment
executes this build. The phone user is not required to install development tools.

Browser screenshot tests and physical Android installation/speaker/controller
checks have not run. The APK is ready for installation and testing on the user's
phone; real-device gameplay, speaker audio and controller checks remain to be done.

## Files

- `app/src/main/assets/`: updated emulator, sound, RTC and UI.
- `app/src/main/java/`: native Android integration.
- `tools/cloud-build.sh`: cloud build and signing pipeline.
- `tools/package_release.py`: source ZIP and standalone offline HTML packager.
- `test-results/integration-report.json`: actual verification results.
- `tests/diagnostic.bin`: optional generated test ROM, separate from the app.
- `tests/AUDIO-PROVENANCE.md` and `tests/Z80-PROVENANCE.md`: dependencies and credits.

ROMs are not bundled in the app. Original ROM files are opened read-only. Corrupted
ROMs and save files export through Android's document-save dialog as separate files.
